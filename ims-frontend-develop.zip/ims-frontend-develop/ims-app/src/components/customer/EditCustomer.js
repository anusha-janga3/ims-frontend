import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS

const EditCustomer = () => {
  const navigate = useNavigate();
  const [customerData, setCustomerData] = useState({
    address: '',
    name: '',
    email: '',
    phone: '',
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [emailError, setEmailError] = useState('');
  const [phoneError, setPhoneError] = useState('');

  // Retrieve the token and user ID from local storage
  const token = localStorage.getItem('userToken');
  const loggedInUserId = localStorage.getItem('userId');

  useEffect(() => {
    const fetchCustomerData = async () => {
      setLoading(true);
      setError('');
      try {
        const response = await axios.get(`http://localhost:8088/api/v1/customers/${loggedInUserId}`, {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        setCustomerData({
          address: response.data.data.address,
          name: response.data.data.name,
          email: response.data.data.email,
          phone: response.data.data.phone,
        });
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    if (token && loggedInUserId) {
      fetchCustomerData();
    } else {
      setError('Authentication token or user ID not found. Please log in.');
      setLoading(false);
      navigate('/login'); // Redirect to login if not authenticated
    }
  }, [navigate, token, loggedInUserId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCustomerData({
      ...customerData,
      [name]: value,
    });

    if (name === 'email') {
      setEmailError('Email cannot be updated.');
    } else if (name === 'phone') {
      if (!/^\d{10}$/.test(value)) {
        setPhoneError('Phone number must be 10 digits.');
      } else {
        setPhoneError('');
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setEmailError('');
    setPhoneError('');

    if (phoneError) {
      setLoading(false);
      return;
    }

    try {
      const response = await axios.put(
        `http://localhost:8088/api/v1/customers/update/${loggedInUserId}`, // Use loggedInUserId for update
        {
          address: customerData.address,
          name: customerData.name,
          email: customerData.email,
          phone: customerData.phone,
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
          },
        }
      );
      console.log(response);

      console.log('Customer updated successfully');
      navigate(`/dashboard/profile/${loggedInUserId}`); // Navigate back to the profile page
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div>Loading customer information...</div>;
  }

  if (error) {
    return <div>Error loading customer: {error}</div>;
  }

  return (
    <div className="container mt-4">
      <h2 className="mb-3">Edit Customer</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="name" className="form-label">Name:</label>
          <input
            type="text"
            id="name"
            name="name"
            value={customerData.name}
            onChange={handleChange}
            className="form-control"
          />
        </div>
        <div className="mb-3">
          <label htmlFor="email" className="form-label">Email:</label>
          <input
            type="email"
            id="email"
            name="email"
            value={customerData.email}
            onChange={handleChange}
            className="form-control"
            readOnly
          />
          {emailError && <p className="text-danger">{emailError}</p>}
        </div>
        <div className="mb-3">
          <label htmlFor="phone" className="form-label">Phone:</label>
          <input
            type="text"
            id="phone"
            name="phone"
            value={customerData.phone}
            onChange={handleChange}
            className="form-control"
          />
          {phoneError && <p className="text-danger">{phoneError}</p>}
        </div>
        <div className="mb-3">
          <label htmlFor="address" className="form-label">Address:</label>
          <textarea
            id="address"
            name="address"
            value={customerData.address}
            onChange={handleChange}
            className="form-control"
          />
        </div>
        <button type="submit" className="btn btn-primary" disabled={loading || phoneError}>
          {loading ? 'Updating...' : 'Update'}
        </button>
        {error && <p className="text-danger mt-2">{error}</p>}
      </form>
    </div>
  );
};

export default EditCustomer;