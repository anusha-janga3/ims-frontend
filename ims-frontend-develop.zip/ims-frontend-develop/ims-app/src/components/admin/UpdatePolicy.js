import { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useParams, useNavigate, Link } from 'react-router-dom';
import AdminNavBar from '../layout/AdminNavBar';
 
const API_BASE_URL = 'http://localhost:8082/api/v1/policies';
const API_BASE_URL_UPDATE = 'http://localhost:8082/api/v1/policies/update';
 
const EditPolicy = () => {
  const { policyId } = useParams();
  const navigate = useNavigate();
  const [policy, setPolicy] = useState({
    name: '',
    coverageDetails: '',
    validityPeriod: '',
    premiumAmount: '',
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
 
  useEffect(() => {
fetchPolicyDetailsWithSecurity();
  }, [policyId]);
 
  const fetchPolicyDetailsWithSecurity = async () => {
    setLoading(true);
    setError('');
    const token = localStorage.getItem('userToken');
 
    try {
      const response = await fetch(`${API_BASE_URL}/${policyId}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
 
      if (response.ok) {
        const responseData = await response.json();
        if (responseData.success && responseData.data) {
          setPolicy(responseData.data);
        } else {
          setError(responseData.message || `Policy with ID ${policyId} not found.`);
        }
      } else if (response.status === 401) {
        setError('Unauthorized. Please log in again.');
        navigate('/login');
      } else if (response.status === 403) {
        setError('Forbidden. You do not have permission to view this policy.');
      } else {
        setError('An unexpected error occurred while fetching policy details.');
      }
    } catch (error) {
      console.error('Error fetching policy details:', error);
      setError('An unexpected error occurred while fetching policy details.');
    } finally {
      setLoading(false);
    }
  };
 
  const handleChange = (e) => {
    const { name, value } = e.target;
    setPolicy(prevState => ({
      ...prevState,
      [name]: value,
    }));
  };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    setMessage('');
    const token = localStorage.getItem('userToken');
 
    try {
      const response = await fetch(`${API_BASE_URL_UPDATE}/${policyId}`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(policy),
      });
 
      if (response.ok) {
        const responseData = await response.json();
        if (responseData.success) {
          setMessage(`Policy with ID ${policyId} updated successfully!`);
          setTimeout(() => navigate('/policies'), 1500);
        } else {
          setError(responseData.message || `Failed to update policy with ID ${policyId}.`);
        }
      } else if (response.status === 401) {
        setError('Unauthorized. Please log in again.');
        localStorage.removeItem('userId');
        localStorage.removeItem('userToken');
        navigate('/login');
      } else if (response.status === 403) {
        setError('Forbidden. You do not have permission to update this policy.');
      } else {
        setError('An unexpected error occurred while updating the policy.');
      }
    } catch (error) {
      console.error('Error updating policy:', error);
      setError('An unexpected error occurred while updating the policy.');
    } finally {
      setSaving(false);
    }
  };
 
  if (loading) {
    return <div className="container mt-4"><div className="spinner-border text-primary" role="status"><span className="visually-hidden">Loading...</span></div></div>;
  }
 
  if (error) {
    return <div className="container mt-4"><div className="alert alert-danger">{error} <Link to="/policies" className="alert-link">Go back to Policies</Link></div></div>;
  }
 
  return (
    <>
     <header className="transparent-header bg-white">
    <AdminNavBar/>
      </header>
    <div className="container mt-4">
      <h2>Edit Policy</h2>
      {message && <div className="alert alert-success">{message}</div>}
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="name" className="form-label">Name</label>
          <input
            type="text"
            className="form-control"
            id="name"
            name="name"
            value={policy.name}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="coverageDetails" className="form-label">Coverage Details</label>
          <textarea
            className="form-control"
            id="coverageDetails"
            name="coverageDetails"
            value={policy.coverageDetails}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="validityPeriod" className="form-label">Validity Period (Years)</label>
          <input
            type="number"
            className="form-control"
            id="validityPeriod"
            name="validityPeriod"
            value={policy.validityPeriod}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="premiumAmount" className="form-label">Premium Amount</label>
          <input
            type="number"
            className="form-control"
            id="premiumAmount"
            name="premiumAmount"
            value={policy.premiumAmount}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary" disabled={saving}>
          {saving ? <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> : 'Save Changes'}
        </button>
        <Link to="/policies" className="btn btn-secondary ms-2">Cancel</Link>
      </form>
    </div>
    </>
  );
};
 
export default EditPolicy;
 
 