
import { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate, Link } from 'react-router-dom';
 
const API_BASE_URL_CREATE = 'http://localhost:8082/api/v1/policies/add'; // Backend API URL for policy creation
 
const AddPolicy = () => {
  const navigate = useNavigate();
  const [policy, setPolicy] = useState({
    name: '',
    coverageDetails: '',
    validityPeriod: '',
    premiumAmount: '',
    adminId: 'a2b73861-957f-4a00-a00a-539d1ccde94d',
  });
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [validationErrors, setValidationErrors] = useState({});
 
  const handleChange = (e) => {
    const { name, value } = e.target;
    setPolicy((prevState) => ({
      ...prevState,
      [name]: value,
    }));
    // Clear any previous validation error for this field
    setValidationErrors((prevErrors) => ({
      ...prevErrors,
      [name]: '',
    }));
  };
 
  const validate = () => {
    const errors = {};
    const nameRegex = /^[a-zA-Z\s]*$/; // Allows only letters and spaces
 
    if (!policy.name.trim()) {
      errors.name = 'Name is required.';
    } else if (!nameRegex.test(policy.name)) {
      errors.name = 'Name should only contain letters and spaces.';
    }
 
    if (!policy.validityPeriod) {
      errors.validityPeriod = 'Validity Period is required.';
    } else if (isNaN(policy.validityPeriod) || Number(policy.validityPeriod) <= 0) {
      errors.validityPeriod = 'Validity Period must be greater than 0.';
    } else if (Number(policy.validityPeriod) < 1 || Number(policy.validityPeriod) > 40) {
      errors.validityPeriod = 'Validity Period must be between 1 and 40 years.';
    }
 
    if (!policy.premiumAmount) {
      errors.premiumAmount = 'Premium Amount is required.';
    } else if (isNaN(policy.premiumAmount) || Number(policy.premiumAmount) <= 0) {
      errors.premiumAmount = 'Premium Amount must be greater than 0.';
    } else if (Number(policy.premiumAmount) < 500 || Number(policy.premiumAmount) > 100000) {
      errors.premiumAmount = 'Premium Amount must be between 500 and 100000.';
    }
 
    if (!policy.coverageDetails.trim()) {
      errors.coverageDetails = 'Coverage Details are required.';
    }
 
    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (validate()) {
      setSaving(true);
      setError('');
      setMessage('');
      const token = localStorage.getItem('userToken');
 
      try {
        const response = await fetch(API_BASE_URL_CREATE, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`, // Pass token for security
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(policy),
        });
        console.log('Request Body:', policy);
        if (response.ok) {
          const responseData = await response.json();
          if (responseData.success) {
            setMessage('Policy created successfully!');
            setTimeout(() => navigate('/policies'), 1500); // Redirect after successful creation
          } else {
            setError(responseData.message || 'Failed to create policy.');
          }
        } else if (response.status === 401) {
          setError('Unauthorized. Please log in again.');
          localStorage.removeItem('userId');
          localStorage.removeItem('userToken');
          navigate('/login');
        } else if (response.status === 403) {
          setError('Forbidden. You do not have permission to create a policy.');
        } else {
          setError('An unexpected error occurred while creating the policy.');
        }
      } catch (error) {
        console.error('Error creating policy:', error);
        setError('An unexpected error occurred while creating the policy.');
      } finally {
        setSaving(false);
      }
    }
  };
 
  return (
    <div className="container mt-4">
      <h2>Add Policy</h2>
      {message && <div className="alert alert-success">{message}</div>}
      {error && <div className="alert alert-danger">{error}</div>}
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="name" className="form-label">Name</label>
          <input
            type="text"
            className={`form-control ${validationErrors.name ? 'is-invalid' : ''}`}
            id="name"
            name="name"
            value={policy.name}
            onChange={handleChange}
            required
          />
          {validationErrors.name && <div className="invalid-feedback">{validationErrors.name}</div>}
        </div>
        <div className="mb-3">
          <label htmlFor="coverageDetails" className="form-label">Coverage Details</label>
          <textarea
            className={`form-control ${validationErrors.coverageDetails ? 'is-invalid' : ''}`}
            id="coverageDetails"
            name="coverageDetails"
            value={policy.coverageDetails}
            onChange={handleChange}
            required
          />
          {validationErrors.coverageDetails && <div className="invalid-feedback">{validationErrors.coverageDetails}</div>}
        </div>
        <div className="mb-3">
          <label htmlFor="validityPeriod" className="form-label">Validity Period (Years)</label>
          <input
            type="number"
            className={`form-control ${validationErrors.validityPeriod ? 'is-invalid' : ''}`}
            id="validityPeriod"
            name="validityPeriod"
            value={policy.validityPeriod}
            onChange={handleChange}
            required
            min="1"
            max="40"
          />
          {validationErrors.validityPeriod && <div className="invalid-feedback">{validationErrors.validityPeriod}</div>}
        </div>
        <div className="mb-3">
          <label htmlFor="premiumAmount" className="form-label">Premium Amount</label>
          <input
            type="number"
            className={`form-control ${validationErrors.premiumAmount ? 'is-invalid' : ''}`}
            id="premiumAmount"
            name="premiumAmount"
            value={policy.premiumAmount}
            onChange={handleChange}
            required
            min="500"
            max="100000"
          />
          {validationErrors.premiumAmount && <div className="invalid-feedback">{validationErrors.premiumAmount}</div>}
        </div>
        <button type="submit" className="btn btn-primary" disabled={saving}>
          {saving ? (
            <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
          ) : (
            'Create Policy'
          )}
        </button>
        <Link to="/policies" className="btn btn-secondary ms-2">Cancel</Link>
      </form>
    </div>
  );
};
 
export default AddPolicy;
 
 