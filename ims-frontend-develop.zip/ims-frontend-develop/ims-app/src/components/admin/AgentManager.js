import { useState, useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link, useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEye, faPencilAlt, faTrash, faUsers } from '@fortawesome/free-solid-svg-icons'; // Import edit and delete icons
import AdminNavBar from '../layout/AdminNavBar';
 
const API_BASE_URL = '/api/v1/agents'; // Your backend API URL
 
const AgentManager = () => {
  const [agents, setAgents] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
 
  useEffect(() => {
    fetchAgentsWithSecurity();
  }, []);
 
  const fetchAgentsWithSecurity = async () => {
    setLoading(true);
    setError('');
    const token = localStorage.getItem('userToken');
 
    try {
      const response = await axios.get(API_BASE_URL, {
        headers: {
          'Authorization': `Bearer ${token}`, // Include the JWT token
          'Content-Type': 'application/json',
        },
      });
      if (response.data && response.data.success) {
        setAgents(response.data.data);
        setError('');
      } else {
        setError(response.data?.message || 'Failed to fetch agents.');
      }
    } catch (error) {
      console.error('Error fetching agents:', error);
      if (error.response && error.response.status === 401) {
        setError('Unauthorized. Please log in again.');
        localStorage.removeItem('userId');
        localStorage.removeItem('userToken');
        navigate('/login'); // Redirect to login if unauthorized
      } else if (error.response && error.response.status === 403) {
        setError('Forbidden. You do not have permission to view agents.');
      } else {
        setError('An unexpected error occurred while fetching agents.');
      }
    } finally {
      setLoading(false);
    }
  };
 
  return (
    <>
      <header className="transparent-header bg-white" >
        <AdminNavBar />
      </header>
      <div className="container mt-4" style={{ marginTop: '84px' }}>
        <h2 className="mb-4"><FontAwesomeIcon icon={faUsers} className="me-2" /> Agent Management</h2>
 
        {loading && <div className="spinner-border text-primary" role="status"><span className="visually-hidden">Loading...</span></div>}
        {error && <div className="alert alert-danger">{error}</div>}
 
        {!loading && !error && agents.length > 0 && (
          <div className="table-responsive">
            <table className="table table-striped table-bordered">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Contact Info</th>
                  <th className="text-center">Actions</th> {/* Center the actions column */}
                </tr>
              </thead>
              <tbody>
                {agents.map(agent => (
                  <tr key={agent.agentId}>
                    <td>{agent.name}</td>
                    <td>{agent.email}</td>
                    <td>{agent.contactInfo}</td>
                    <td className="text-center"> {/* Center the action buttons */}
                      <Link
                        to={`/agents/edit/${agent.agentId}`}
                        className="btn btn-sm btn-outline-primary me-2" // Use outline buttons for a cleaner look
                      >
                        <FontAwesomeIcon icon={faPencilAlt} className="me-1" /> Edit
                      </Link>
                      <Link
                        to={`/agents/view/${agent.agentId}`}
                        className="btn btn-sm btn-outline-info" // Use outline buttons for a cleaner look
                      >
                        <FontAwesomeIcon icon={faEye} className="me-1" /> View
                      </Link>
                      {/* Add delete button with potential authorization check */}
                      {/* <button className="btn btn-sm btn-outline-danger ms-2" onClick={() => handleDelete(agent.agentId)}>
                        <FontAwesomeIcon icon={faTrash} className="me-1" /> Delete
                      </button> */}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
 
        {!loading && !error && agents.length === 0 && (
          <div className="alert alert-info">No agents found.</div>
        )}
      </div>
    </>
  );
};
 
export default AgentManager;
 