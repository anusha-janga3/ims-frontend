 
// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import { useParams, Link, useNavigate } from 'react-router-dom';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faUser, faEnvelope, faPhone, faArrowLeft, faIdCard, faExclamationTriangle, faExclamationCircle } from '@fortawesome/free-solid-svg-icons';
// import AdminNavBar from '../layout/AdminNavBar';
 
// const API_BASE_URL = 'http://localhost:8084/api/v1/agents'; // Your backend API URL
 
// const ViewAgent = () => {
// const { agentId } = useParams();
// const navigate = useNavigate();
// const [agent, setAgent] = useState(null);
// const [error, setError] = useState('');
// const [loading, setLoading] = useState(true);
 
//   useEffect(() => {
//     fetchAgentDetailsWithSecurity();
//   }, [agentId]);
 
//   const fetchAgentDetailsWithSecurity = async () => {
//     setLoading(true);
//     setError('');
//     const token = localStorage.getItem('token');
 
//     try {
//         console.log("dfghjkl;rjoittiujjuejjfoi");
//       const response = await axios.get(`${API_BASE_URL}/${agentId}`, {
//         headers: {
//           'Authorization': `Bearer ${token}`,
//           'Content-Type': 'application/json',
//         },
//       });
//       console.log(token);
//       if (response.data && response.data.success && response.data.data) {
//         setAgent(response.data.data);
//         setError('');
//       } else {
//         setError(response.data?.message || `Agent with ID ${agentId} not found.`);
//       }
//     } catch (error) {
//       console.error('Error fetching agent details:', error);
//       if (error.response && error.response.status === 401) {
//         setError('Unauthorized. Please log in again.');
//         localStorage.removeItem('uuid');
//         localStorage.removeItem('token');
//         navigate('/login');
//       } else if (error.response && error.response.status === 403) {
//         setError('Forbidden. You do not have permission to view this agent.');
//       } else {
//         setError('An unexpected error occurred while fetching agent details.');
//       }
//     } finally {
//       setLoading(false);
//     }
//   };
 
//   if (loading) {
//     return (
//       <div className="d-flex justify-content-center align-items-center vh-100">
//         <div className="spinner-border text-primary" role="status">
//           <span className="visually-hidden">Loading...</span>
//         </div>
//       </div>
//     );
//   }
 
//   if (error) {
//     return (
//       <div className="container mt-4">
//         <div className="alert alert-danger d-flex align-items-center" role="alert">
//           <FontAwesomeIcon icon={faExclamationTriangle} className="me-3" />
//           <div>
//             {error} <Link to="/agents" className="alert-link">Go back to Agents</Link>
//           </div>
//         </div>
//       </div>
//     );
//   }
 
//   if (!agent) {
//     return (
//       <div className="container mt-4">
//         <div className="alert alert-warning d-flex align-items-center" role="alert">
//           <FontAwesomeIcon icon={faExclamationCircle} className="me-3" />
//           <div>
//             No agent details found. <Link to="/agents" className="alert-link">Go back to Agents</Link>
//           </div>
//         </div>
//       </div>
//     );
//   }
 
//   return (
//     <>
//      <header className="transparent-header">
//     <AdminNavBar />
//       </header>
//     <div className="container mt-3">
//       <div className="card shadow">
//         <div className="card-header bg-primary text-white d-flex justify-content-between align-items-center">
//           <h5 className="mb-0"><FontAwesomeIcon icon={faIdCard} className="me-2" /> Agent Profile</h5>
//           <Link to="/agents" className="btn btn-outline-light btn-sm">
//             <FontAwesomeIcon icon={faArrowLeft} className="me-2" /> Back to Agents
//           </Link>
//         </div>
//         <div className="card-body">
//           <ul className="list-group list-group-flush">
//             <li className="list-group-item d-flex align-items-center py-2">
//               <FontAwesomeIcon icon={faIdCard} className="me-3 text-info" size="lg" />
//               <strong>ID:</strong> <span className="ms-2">{agent.agentId}</span>
//             </li>
//             <li className="list-group-item d-flex align-items-center py-2">
//               <FontAwesomeIcon icon={faUser} className="me-3 text-info" size="lg" />
//               <strong>Name:</strong> <span className="ms-2">{agent.name}</span>
//             </li>
//             <li className="list-group-item d-flex align-items-center py-2">
//               <FontAwesomeIcon icon={faEnvelope} className="me-3 text-info" size="lg" />
//               <strong>Email:</strong> <span className="ms-2">{agent.email}</span>
//             </li>
//             <li className="list-group-item d-flex align-items-center py-2">
//               <FontAwesomeIcon icon={faPhone} className="me-3 text-info" size="lg" />
//               <strong>Contact Info:</strong> <span className="ms-2">{agent.contactInfo}</span>
//             </li>
//             {/* Add other agent details here based on your AgentDTO in similar list items */}
//           </ul>
//         </div>
//       </div>
//     </div>
//     </>
//   );
// };
 
// export default ViewAgent;


import React, { useState, useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser, faEnvelope, faPhone, faArrowLeft, faIdCard, faExclamationTriangle, faExclamationCircle } from '@fortawesome/free-solid-svg-icons';
import AdminNavBar from '../layout/AdminNavBar';

const API_BASE_URL = '/api/v1/agents'; // Your backend API URL

const ViewAgent = () => {
  const { agentId } = useParams();
  const navigate = useNavigate();
  const [agent, setAgent] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAgentDetailsWithSecurity();
  }, [agentId]); // <-- Dependency array ensures effect runs only when agentId changes

  const fetchAgentDetailsWithSecurity = async () => {
    setLoading(true);
    setError('');
    const token = localStorage.getItem('userToken');

    try {
      console.log("Fetching agent details for ID:", agentId);
      const response = await axios.get(`${API_BASE_URL}/${agentId}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
      console.log("Token:", token);
      console.log("Agent Details Response:", response.data);
      if (response.data && response.data.success && response.data.data) {
        setAgent(response.data.data);
        setError('');
      } else {
        setError(response.data?.message || `Agent with ID ${agentId} not found.`);
      }
    } catch (error) {
      console.error('Error fetching agent details:', error);
      if (error.response && error.response.status === 401) {
        setError('Unauthorized. Please log in again.');
        localStorage.removeItem('userId');
        localStorage.removeItem('userToken');
        navigate('/login');
      } else if (error.response && error.response.status === 403) {
        setError('Forbidden. You do not have permission to view this agent.');
      } else {
        setError('An unexpected error occurred while fetching agent details.');
      }
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center vh-100">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mt-4">
        <div className="alert alert-danger d-flex align-items-center" role="alert">
          <FontAwesomeIcon icon={faExclamationTriangle} className="me-3" />
          <div>
            {error} <Link to="/agents" className="alert-link">Go back to Agents</Link>
          </div>
        </div>
      </div>
    );
  }

  if (!agent) {
    return (
      <div className="container mt-4">
        <div className="alert alert-warning d-flex align-items-center" role="alert">
          <FontAwesomeIcon icon={faExclamationCircle} className="me-3" />
          <div>
            No agent details found. <Link to="/agents" className="alert-link">Go back to Agents</Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <header className="transparent-header">
        <AdminNavBar />
      </header>
      <div className="container mt-3">
        <div className="card shadow">
          <div className="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h5 className="mb-0"><FontAwesomeIcon icon={faIdCard} className="me-2" /> Agent Profile</h5>
            <Link to="/agents" className="btn btn-outline-light btn-sm">
              <FontAwesomeIcon icon={faArrowLeft} className="me-2" /> Back to Agents
            </Link>
          </div>
          <div className="card-body">
            <ul className="list-group list-group-flush">
              <li className="list-group-item d-flex align-items-center py-2">
                <FontAwesomeIcon icon={faIdCard} className="me-3 text-info" size="lg" />
                <strong>ID:</strong> <span className="ms-2">{agent.agentId}</span>
              </li>
              <li className="list-group-item d-flex align-items-center py-2">
                <FontAwesomeIcon icon={faUser} className="me-3 text-info" size="lg" />
                <strong>Name:</strong> <span className="ms-2">{agent.name}</span>
              </li>
              <li className="list-group-item d-flex align-items-center py-2">
                <FontAwesomeIcon icon={faEnvelope} className="me-3 text-info" size="lg" />
                <strong>Email:</strong> <span className="ms-2">{agent.email}</span>
              </li>
              <li className="list-group-item d-flex align-items-center py-2">
                <FontAwesomeIcon icon={faPhone} className="me-3 text-info" size="lg" />
                <strong>Contact Info:</strong> <span className="ms-2">{agent.contactInfo}</span>
              </li>
              {/* Add other agent details here based on your AgentDTO in similar list items */}
            </ul>
          </div>
        </div>
      </div>
    </>
  );
};

export default ViewAgent;
 