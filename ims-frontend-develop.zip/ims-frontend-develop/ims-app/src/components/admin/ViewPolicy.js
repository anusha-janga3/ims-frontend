import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useParams, Link, useNavigate } from 'react-router-dom';
import AdminNavBar from '../layout/AdminNavBar';
 
const API_BASE_URL = 'http://localhost:8082/api/v1/policies'; // Your backend API URL for policies
 
const ViewPolicy = () => {
  const { policyId } = useParams();
  const navigate = useNavigate();
  const [policy, setPolicy] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
 
  useEffect(() => {
    // Simulate setting UUID and token in local storage for testing
   fetchPolicyDetailsWithSecurity();
  }, [policyId]);
 
  const fetchPolicyDetailsWithSecurity = async () => {
    setLoading(true);
    setError('');
    const token = localStorage.getItem('userToken');
 
    try {
      const response = await fetch(`${API_BASE_URL}/${policyId}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
 
      if (response.ok) {
        const responseData = await response.json();
        if (responseData.success && responseData.data) {
          setPolicy(responseData.data);
          setError('');
        } else {
          setError(responseData.message || `Policy with ID ${policyId} not found.`);
        }
      } else if (response.status === 401) {
        setError('Unauthorized. Please log in again.');
        localStorage.removeItem('userId');
        localStorage.removeItem('userToken');
        navigate('/login');
      } else if (response.status === 403) {
        setError('Forbidden. You do not have permission to view this policy.');
      } else {
        setError('An unexpected error occurred while fetching policy details.');
      }
    } catch (error) {
      console.error('Error fetching policy details:', error);
      setError('An unexpected error occurred while fetching policy details.');
    } finally {
      setLoading(false);
    }
  };
 
  if (loading) {
    return (
      <div className="container mt-4">
        <h2>View Policy</h2>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }
 
  if (error) {
    return (
      <div className="container mt-4">
        <h2>View Policy</h2>
        <div className="alert alert-danger">
          {error} <Link to="/policies" className="alert-link">Go back to Policies</Link>
        </div>
      </div>
    );
  }
 
  if (!policy) {
    return (
      <div className="container mt-4">
        <h2>View Policy</h2>
        <div className="alert alert-warning">No policy details found. <Link to="/policies" className="alert-link">Go back to Policies</Link></div>
      </div>
    );
  }
 
  return (
    <>
     <header className="transparent-header">
    <AdminNavBar/>
      </header>
    <div className="container mt-4">
      <h2>View Policy Details</h2>
      <div className="card">
        <div className="card-body">
          <h5 className="card-title">Policy Information</h5>
          <ul className="list-group list-group-flush">
            <li className="list-group-item">
              <strong>ID:</strong> {policy.policyId}
            </li>
            <li className="list-group-item">
              <strong>Name:</strong> {policy.name}
            </li>
            <li className="list-group-item">
              <strong>Coverage Details:</strong> {policy.coverageDetails}
            </li>
            <li className="list-group-item">
              <strong>Validity Period (Years):</strong> {policy.validityPeriod}
            </li>
            <li className="list-group-item">
              <strong>Premium Amount:</strong> {policy.premiumAmount}
            </li>
            {/* Add other policy details here based on your PolicyDTO */}
          </ul>
          <Link to="/policies" className="btn btn-secondary mt-3">
            Back to Policies
          </Link>
        </div>
      </div>
    </div>
    </>
  );
};
 
export default ViewPolicy;
 
 
 
 