import { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link, useNavigate } from 'react-router-dom';
import AdminNavBar from '../layout/AdminNavBar';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEye, faPencilAlt } from '@fortawesome/free-solid-svg-icons'; // Import icons
 
const API_BASE_URL = 'http://localhost:8082/api/v1/policies'; // Your backend API URL for policies
 
const PolicyManager = () => {
  const [policies, setPolicies] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
 
  useEffect(() => {
    fetchPoliciesWithSecurity();
  }, []);
 
  const fetchPoliciesWithSecurity = async () => {
    setLoading(true);
    setError('');
    const token = localStorage.getItem('userToken');
 
    try {
      const response = await fetch(API_BASE_URL, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`, // Include the JWT token
          'Content-Type': 'application/json',
        },
      });
 
      if (response.ok) {
        const responseData = await response.json();
        if (responseData.success) {
          setPolicies(responseData.data);
          setError('');
        } else {
          setError(responseData.message || 'Failed to fetch policies.');
        }
      } else if (response.status === 401) {
        setError('Unauthorized. Please log in again.');
        localStorage.removeItem('userId');
        localStorage.removeItem('userToken');
        navigate('/login'); // Redirect to login if unauthorized
      } else if (response.status === 403) {
        setError('Forbidden. You do not have permission to view policies.');
      } else {
        setError('An unexpected error occurred while fetching policies.');
      }
    } catch (error) {
      console.error('Error fetching policies:', error);
      setError('An unexpected error occurred while fetching policies.');
    } finally {
      setLoading(false);
    }
  };
 
  return (
    <>
      <header className="transparent-header bg-white">
        <AdminNavBar />
      </header>
 
      <div className="container mt-4">
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h2 className="mb-0">Policy Management</h2>
          <Link to="/policies/create" className="btn btn-sm btn-success">
            Add Policy
          </Link>
        </div>
 
        {loading && (
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        )}
        {error && <div className="alert alert-danger">{error}</div>}
 
        {!loading && !error && policies.length > 0 && (
          <div className="table-responsive">
            <table className="table table-striped table-bordered">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Coverage Details</th>
                  <th>Validity Period (Years)</th>
                  <th>Premium Amount</th>
                  <th className="text-center">Actions</th>
                </tr>
              </thead>
              <tbody>
                {policies.map((policy) => (
                  <tr key={policy.policyId}>
                    <td>{policy.name}</td>
                    <td>{policy.coverageDetails}</td>
                    <td>{policy.validityPeriod}</td>
                    <td>{policy.premiumAmount}</td>
                    <td className="text-center">
                      <Link
                        to={`/policies/edit/${policy.policyId}`}
                        className="btn btn-sm btn-outline-primary me-2" // Edit button
                      >
                        <FontAwesomeIcon icon={faPencilAlt} className="me-1" /> Edit
                      </Link>
                      <Link
                        to={`/policies/view/${policy.policyId}`}
                        className="btn btn-sm btn-outline-info" // View button
                      >
                        <FontAwesomeIcon icon={faEye} className="me-1" /> View
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
 
        {!loading && !error && policies.length === 0 && (
          <div className="alert alert-info">No policies found.</div>
        )}
      </div>
    </>
  );
};
 
export default PolicyManager;
 