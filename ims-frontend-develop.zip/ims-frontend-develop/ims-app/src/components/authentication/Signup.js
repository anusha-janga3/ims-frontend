import React, { useState } from 'react';
import './Signup.css';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
 
const Signup = () => {
  const [role, setRole] = useState('AGENT');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    address: '',
    contactInfo: '',
    adminId: 'a2b73861-957f-4a00-a00a-539d1ccde94d',
  });
  const [errors, setErrors] = useState({});
  const [generalError, setGeneralError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const navigate = useNavigate();
 
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    setErrors({ ...errors, [name]: '' });
    setGeneralError('');
  };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
    const url =
      role === 'AGENT'
        ? 'http://localhost:8086/api/v1/users/register-agent'
        : 'http://localhost:8086/api/v1/users/register-customer';
    const payload =
      role === 'AGENT'
        ? { name: formData.name, email: formData.email, password: formData.password, contactInfo: formData.contactInfo, adminId: formData.adminId || 'a23b020f-406d-4cff-b858-0ea4b93cebe1' }
        : { name: formData.name, email: formData.email, password: formData.password, phone: formData.phone, address: formData.address };
 
    try {
      const response = await axios.post(url, payload);
      setSuccessMessage('Registration Successful!');
      setErrors({});
      setGeneralError('');
      console.log('Success:', response.data);
      setTimeout(() => {
        navigate('/Login'); // Navigate to the login page
      }, 2000);
    } catch (err) {
      console.error('Registration Failed:', err);
      console.error('Error Response:', err.response);
      console.error('Error Response Data:', err.response?.data);
      const backendErrors = err.response?.data || {};
      console.error('Backend Errors:', backendErrors);
      setErrors(backendErrors);
      setGeneralError(err.response?.data?.message || 'Registration failed. Please try again.');
      setSuccessMessage('');
    }
  };
 
  return (
    <div className="sign-up">
      <main className="form-signin w-100 m-auto">
        <form onSubmit={handleSubmit}>
          <h1 className="h3 mb-3 fw-normal text-center">
            Register as {role}
          </h1>
 
          {/* Role Toggle Buttons */}
          <ul
            className="nav nav-pills nav-fill gap-2 p-1 small bg-secondary rounded-5 shadow-sm"
            id="pillNav2"
            role="tablist"
            style={{
              '--bs-nav-link-color': 'var(--bs-white)',
              '--bs-nav-pills-link-active-color': 'var(--bs-secondary)',
              '--bs-nav-pills-link-active-bg': 'var(--bs-white)',
            }}
          >
            <li className="nav-item" role="presentation">
              <button
                type="button"
                className={`nav-link ${role === 'AGENT' ? 'active' : ''} rounded-5`}
                onClick={() => setRole('AGENT')}
                aria-selected={role === 'AGENT'}
              >
                Agent
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                type="button"
                className={`nav-link ${role === 'CUSTOMER' ? 'active' : ''} rounded-5`}
                onClick={() => setRole('CUSTOMER')}
                aria-selected={role === 'CUSTOMER'}
              >
                Customer
              </button>
            </li>
          </ul>
 
          <br />
 
          {/* Form Fields */}
 
          {/* Name */}
          <div className="col-md-6 w-100 mb-1">
            <div className="input-group">
              {/* <span className="input-group-text" id="basic-addon1">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-person-fill" viewBox="0 0 16 16">
                  <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6"></path>
                </svg>
              </span> */}
              <input type="text"
                name="name"
                className={`form-control ${errors.name ? 'is-invalid' : ''}`}
                id="floatingName"
                placeholder="Full Name"
                value={formData.name}
                onChange={handleInputChange}
                required aria-label="Input group example" aria-describedby="basic-addon1"/>
              {errors.name && <div className="invalid-feedback">{errors.name}</div>}
            </div>
          </div>
 
          {/* Email */}
          <div className="col-md-6 w-100 mb-1">
            <div className="input-group">
              {/* <span className="input-group-text" id="basic-addon1">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-envelope" viewBox="0 0 16 16">
                  <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1zm13 2.383-4.708 2.825L15 11.105zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741M1 11.105l4.708-2.897L1 5.383z"></path>
                </svg>
              </span> */}
              <input type="email"
                name="email"
                className={`form-control ${errors.email ? 'is-invalid' : ''}`}
                id="floatingEmail"
                placeholder="Email"
                value={formData.email}
                onChange={handleInputChange}
                required aria-label="Input group example" aria-describedby="basic-addon1"/>
              {errors.email && <div className="invalid-feedback">{errors.email}</div>}
            </div>
          </div>
 
          {/* Password */}
          <div className="col-md-6 w-100 mb-1">
            <div className="input-group">
              {/* <span className="input-group-text" id="basic-addon1">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-lock" viewBox="0 0 16 16">
                  <path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2m3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2M5 8h6a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1"></path>
                </svg>
              </span> */}
              <input type="password"
                name="password"
                className={`form-control ${errors.password ? 'is-invalid' : ''}`}
                id="floatingPassword"
                placeholder="Password"
                value={formData.password}
                onChange={handleInputChange}
                required aria-label="Input group example" aria-describedby="basic-addon1"/>
              {errors.password && <div className="invalid-feedback">{errors.password}</div>}
            </div>
          </div>
 
          {role === 'CUSTOMER' && (
            <>
 
              {/* Mobile Number */}
              <div className="col-md-6 w-100 mb-1">
                <div className="input-group">
                  {/* <span className="input-group-text" id="basic-addon1">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-phone" viewBox="0 0 16 16">
                      <path d="M11 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1zM5 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2z"></path>
                      <path d="M8 14a1 1 0 1 0 0-2 1 1 0 0 0 0 2"></path>
                    </svg>
                  </span> */}
                  <input type="tel"
                    name="phone"
                    className={`form-control ${errors.phone ? 'is-invalid' : ''}`}
                    id="floatingPhone"
                    placeholder="Phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    required aria-label="Input group example" aria-describedby="basic-addon1"/>
                  {errors.phone && <div className="invalid-feedback">{errors.phone}</div>}
                </div>
              </div>
 
              {/* Address */}
              <div className="col-md-6 w-100 mb-1">
                <div className="input-group">
                  {/* <span className="input-group-text" id="basic-addon1">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-geo-alt" viewBox="0 0 16 16">
                      <path d="M12.166 8.94c-.524 1.062-1.234 2.12-1.96 3.07A32 32 0 0 1 8 14.58a32 32 0 0 1-2.206-2.57c-.726-.95-1.436-2.008-1.96-3.07C3.304 7.867 3 6.862 3 6a5 5 0 0 1 10 0c0 .862-.305 1.867-.834 2.94M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10"/>
                      <path d="M8 8a2 2 0 1 1 0-4 2 2 0 0 1 0 4m0 1a3 3 0 1 0 0-6 3 3 0 0 0 0 6"/>
                    </svg>
                  </span> */}
                  <input type="text"
                    name="address"
                    className={`form-control ${errors.address ? 'is-invalid' : ''}`}
                    id="floatingAddress"
                    placeholder="Address"
                    value={formData.address}
                    onChange={handleInputChange}
                    required aria-label="Input group example" aria-describedby="basic-addon1"/>
                  {errors.address && <div className="invalid-feedback">{errors.address}</div>}
                </div>
              </div>
            </>
          )}
 
          {role === 'AGENT' && (
            <div className="col-md-6 w-100 mb-1">
              <div className="input-group">
                {/* <span className="input-group-text" id="basic-addon1">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-phone" viewBox="0 0 16 16">
                    <path d="M11 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1zM5 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2z"></path>
                    <path d="M8 14a1 1 0 1 0 0-2 1 1 0 0 0 0 2"></path>
                  </svg>
                </span> */}
                <input type="text"
                  name="contactInfo"
                  className={`form-control ${errors.contactInfo ? 'is-invalid' : ''}`}
                  id="floatingContactInfo"
                  placeholder="Contact Info"
                  value={formData.contactInfo}
                  onChange={handleInputChange}
                  required aria-label="Input group example" aria-describedby="basic-addon1"/>
                {errors.contactInfo && <div className="invalid-feedback">{errors.contactInfo}</div>}
              </div>
            </div>
          )}
 
          <br />
 
          {/* Submit Button */}
          <button className="btn btn-secondary w-100 py-2 mb-2" type="submit">
            Register
          </button>
 
          {/* Render general error message */}
          {generalError && <p className="text-danger text-center">{generalError}</p>}
 
          {/* Render success message */}
          {!generalError && successMessage && <p className="text-success text-center">{successMessage}</p>}
 
          <p className="text-center">
            Already have an account?{' '}
            <Link to="/Login"  className="custom-signup-link">
              Login
            </Link>
          </p>
        </form>
      </main>
    </div>
  );
};
 
export default Signup;
 