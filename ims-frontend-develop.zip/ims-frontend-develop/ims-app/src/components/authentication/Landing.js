import React from 'react';
import './Landing.css'; // Importing the CSS file for styling
import { useNavigate } from 'react-router-dom'; // For navigation

const Landing = () => {
  const navigate = useNavigate(); // Initialize the navigation hook

  return (
    <div className="landing-page">
      {/* Background and content */}
      <div className="landing-content text-start">
        <h1>Welcome to Our Website</h1>
        <p>Manage your insurance seamlessly with our platform.</p>
        <div className="landing-buttons">
          {/* Login Button */}
          <button className="btn btn-primary" onClick={() => navigate('/Login')}>
            Login
          </button>

          {/* Signup Button */}
          <button className="btn btn-secondary" onClick={() => navigate('/SignUp')}>
            Signup
          </button>
        </div>
      </div>
    </div>
  );
};

export default Landing;
