import './Login.css';
import { Link, useNavigate } from 'react-router-dom'; // Import useNavigate
import React, { useState, useEffect } from 'react';
import axios from 'axios';
 
const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('ADMIN'); // Default role is ADMIN
  const [error, setError] = useState(''); // Unified error state
  const navigate = useNavigate(); // Initialize navigate
 
  useEffect(() => {
    console.log("Clearing logout flag on Login page load.");
    sessionStorage.removeItem('logoutFlag'); // ✅ Clears flag after redirect
  }, []);
 
 
 
  const validateForm = () => {
    // Email validation using regex
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email) return 'Email is required.';
    if (!emailRegex.test(email)) return 'Please enter a valid email address.';
 
    // Password validation: Minimum length 6 characters
    if (!password) return 'Password is required.';
    if (password.length < 6) return 'Password must be at least 6 characters long.';
 
    // If all validations pass
    return '';
  };
 
  const handleLogin = async (event) => {
    event.preventDefault(); // Prevent form submission
 
    // Validate the form inputs
    const formError = validateForm();
    if (formError) {
      setError(formError); // Set the form validation error
      return; // Stop execution if there's a validation error
    }
 
    try {
      // Call the login API
      const response = await axios.post('http://localhost:8086/api/v1/users/login', {
        email,
        password,
        role,
      });
 
      console.log('Login Successful:', response.data);
 
      // Store the token and uuid in local storage
      const { uuid, token } = response.data.data;
      localStorage.setItem('userToken', token); // Save the token
      localStorage.setItem('userId', uuid); // Save the UUID
      localStorage.setItem('userRole', role); // Save the role
      console.log('Token, UUID, and Role stored in local storage.');
 
      // Navigate to the specific dashboard based on the role
      if (role === 'ADMIN') {
        navigate('/admindashboard');
      } else if (role === 'AGENT') {
        navigate('/agentDashboard');
      } else if (role === 'CUSTOMER') {
        navigate('/dashboard');
      }
    } catch (err) {
      console.error('Login Failed:', err.response?.data || err.message);
      // Display only the backend error (overrides previous errors)
      setError(err.response?.data?.message || 'Login failed. Please try again.');
    }
  };
 
  return (
    <div className="sign-in">
      <main className="form-signin w-100">
        <form onSubmit={handleLogin}>
          <h1 className="h3 mb-3 fw-normal text-center">Please sign in</h1>
 
          {/* Role Selection Buttons */}
          <ul
            className="nav nav-pills nav-fill gap-2 p-1 small bg-secondary rounded-5 shadow-sm"
            id="pillNav2"
            role="tablist"
            style={{
              '--bs-nav-link-color': 'var(--bs-white)',
              '--bs-nav-pills-link-active-color': 'var(--bs-secondary)',
              '--bs-nav-pills-link-active-bg': 'var(--bs-white)',
            }}
          >
            <li className="nav-item" role="presentation">
              <button
                type="button"
                className={`nav-link rounded-5 ${role === 'ADMIN' ? 'active' : ''}`}
                onClick={() => setRole('ADMIN')}
              >
                Admin
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                type="button"
                className={`nav-link rounded-5 ${role === 'AGENT' ? 'active' : ''}`}
                onClick={() => setRole('AGENT')}
              >
                Agent
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                type="button"
                className={`nav-link rounded-5 ${role === 'CUSTOMER' ? 'active' : ''}`}
                onClick={() => setRole('CUSTOMER')}
              >
                Customer
              </button>
            </li>
          </ul>
 
          <br />
          {/* Email Input */}
          <div className="input-fields col-md-6 w-100 mb-1">
              <div className="input-group">
                {/* <span className="input-group-text" id="basic-addon1">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope" viewBox="0 0 16 16">
  <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1zm13 2.383-4.708 2.825L15 11.105zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741M1 11.105l4.708-2.897L1 5.383z"></path>
</svg>
                </span> */}
                <input type="email"
              className="form-control"
              id="floatingInput"
              placeholder="name@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)} aria-label="Input group example" aria-describedby="basic-addon1"/>
              </div>
            </div>
 
          {/* Password Input */}
          <div className="col-md-6 w-100">
              <div className="input-group">
                {/* <span className="input-group-text" id="basic-addon1">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-lock" viewBox="0 0 16 16">
  <path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2m3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2M5 8h6a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1"></path>
</svg>
                </span> */}
                <input type="password"
              className="form-control"
              id="floatingPassword"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)} aria-describedby="basic-addon1"/>
              </div>
            </div>
 
          <br />
          {/* Unified Error Message */}
          {error && <p className="text-danger text-center">{error}</p>}
 
          <button className="btn btn-secondary w-100 py-2 mb-2" type="submit">
            Login
          </button>
          <p className='text-center'>
            Don't have an account?{' '}
            <Link to="/SignUp" className="custom-login-link">
              SignUp
            </Link>
          </p>
        </form>
      </main>
    </div>
  );
};
 
export default Login;
 
 