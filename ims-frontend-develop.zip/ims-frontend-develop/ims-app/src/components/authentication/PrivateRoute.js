// import React from 'react';
// import { Navigate } from 'react-router-dom';

// const PrivateRoute = ({ children, allowedRole }) => {
//   // Get token and role from localStorage
//   const token = localStorage.getItem('userToken');
//   const userRole = localStorage.getItem('userRole');

//   // If no token or the role does not match, redirect to Login with a warning message
//   if (!token || userRole !== allowedRole) {
//     // Customize alert message based on allowedRole
//     const roleMessage =
//       allowedRole === 'ADMIN'
//         ? 'Admin'
//         : allowedRole === 'AGENT'
//         ? 'Agent'
//         : allowedRole === 'CUSTOMER'
//         ? 'Customer'
//         : 'User'; // Default fallback for unknown roles

//     alert(`Please login as a ${roleMessage} to access this page.`);
//     return <Navigate to="/Login" />;
//   }

//   // Otherwise, render the children (protected content)
//   return children;
// };

// export default PrivateRoute;
import React from 'react';
import { Navigate } from 'react-router-dom';
 
const PrivateRoute = ({ children, allowedRole }) => {
  const token = localStorage.getItem('userToken');
  const userRole = localStorage.getItem('userRole');
  const logoutFlag = sessionStorage.getItem('logoutFlag'); // Check logout flag
 
  // ✅ Prevent alert when navigating due to logout
  if (logoutFlag) {
    console.log("Redirecting due to logout, suppressing alert.");
    return <Navigate to="/Login" />;
  }
 
  // ✅ FIX: Adjust logic to prevent unwanted alerts
  if ((!token && !logoutFlag) || (userRole !== allowedRole && !logoutFlag)) {
    const roleMessage = allowedRole === 'ADMIN' ? 'Admin' : allowedRole === 'AGENT' ? 'Agent' : allowedRole === 'CUSTOMER' ? 'Customer' : 'User';
   
    alert(`Please login as a ${roleMessage} to access this page.`);
    return <Navigate to="/Login" />;
  }
 
  return children;
};
 
export default PrivateRoute;
 
 