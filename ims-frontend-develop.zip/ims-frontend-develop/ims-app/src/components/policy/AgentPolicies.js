// import React, { useState, useEffect } from "react";
// import axios from "axios";
// import PolicyDetails from "./PolicyDetails";
// import "./CustomerPolicies.css"; // Import the CSS file

// const CustomerPolicies = () => {
//   const [policyDetails, setPolicyDetails] = useState(null);
//   const [error, setError] = useState("");

//   const token ="eyJhbGciOiJIUzI1NiJ9.eyJyb2xlIjoiQ1VTVE9NRVIiLCJzdWIiOiJzaXJpQGdtYWlsLmNvbSIsImlhdCI6MTc0NDM0NTc0NSwiZXhwIjoxNzQ0MzQ5MzQ1fQ.oCwdpRUmlM28a3yqtgIxPUfcIBg4v2eod8WVzfp_BjQ";

//   const fetchCustomerPolicyDetails = async (customerId) => {
//     try {
//       const customerResponse = await axios.get(
//         `/api/v1/policies/customer/${customerId}`,
//         {
//           headers: { Authorization: `Bearer ${token}` },
//         }
//       );
//       console.log("Customer Response:", customerResponse.data); // Debugging

//       const { policyId, purchaseDate } = customerResponse.data;

//       if (!policyId) {
//         throw new Error("Policy ID is missing in the customer response.");
//       }

//       const policyResponse = await axios.get(`/api/v1/policies/${policyId}`, {
//         headers: { Authorization: `Bearer ${token}` },
//       });

//       const mergedPolicyDetails = {
//         ...policyResponse.data,
//         purchaseDate, // Add purchaseDate to policy details
//       };

//       setPolicyDetails(mergedPolicyDetails);
//     } catch (err) {
//       console.error(err); // Log the error for debugging
//       setError("Failed to fetch policy details.");
//     }
//   };

//   useEffect(() => {
//     const customerId = "96a64c09-7e23-4075-8d64-1e6d4d75396b"; // Replace with actual customer ID
//     fetchCustomerPolicyDetails(customerId);
//   }, []);

//   return (
//     <div className="container">
//       <h1 className="title">Policy Details</h1>
//       {error && <p className="error">{error}</p>}
//       {policyDetails ? (
//         <PolicyDetails policyDetails={policyDetails} />
//       ) : (
//         <p>Loading policy details...</p>
//       )}
//     </div>
//   );
// };

// export default CustomerPolicies;

import React, { useState, useEffect } from "react";
import axios from "axios";
import PolicyDetails from "./PolicyDetails";
import "./CustomerPolicies.css"; // Import the CSS file
import CustomerNavbar from "../layout/CustomerNavbar";
import AgentNav from "../layout/AgentNavBar";

const AgentPolicies = () => {
  const [policies, setPolicies] = useState([]); // State to hold details of multiple policies
  const [error, setError] = useState("");

  const token = localStorage.getItem('userToken');
    

  const fetchCustomerPolicyDetails = async (agentId) => {
    try {
      const customerResponse = await axios.get(
        `/api/v1/policies/agent/${agentId}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      console.log("Customer Response:", customerResponse.data); // Debugging

      const customerPolicies = customerResponse.data.data; // Extract array from the response structure
      
      // Fetch details for each policy
      const policyDetailsArray = await Promise.all(
        customerPolicies.map(async (customerPolicy) => {
          const { policyId, purchaseDate } = customerPolicy;

          if (!policyId) {
            console.error("Policy ID is missing in customer response.");
            return null; // Skip if policyId is missing
          }

          // Fetch individual policy details using policyId
          const policyResponse = await axios.get(`/api/v1/policies/${policyId}`, {
            headers: { Authorization: `Bearer ${token}` },
          });

          // Merge purchaseDate into the policy details
          return {
            ...policyResponse.data.data,
            purchaseDate, // Add purchaseDate from customer response
          };
        })
      );

      setPolicies(policyDetailsArray.filter((policy) => policy)); // Filter out null values
    } catch (err) {

      if (error.response && error.response.status === 401) {
        setError('Unauthorized. Please log in again.');
        // Optionally redirect to login
    } else if (error.response && error.response.status === 403) {
        setError('Forbidden. You do not have permission to view this data.');
    }
    else if (error.response && error.response.status === 404) {
        setError('No Customers Assigned');
    } else {
        setError('An unexpected error occurred while fetching customer data.');
    }
      console.error(err); // Log the error for debugging
    }
  };

  useEffect(() => {
    const agentId = localStorage.getItem('userId'); // Replace with actual customer ID
    fetchCustomerPolicyDetails(agentId);
  }, []);

  return (
    <>
    <header className="transparent-header">
                <AgentNav />
            </header>
    <div className="container"> 
      <h1 className="title">Your Policies</h1>
      {error && <p className="error">{error}</p>}
      {policies.length > 0 ? (
        <div className="policies-grid">
          {policies.map((policyDetails, index) => (
            <PolicyDetails key={index} policyDetails={policyDetails} />
          ))}
        </div>
      ) : (
        <p>Loading policy details...</p>
      )}
    </div>
    </>
  );
};

export default AgentPolicies;

