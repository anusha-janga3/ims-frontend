
// import React, { useState, useEffect } from "react";
// import axios from "axios";
// import PolicyDetails from "./PolicyDetails";
// import "./CustomerPolicies.css"; // Import the CSS file
// import CustomerNavbar from "../layout/CustomerNavbar";

// const CustomerPolicies = () => {
//   const [policies, setPolicies] = useState([]); // State to hold details of multiple policies
//   const [error, setError] = useState("");

//   const token =localStorage.getItem('userToken')
    

//   const fetchCustomerPolicyDetails = async (customerId) => {
//     try {
//       const customerResponse = await axios.get(
//         `/api/v1/policies/customer/${customerId}`,
//         {
//           headers: { Authorization: `Bearer ${token}` },
//         }
//       );
//       console.log("Customer Response:", customerResponse.data); // Debugging

//       const customerPolicies = customerResponse.data.data; // Extract array from the response structure
      
//       // Fetch details for each policy
//       const policyDetailsArray = await Promise.all(
//         customerPolicies.map(async (customerPolicy) => {
//           const { policyId, agentId , purchaseDate } = customerPolicy;

//           if (!policyId) {
//             console.error("Policy ID is missing in customer response.");
//             return null; // Skip if policyId is missing
//           }

//           // Fetch individual policy details using policyId
//           const policyResponse = await axios.get(`/api/v1/policies/${policyId}`, {
//             headers: { Authorization: `Bearer ${token}` },
//           });

//           // Merge purchaseDate into the policy details
//           return {
//             ...policyResponse.data.data,
//             agentId,
//             purchaseDate // Add purchaseDate from customer response
//           };
//         })
//       );

//       setPolicies(policyDetailsArray.filter((policy) => policy)); // Filter out null values
//     } catch (err) {
//       console.error(err); // Log the error for debugging
//       setError("Failed to fetch policies.");
//     }
//   };

//   useEffect(() => {
//     const customerId = localStorage.getItem('userId') // Replace with actual customer ID
//     fetchCustomerPolicyDetails(customerId);
//   }, []);

//   return (
//     <>
//    <header className="transparent-header">
//       <CustomerNavbar />
//       </header>
//     <div className="container"> 
//       <h1 className="title">Your Policies</h1>
//       {error && <p className="error">{error}</p>}
//       {policies.length > 0 ? (
//         <div className="policies-grid">
//           {policies.map((policyDetails, index) => (
//             <PolicyDetails key={index} policyDetails={policyDetails} />
//           ))}
//         </div>
//       ) : (
//         <p>Loading policy details...</p>
//       )}
//     </div>
//     </>
    
//   );
// };

// export default CustomerPolicies;

import React, { useState, useEffect } from "react";
import axios from "axios";
import PolicyDetails from "./PolicyDetails";
import "./CustomerPolicies.css"; // Import the CSS file
import CustomerNavbar from "../layout/CustomerNavbar";

const CustomerPolicies = () => {
  const [policies, setPolicies] = useState([]); // State to hold details of multiple policies
  const [error, setError] = useState("");

  const token = localStorage.getItem('userToken');

  const fetchAgentDetails = async (agentId) => {
    try {
      const agentResponse = await axios.get(`/api/v1/agents/${agentId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      return agentResponse.data.data;
    } catch (err) {
      console.error(`Failed to fetch agent details for agentId: ${agentId}`, err);
      return null;
    }
  };

  const fetchCustomerPolicyDetails = async (customerId) => {
    try {
      const customerResponse = await axios.get(
        `/api/v1/policies/customer/${customerId}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      console.log("Customer Response:", customerResponse.data); // Debugging

      const customerPolicies = customerResponse.data.data; // Extract array from the response structure
      
      // Fetch details for each policy
      const policyDetailsArray = await Promise.all(
        customerPolicies.map(async (customerPolicy) => {
          const { policyId, agentId, purchaseDate } = customerPolicy;

          if (!policyId) {
            console.error("Policy ID is missing in customer response.");
            return null; // Skip if policyId is missing
          }

          // Fetch individual policy details using policyId
          const policyResponse = await axios.get(`/api/v1/policies/${policyId}`, {
            headers: { Authorization: `Bearer ${token}` },
          });

          // Fetch agent details using agentId
          const agentDetails = await fetchAgentDetails(agentId);

          // Merge purchaseDate and agent details into the policy details
          return {
            ...policyResponse.data.data,
            agentId,
            purchaseDate, // Add purchaseDate from customer response
            agentName: agentDetails ? agentDetails.name : "Unknown",
            agentContactInfo: agentDetails ? agentDetails.contactInfo : "Unknown"
          };
        })
      );

      setPolicies(policyDetailsArray.filter((policy) => policy)); // Filter out null values
    } catch (err) {
      console.error(err); // Log the error for debugging
      setError("Failed to fetch policies.");
    }
  };

  useEffect(() => {
    const customerId = localStorage.getItem('userId'); // Replace with actual customer ID
    fetchCustomerPolicyDetails(customerId);
  }, []);

  return (
    <>
      <header className="transparent-header bg-white">
        <CustomerNavbar />
      </header>
      <div className="container">
        <h1 className="title">Your Policies</h1>
        {error && <p className="error">{error}</p>}
        {policies.length > 0 ? (
          <div className="policies-grid">
            {policies.map((policyDetails, index) => (
              <PolicyDetails key={index} policyDetails={policyDetails} />
            ))}
          </div>
        ) : (
          <p>Loading policy details...</p>
        )}
      </div>
    </>
  );
};

export default CustomerPolicies;
