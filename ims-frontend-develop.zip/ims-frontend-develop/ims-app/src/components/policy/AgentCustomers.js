import React, { useState, useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import CustomerDetails from './CustomerDetails'; // Assuming you have this component
import AgentNavBar from '../layout/AgentNavBar'; // Assuming you have an agent-specific navbar

const API_BASE_URL = '/api/v1'; // Your backend API base URL

const AgentCustomers = () => {
    const [customers, setCustomers] = useState([]);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(true);
    const agentId = localStorage.getItem('userId'); // Assuming agentId is stored here

    useEffect(() => {
        if (agentId) {
            fetchAgentCustomers();
        } else {
            setError('Agent ID not found. Please log in as an agent.');
            setLoading(false);
        }
    }, [agentId]);

    const fetchAgentCustomers = async () => {
        setLoading(true);
        setError('');
        const token = localStorage.getItem('userToken'); // Assuming you store the user token

        try {
            const policiesResponse = await axios.get(`${API_BASE_URL}/policies/agent/${agentId}`, {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json',
                },
            });

            if (policiesResponse.data && policiesResponse.data.success && Array.isArray(policiesResponse.data.data)) {
                const policyCustomers = policiesResponse.data.data.map(policy => policy.customerId).filter(Boolean); // Extract customerIds and filter out any null/undefined

                if (policyCustomers.length > 0) {
                    // Fetch details for each unique customer
                    const uniqueCustomerIds = [...new Set(policyCustomers)];
                    const customerDetailsPromises = uniqueCustomerIds.map(customerId =>
                        axios.get(`${API_BASE_URL}/customers/${customerId}`, {
                            headers: {
                                'Authorization': `Bearer ${token}`,
                                'Content-Type': 'application/json',
                            },
                        })
                    );

                    const customerDetailsResponses = await Promise.all(customerDetailsPromises);
                    const fetchedCustomers = customerDetailsResponses.map(res => res.data?.data).filter(Boolean);
                    setCustomers(fetchedCustomers);
                } else {
                    setCustomers([]); // No customers associated with this agent
                }
            } else {
                setError(policiesResponse.data?.message || 'Failed to fetch policies for this agent.');
                setCustomers([]);
            }
        } catch (error) {
            console.error('Error fetching agent customers:', error);
            if (error.response && error.response.status === 401) {
                setError('Unauthorized. Please log in again.');
                // Optionally redirect to login
            } else if (error.response && error.response.status === 403) {
                setError('Forbidden. You do not have permission to view this data.');
            }
            else if (error.response && error.response.status === 404) {
                setError('no customers');
            } else {
                setError('An unexpected error occurred while fetching customer data.');
            }
            setCustomers([]);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return <div className="text-center">Loading customers...</div>;
    }

    if (error) {
        return <div className="alert alert-danger">{error}</div>;
    }

    return (
        <>
            <header className="transparent-header">
                <AgentNavBar />
            </header>
            <div className="container mt-4">
                <h2 className='title'>Customers Assigned </h2>
                {customers.length > 0 ? (
                    <div className="row row-cols-1 row-cols-md-3 g-4">
                        {customers.map(customer => (
                            <div className="col" key={customer.customerId}>
                                <CustomerDetails customer={customer} />
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="alert alert-info">No customers are currently assigned to this agent.</div>
                )}
            </div>
        </>
    );
};

export default AgentCustomers;