import React from 'react';
import './ClaimDetails.css'; // Import the CSS file

function ClaimDetails({ policyDetails, isPopupOpen, onClose }) {
  if (!isPopupOpen || !policyDetails) {
    return null;
  }

  return (
    <div className="popup-overlay" onClick={onClose}> {/* Close on overlay click */}
      <div className="popup-box" onClick={(e) => e.stopPropagation()}> {/* Prevent closing when clicking inside */}
        <button onClick={onClose} className="close-button">
          <span aria-hidden="true">&times;</span>
        </button>
        <h3>Policy Details</h3>
        {/* {policyDetails.policyId && <p>Policy ID: {policyDetails.policyId}</p>} */}
        {policyDetails.name && <p>Policy Name: {policyDetails.name}</p>}
        {policyDetails.coverageDetails && <p>Coverage Details: {policyDetails.coverageDetails}</p>}
        {policyDetails.premiumAmount && <p>Premium: {policyDetails.premiumAmount}</p>}
        {policyDetails.validityPeriod && <p>Validity Period: {policyDetails.validityPeriod}</p>}
        {/* Add more policy details as needed */}
      </div>
    </div>
  );
}

export default ClaimDetails;