// import React, { useEffect, useState, useMemo } from 'react';
// import axios from 'axios';
// import './ClaimListPage.css';
// import ClaimDetails from './ClaimDetails'; // Import the ClaimDetailsPage component

// const ClaimListPage = () => {
//   const [claims, setClaims] = useState([]);
//   const customerId = 'e4c4d9bb-df60-47e4-bf4a-2075805d668d'; // Hardcoded for testing
//   const [policyDetails, setPolicyDetails] = useState({}); // Store policy details by policyId
//   const [selectedPolicyId, setSelectedPolicyId] = useState(null);
//   const [statusFilter, setStatusFilter] = useState('');
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState('');

//   const claimStatuses = ['UnderReview', 'Approved', 'Rejected', '']; // Available filter options

//   useEffect(() => {
//     const fetchClaims = async () => {
//       setLoading(true);
//       setError('');
//       try {
//         const response = await axios.get(`/api/v1/claim/${customerId}/customer-claims`);
//         setClaims(response.data.data);
//         // Pre-fetch policy details for all policies in the fetched claims
//         const uniquePolicyIds = [...new Set(response.data.data.map(claim => claim.policyId).filter(Boolean))];
//         uniquePolicyIds.forEach(policyId => fetchPolicyDetails(policyId));
//       } catch (err) {
//         console.error('Error fetching claims:', err);
//         setError('Failed to fetch claims.');
//         setClaims([]);
//       } finally {
//         setLoading(false);
//       }
//     };

//     const fetchPolicyDetails = async (policyId) => {
//       try {
//         const response = await axios.get(`http://localhost:8082/api/v1/policies/${policyId}`);
//         setPolicyDetails(prevDetails => ({
//           ...prevDetails,
//           [policyId]: response.data.data,
//         }));
//       } catch (err) {
//         console.error(`Error fetching policy details for ID ${policyId}:`, err);
//         setPolicyDetails(prevDetails => ({
//           ...prevDetails,
//           [policyId]: { name: 'Policy Details Not Found' },
//         }));
//       }
//     };

//     fetchClaims();
//   }, [customerId]);

//   const handleViewDetailsClick = (policyId) => {
//     setSelectedPolicyId(policyId);
//   };

//   const closePopup = () => {
//     setSelectedPolicyId(null);
//   };

//   const handleStatusFilterChange = (event) => {
//     setStatusFilter(event.target.value);
//   };

//   const getStatusButtonStyle = (status) => {
//     const lowerCaseStatus = status.toLowerCase();
//     if (lowerCaseStatus === 'underreview') {
//       return 'status-button yellow';
//     } else if (lowerCaseStatus === 'rejected') {
//       return 'status-button red';
//     } else if (lowerCaseStatus === 'approved') {
//       return 'status-button green';
//     }
//     return 'status-button';
//   };

//   // Filter the claims based on the selected status
//   const filteredClaims = useMemo(() => {
//     if (!statusFilter) {
//       return claims;
//     }
//     return claims.filter(claim =>
//       claim.status.toLowerCase() === statusFilter.toLowerCase()
//     );
//   }, [claims, statusFilter]);

//   const selectedPolicy = selectedPolicyId ? policyDetails[selectedPolicyId] : null;
//   const selectedClaim = claims.find(claim => claim.policyId === selectedPolicyId);

//   return (
//     <div className="claim-cards-container">
//       <h2 className="page-title">Your Claims</h2>

//       <div className="filter-section">
//         <label htmlFor="statusFilter" className="filter-label">Filter by Status:</label>
//         <select
//           id="statusFilter"
//           className="filter-dropdown"
//           value={statusFilter}
//           onChange={handleStatusFilterChange}
//         >
//           <option value="">All Statuses</option>
//           {claimStatuses
//             .filter(status => status !== '')
//             .map((status) => (
//               <option key={status.toLowerCase()} value={status.toLowerCase()}>
//                 {status}
//               </option>
//             ))}
//         </select>
//       </div>

//       {loading && <p className="loading-message">Loading claims...</p>}
//       {error && <p className="error-message">{error}</p>}

//       {!loading && !error && filteredClaims.length > 0 ? (
//         <div className="card-grid">
//           {filteredClaims.map((claim) => (
//             <div key={claim.claimId} className="claim-card elevated-card">
//               <div className="card-body">
//                 <div className="text-section">
//                   <h5 className="card-title">{claim.claimId}</h5>
//                   {claim.policyId && (
//                     <p className="card-subtitle">
//                       Policy: {policyDetails[claim.policyId]?.name || 'Loading...'}
//                     </p>
//                   )}
//                   <p className="card-info">
//                     Amount: <span className="amount">Rs.{claim.claimAmount}</span>
//                   </p>
//                   <p className="card-info">
//                     Updated At: {new Date(claim.updatedAt).toLocaleDateString()}
//                   </p>
//                 </div>
//                 <div className="actions-section">
//                   <button className={`status-button ${getStatusButtonStyle(claim.status)}`}>
//                     {claim.status}
//                   </button>
//                   {claim.policyId && (
//                     <button className="view-details-button primary-button" onClick={() => handleViewDetailsClick(claim.policyId)}>
//                       View Policy
//                     </button>
//                   )}
//                 </div>
//               </div>
//             </div>
//           ))}
//         </div>
//       ) : (!loading && !error && (
//         <p className="empty-message">No claims found for the selected status.</p>
//       ))}

//       {selectedPolicyId && selectedPolicy && selectedClaim && (
//         <div className="popup-overlay">
//           <div className="popup-box beautiful-popup">
//             <button onClick={closePopup} className="close-button">
//               <span aria-hidden="true">&times;</span>
//             </button>
//             <ClaimDetails
//               policyDetails={selectedPolicy}
//               isPopupOpen={true}
//               onClose={closePopup}
//             />
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default ClaimListPage;
import React, { useEffect, useState, useMemo } from 'react';
import axios from 'axios';
import './ClaimListPage.css';
import ClaimDetails from './ClaimDetails';
import CustomerNavbar from '../layout/CustomerNavbar';
// Import the ClaimDetailsPage component

const CustomerClaimListPage = () => {
  const [claims, setClaims] = useState([]);
  const customerId = 'e4c4d9bb-df60-47e4-bf4a-2075805d668d'; // Hardcoded for testing - consider fetching dynamically
  const [policyDetails, setPolicyDetails] = useState({});
  const [selectedPolicyId, setSelectedPolicyId] = useState(null);
  const [statusFilter, setStatusFilter] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const claimStatuses = ['UnderReview', 'Approved', 'Rejected', ''];

  // Function to set tokens in localStorage (for testing)
  

  // Function to get tokens from localStorage
  const getTokens = () => {
    const token = localStorage.getItem('userToken');
    const uuid = localStorage.getItem('userId');
    return { token, uuid };
  };

  useEffect(() => {
    // Call setTestTokens once when the component mounts (for testing purposes)

    const fetchClaims = async () => {
      setLoading(true);
      setError('');
      try {
        const { token, uuid } = getTokens(); // Get tokens

        const endpoint =`/api/v1/claim/${uuid}/customer-claims`; // Use uuid

        const response = await axios.get(endpoint, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setClaims(response.data.data);
        const uniquePolicyIds = [...new Set(response.data.data.map(claim => claim.policyId).filter(Boolean))];
        uniquePolicyIds.forEach(policyId => fetchPolicyDetails(policyId, token));
      } catch (err) {
        console.error('Error fetching claims:', err);
        if(err.response && err.response.status === 404){
          setError('no claims to fetch .');
        }
        setClaims([]);
        if (err.response && err.response.status === 401) {
          console.error('Unauthorized access.');
          setError('No ACCESS!!');
          // Handle unauthorized access (e.g., redirect to login)
        }
      } finally {
        setLoading(false);
      }
    };

    const fetchPolicyDetails = async (policyId, token) => {
      try {
        const response = await axios.get(`/api/v1/policies/${policyId}`, {
          headers: { Authorization: `Bearer ${token}`},
        });
        setPolicyDetails(prevDetails => ({
          ...prevDetails,
          [policyId]: response.data.data,
        }));
      } catch (err) {
        console.error(`Error fetching policy details for ID ${policyId}:`, err);
        setPolicyDetails(prevDetails => ({
          ...prevDetails,
          [policyId]: { name: 'Policy Details Not Found' },
        }));
        if (err.response && err.response.status === 401) {
          console.error('Unauthorized access to policy details.');
        }
      }
    };

    fetchClaims();
  }, [statusFilter]);

  const handleViewDetailsClick = (policyId) => {
    setSelectedPolicyId(policyId);
  };

  const closePopup = () => {
    setSelectedPolicyId(null);
  };

  const handleStatusFilterChange = (event) => {
    setStatusFilter(event.target.value);
  };

  const getStatusButtonStyle = (status) => {
    const lowerCaseStatus = status.toLowerCase();
    if (lowerCaseStatus === 'underreview') {
      return 'status-button yellow';
    } else if (lowerCaseStatus === 'rejected') {
      return 'status-button red';
    } else if (lowerCaseStatus === 'approved') {
      return 'status-button green';
    }
    return 'status-button';
  };

  const filteredClaims = useMemo(() => {
    if (!statusFilter) {
      return claims;
    }
    return claims.filter(claim =>
      claim.status.toLowerCase() === statusFilter.toLowerCase()
    );
  }, [claims, statusFilter]);

  const selectedPolicy = selectedPolicyId ? policyDetails[selectedPolicyId] : null;
  const selectedClaim = claims.find(claim => claim.policyId === selectedPolicyId);

  return (

    <>
    <header className="transparent-header">
      <CustomerNavbar />
      </header>
   
    <div className="claim-cards-container">
      
      
      <h2 className="title">Your Claims</h2>

      <div className="filter-section">
        <label htmlFor="statusFilter" className="filter-label">Filter by Status:</label>
        <select
          id="statusFilter"
          className="filter-dropdown"
          value={statusFilter}
          onChange={handleStatusFilterChange}
        >
          <option value="">All Statuses</option>
          {claimStatuses
            .filter(status => status !== '')
            .map((status) => (
              <option key={status.toLowerCase()} value={status.toLowerCase()}>
                {status}
              </option>
            ))}
        </select>
      </div>

      {loading && <p className="loading-message">Loading claims...</p>}
      {error && <p className="error-message">{error}</p>}

      {!loading && !error && filteredClaims.length > 0 ? (
        <div className="card-grid">
          {filteredClaims.map((claim) => (
            <div key={claim.claimId} className="claim-card elevated-card">
              <div className="card-body">
                <div className="text-section">
                  {claim.policyId && (
                    <p className="card-subtitle">
                      Policy: {policyDetails[claim.policyId]?.name || 'Loading...'}
                    </p>
                  )}
                  <p className="card-info">
                   Claim Amount: <span className="amount">Rs.{claim.claimAmount}</span>
                  </p>
                  <p className="card-info">
                    Updated At: {new Date(claim.updatedAt).toLocaleDateString()}
                  </p>
                </div>
                <div className="actions-section">
                  <button className={`status-button ${getStatusButtonStyle(claim.status)}`}>
                    {claim.status}
                  </button>
                  {claim.policyId && (
                    <button className="view-details-button primary-button" onClick={() => handleViewDetailsClick(claim.policyId)}>
                      View Policy
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (!loading && !error && (
        <p className="empty-message">No claims found for the selected status.</p>
      ))}

      {selectedPolicyId && selectedPolicy && selectedClaim && (
        <div className="popup-overlay">
          <div className="popup-box beautiful-popup">
            <button onClick={closePopup} className="close-button">
              <span aria-hidden="true">&times;</span>
            </button>
            <ClaimDetails
              policyDetails={selectedPolicy}
              isPopupOpen={true}
              onClose={closePopup}
            />
            
          </div>
        </div>
      )}
    </div>
    </>
  );
};

export default CustomerClaimListPage;