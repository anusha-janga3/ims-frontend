import React, { useState, useEffect } from "react";
import axios from "axios";
import ClaimPolicyDetails from "./ClaimPolicyDetails"; // Import the new component
import "../policy/CustomerPolicies.css"; // Import the CSS file
import CustomerNavbar from "../layout/CustomerNavbar";
import "./FileClaimPage.css"; // Import the CSS file for this component

const FileClaimPage = () => {
  const [policies, setPolicies] = useState([]); // State to hold details of multiple policies
  const [error, setError] = useState(""); // General error state for main page
  const [popupError, setPopupError] = useState(""); // Error state for the popup
  const [showPopup, setShowPopup] = useState(false); // State to show/hide the popup
  const [selectedPolicy, setSelectedPolicy] = useState(null); // State for selected policy
  const [claimAmount, setClaimAmount] = useState(""); // Claim amount
  const [successMessage, setSuccessMessage] = useState(""); // Success message

  const token = localStorage.getItem("userToken"); // Retrieve token from localStorage
  const customerId = localStorage.getItem("userId"); // Retrieve customer ID from localStorage
  const adminId = "a2b73861-957f-4a00-a00a-539d1ccde94d"; // Fixed admin ID

  const fetchCustomerPolicyDetails = async () => {
    try {
      const customerResponse = await axios.get(
        `/api/v1/policies/customer/${customerId}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      const customerPolicies = customerResponse.data.data;
      const policyDetailsArray = await Promise.all(
        customerPolicies.map(async (customerPolicy) => {
          const { policyId, purchaseDate, agentId } = customerPolicy;

          if (!policyId) {
            console.error("Policy ID is missing.");
            return null;
          }

          const policyResponse = await axios.get(`/api/v1/policies/${policyId}`, {
            headers: { Authorization: `Bearer ${token}` },
          });

          return {
            ...policyResponse.data.data,
            purchaseDate, // Add purchase date
            agentId, // Add agent ID
          };
        })
      );

      setPolicies(policyDetailsArray.filter((policy) => policy));
    } catch (err) {
      console.error("Failed to fetch policies:", err);
      setError("Failed to fetch policies.");
    }
  };

  const handleFileClaimClick = (policy) => {
    setSelectedPolicy(policy); // Store the selected policy
    setShowPopup(true); // Show the popup
    setClaimAmount(""); // Reset claim amount when opening popup
    setPopupError(""); // Clear any previous popup errors
  };

  const handleClaimSubmit = async () => {
    if (!claimAmount) {
      setPopupError("Claim amount cannot be empty.");
      return;
    }

    if (parseFloat(claimAmount) <= 10000) {
      setPopupError("Claim amount must be greater than 10000.");
      return;
    }

    if (parseFloat(claimAmount) >= 10000000) {
      setPopupError("Claim amount is Invalid");
      return;
    }

    try {
      const claimData = {
        claimAmount: parseFloat(claimAmount), // Convert claim amount to number
        customerId,
        adminId,
        policyId: selectedPolicy.policyId,
        agentId: selectedPolicy.agentId,
      };

      const response = await axios.post(
        "http://localhost:8083/api/v1/claim/claim",
        claimData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          withCredentials: true,
        }
      );
      setSuccessMessage("Claim filed successfully!");
      setShowPopup(false); // Close the popup on success
      setClaimAmount(""); // Reset the claim amount field
      setPopupError(""); // Clear any potential previous popup error
    } catch (err) {
      console.error("Error filing claim:", err);
      if (err.response && err.response.data && err.response.data.message) {
        setPopupError(err.response.data.message); // Set error message in popup
      } else if (err.message) {
        setPopupError(`Failed to file the claim: ${err.message}`); // Set a generic error in popup
      } else {
        setPopupError("Failed to file the claim. Please try again."); // Default error in popup
      }
    }
  };

  useEffect(() => {
    fetchCustomerPolicyDetails();
  }, []);

  return (
    <>
      <header className="transparent-header">
        <CustomerNavbar />
      </header>
      <div className="container">
        <h1 className="title">File a Claim for Your Policies</h1>
        {error && <p className="error">{error}</p>} {/* Main page error */}
        {successMessage && <p className="success">{successMessage}</p>}
        {policies.length > 0 ? (
          <div className="policies-grid">
            {policies.map((policy, index) => (
              <ClaimPolicyDetails
                key={index}
                policy={policy}
                handleFileClaimClick={handleFileClaimClick}
              />
            ))}
          </div>
        ) : (
          <p>Loading policy details...</p>
        )}

        {/* Popup for filing a claim */}
        {showPopup && (
          <div className="popup-overlay" onClick={() => setShowPopup(false)}>
            <div
              className="popup-box"
              onClick={(e) => e.stopPropagation()} // Prevent closing on inner box click
            >
              <h3 className="popup-title">File Claim</h3>
              <p className="popup-policy-info">
                Filing a claim for Policy ID:{" "}
                <strong className="highlighted-policy-name">
                  {selectedPolicy.policyName}
                </strong>
              </p>
              <input
                type="number"
                placeholder="Enter Claim Amount "
                value={claimAmount}
                onChange={(e) => setClaimAmount(e.target.value)}
                className={`claim-input ${popupError ? 'error-input' : ''}`}
              />
              {popupError && <p className="validation-error">{popupError}</p>} {/* Popup error */}
              <div className="popup-buttons">
                <button className="submit-claim-button" onClick={handleClaimSubmit}>
                  Submit
                </button>
                <button className="close-popup-button" onClick={() => setShowPopup(false)}>
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default FileClaimPage;