// src/components/layout/CustomerFooter.js
import React from 'react';
import './FooterStyle.css'; // Import the CSS file for styling
 
const CustomerFooter = () => {
    return (
        <footer className="customer-footer">
            <div className="footer-content">
                <div className="footer-section">
                    <h4>About Us</h4>
                    <p>Your trusted partner for all your insurance needs.</p>
                </div>
                <div className="footer-section">
                    <h4>Contact Us</h4>
                    <p>Email: support@insurancecompany.com</p>
                    <p>Phone: +91 1234567890</p>
                    <p>Address: 123 Main Street, Chennai, India</p>
                </div>
                <div className="footer-section">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="/dashboard">Home</a></li>
                        <li><a href="/dashboard/policies/view">My Policies</a></li>
                        <li><a href="/dashboard/claims/submit">File a Claim</a></li>
                        <li><a href="/dashboard/support">Support</a></li>
                    </ul>
                </div>
                <div className="footer-bottom">
                    <p>&copy; {new Date().getFullYear()} Insurance Company. All rights reserved.</p>
                    <div className="social-icons">
                        {/* Add your social media icons here (e.g., FontAwesome) */}
                        {/* <a href="#"><FontAwesomeIcon icon={faFacebook} /></a> */}
                        {/* <a href="#"><FontAwesomeIcon icon={faTwitter} /></a> */}
                        {/* <a href="#"><FontAwesomeIcon icon={faLinkedin} /></a> */}
                    </div>
                </div>
            </div>
        </footer>
    );
};
 
export default CustomerFooter;
 