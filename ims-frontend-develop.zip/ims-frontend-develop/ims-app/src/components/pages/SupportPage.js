import React, { useState } from 'react';
import './SupportPage.css'; // Import CSS for styling
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faChevronDown, faChevronUp } from '@fortawesome/free-solid-svg-icons';
import CustomerNavbar from '../layout/CustomerNavbar';
 
const SupportPage = () => {
  const [activeQuestion, setActiveQuestion] = useState(null);
 
  const faqData = [
    {
      id: 1,
      question: 'What is this application about?',
      answer: "This application is designed to provide better access for the customer's to their Insurance policies and claims.",
    },
    {
      id: 2,
      question: 'How do I create a new account?',
      answer: 'To create a new account, simply click on the "Sign Up" button located on the homepage. Follow the on-screen instructions, providing the necessary details and verifying your email address.',
    },
    {
        id: 3,
        question: 'How to Register in Customer Portal?',
        answer: (
          <>
            1. Select "Register" option in the Home page
            <br />
            2. Provide the required feilds and click Register.
            <br />
            3. New customer is registered successfully
          </>
        ),   },
    {
      id: 4,
      question: 'Where can I view the details of my insurance policy?',
      answer: 'All the policies taken by the customer will be displayed in the "View Policies" section of the customer dashboard.',
    },
    {
      id: 5,
      question: 'What is Health Insurance',
      answer: "Health insurance is a contract between an individual (or a group) and an insurance company. In exchange for a regular payment called a premium, the insurance company agrees to pay for a portion of the insured person's medical expenses.",
    },
    {
      id: 6,
      question: 'What is a Claim?',
      answer: 'A claim is a formal request made by the policyholder to the insurance company for compensation or payment based on the terms and conditions of their insurance policy.',
    },
    {
      id: 7,
      question: 'How do I contact customer support?',
      answer: 'You can reach out to your agent through the Phone no. provided in the Customer dashboard.',
    },
  ];
 
  const toggleAnswer = (questionId) => {
    setActiveQuestion(activeQuestion === questionId ? null : questionId);
  };
 
  return (
    <>
    <header className="transparent-header">
        <CustomerNavbar />
      </header>
    <div className="support-page">
      <h1>Application Support</h1>
      <ul className="faq-list">
        {faqData.map((item) => (
          <li key={item.id} className="faq-item">
            <button
              className={`question-button ${activeQuestion === item.id ? 'active' : ''}`}
              onClick={() => toggleAnswer(item.id)}
            >
              {item.question}
              <span className="dropdown-icon">
                <FontAwesomeIcon icon={activeQuestion === item.id ? faChevronUp : faChevronDown} />
              </span>
            </button>
            {activeQuestion === item.id && (
              <div className="answer-dropdown open">
                <p>{item.answer}</p>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
    </>
  );
};
 
export default SupportPage;
 
 