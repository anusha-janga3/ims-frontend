// // // src/components/layout/CustomerNavbar.js
// // import React, { useState } from 'react';
// // import { Link, useNavigate } from 'react-router-dom';
// // import styles from './CustomerNavStyle.css'; 
// // import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// // import { faUser, faBell, faCaretDown } from '@fortawesome/free-solid-svg-icons';
// // import NotificationPage from '../notificaton/Notification';
// // import axios from 'axios';

// // const CustomerNavbar = () => {
// //    // Replace with your actual way to get the ID

// //    const [isPoliciesOpen, setIsPoliciesOpen] = useState(false);
// //     const [isClaimsOpen, setIsClaimsOpen] = useState(false);
// //     const [isAuthDropdownOpen, setIsAuthDropdownOpen] = useState(false);
// //     const [showPopup, setShowPopup] = useState(false); // Add showPopup state
// //     const [notificationCount, setNotificationCount] = useState(0); // Add notification count state
// //     const navigate = useNavigate();
// //     const loggedInUserId = localStorage.getItem('userId');
// //     const uuid = localStorage.getItem('userId');
// //     const token = localStorage.getItem('userToken');

// //   const togglePoliciesDropdown = () => {
// //     setIsPoliciesOpen(!isPoliciesOpen);
// //     setIsClaimsOpen(false);
// //     setIsAuthDropdownOpen(false);
// //   };

// //   const toggleClaimsDropdown = () => {
// //     setIsClaimsOpen(!isClaimsOpen);
// //     setIsPoliciesOpen(false);
// //     setIsAuthDropdownOpen(false);
// //   };
// //   const fetchNotificationCount = async () => {
// //     try {
// //         const response = await axios.get(`/api/v1/notification/customer/{uuid}`, {
// //             headers: {
// //                 'Authorization': `Bearer ${token}`,
// //             },
// //         });
// //         if (response.data && response.data.data) {
// //             setNotificationCount(response.data.data.length);
// //         }
// //     } catch (error) {
// //         console.error('Error fetching notification count:', error);
// //     }
// // };
// //   const toggleAuthDropdown = () => {
// //     setIsAuthDropdownOpen(!isAuthDropdownOpen);
// //     setIsPoliciesOpen(false);
// //     setIsClaimsOpen(false);
// //   };

// //   const handleLogout = () => {
// //     // Implement your logout logic
// //     navigate('/login');
// //   };

// //   return (
// //     <nav className={styles.navbar}>
// //       <div className={styles['navbar-left']}>
// //         <Link to="/dashboard" className={styles.logo}>
// //           {/* <img src={logo} alt="Insurance Logo" className={styles['logo-img']} /> */}
// //           <span className={styles['logo-placeholder']}>Insurance</span> {/* Placeholder for logo */}
// //         </Link>
// //       </div>

// //       <div className={styles['navbar-right-content']}>
// //         {/* <div className="search-bar">
// //           <input type="text" placeholder="Search..." />
// //           <button type="submit">Search</button>
// //         </div> */}
// //         <ul className={styles['nav-links']}>
// //           <li><Link to="/dashboard">Home</Link></li>
// //           <li
// //             className={`${styles.dropdown} ${isPoliciesOpen ? styles.open : ''}`}
// //             onClick={togglePoliciesDropdown}
// //           >
// //             <Link to="#">My Policies</Link>
// //             {isPoliciesOpen && (
// //               <ul className={styles['dropdown-menu']}>
// //                 <li><Link to="/dashboard/policies/view">View Policies</Link></li>
// //                 <li><Link to="/dashboard/policies/add">Add New Policy</Link></li>
// //               </ul>
// //             )}
// //           </li>
// //           <li
// //             className={`${styles.dropdown} ${isClaimsOpen ? styles.open : ''}`}
// //             onClick={toggleClaimsDropdown}
// //           >
// //             <Link to="#">Claims</Link>
// //             {isClaimsOpen && (
// //               <ul className={styles['dropdown-menu']}>
// //                 <li><Link to="/dashboard/claims/submit">Submit Claim</Link></li>
// //                 <li><Link to="/dashboard/claims/status">Claim Status</Link></li>
// //               </ul>
// //             )}
// //           </li>
// //           <li><Link to="/dashboard/support">Support</Link></li>
// //         </ul>
// //         <div className="notifications" >
// //         {/* <FontAwesomeIcon icon={faBell} onClick={() => setShowPopup(true)}/> */}
// // <NotificationPage showPopup={showPopup} setShowPopup={setShowPopup} />
// // </div>
// //         <div className={`${styles['auth-dropdown']} ${isAuthDropdownOpen ? styles.open : ''}`}>
// //           <div className={styles['auth-toggle']} onClick={toggleAuthDropdown}>
// //             <FontAwesomeIcon icon={faUser} />
// //             <FontAwesomeIcon icon={faCaretDown} className={styles['dropdown-arrow']} />
// //           </div>
// //           {isAuthDropdownOpen && (
// //             <ul className={styles['auth-dropdown-menu']}>
// //               <li>
// //                 <Link to={`/dashboard/profile/${loggedInUserId}`}>My Profile</Link>
// //               </li>
// //               <li>
// //                 <Link to={`/customers/edit/${loggedInUserId}`}>Update Profile</Link>
// //               </li>

// //               <li>
// //                 <button onClick={handleLogout} className={styles['logout-button']}>Logout</button>
// //               </li>
// //             </ul>
// //           )}
// //         </div>
// //       </div>
// //     </nav>
// //   );
// // };

// // export default CustomerNavbar;


// // src/components/layout/CustomerNavbar.js
// import React, { useState } from 'react';
// import { Link, useNavigate } from 'react-router-dom';
// import './CustomerNavStyle.css';
// // import logo from '../../assets/images/logo.png';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faUser, faBell, faCaretDown } from '@fortawesome/free-solid-svg-icons';
// import NotificationPage from '../notificaton/Notification';
 
// const CustomerNavbar = () => {
//   const [isPoliciesOpen, setIsPoliciesOpen] = useState(false);
//   const [isClaimsOpen, setIsClaimsOpen] = useState(false);
//   const [isAuthDropdownOpen, setIsAuthDropdownOpen] = useState(false);
//   const [notifications, setNotifications] = useState([]);
//     const [showPopup, setShowPopup] = useState(false);

//   const navigate = useNavigate();
//   const loggedInUserId = localStorage.getItem('userId'); // Replace with your actual way to get the ID
 
//   const togglePoliciesDropdown = () => {
//     setIsPoliciesOpen(!isPoliciesOpen);
//     setIsClaimsOpen(false);
//     setIsAuthDropdownOpen(false);
//   };
 
//   const toggleClaimsDropdown = () => {
//     setIsClaimsOpen(!isClaimsOpen);
//     setIsPoliciesOpen(false);
//     setIsAuthDropdownOpen(false);
//   };
 
//   const toggleAuthDropdown = () => {
//     console.log('toggleAuthDropdown called'); // For debugging
//     setIsAuthDropdownOpen(!isAuthDropdownOpen);
//     setIsPoliciesOpen(false);
//     setIsClaimsOpen(false);
//   };
 
//   const handleLogout = () => {
//     // Implement your logout logic
//     navigate('/login');
//   };
 
//   return (
//     <nav className="navbar">
//       <div className="navbar-left">
//         <Link to="/dashboard" className="logo">
//           {/* <img src={logo} alt="Insurance Logo" className="logo-img" /> */}
//           <span className="logo-placeholder">Insurance</span>
//         </Link>
//       </div>
 
//       <div className="navbar-right-content">
//         <ul className="nav-links">
//           <li><Link to="/dashboard">Home</Link></li>
//           <li
//             className={`dropdown ${isPoliciesOpen ? 'open' : ''}`}
//             onClick={togglePoliciesDropdown}
//           >
//             <Link to="#">My Policies</Link>
//             {isPoliciesOpen && (
//               <ul className="dropdown-menu">
//                 <li><Link to="/dashboard/policies/view">View Policies</Link></li>
//                 <li><Link to="/dashboard/policies/add">Add New Policy</Link></li>
//               </ul>
//             )}
//           </li>
//           <li
//             className={`dropdown ${isClaimsOpen ? 'open' : ''}`}
//             onClick={toggleClaimsDropdown}
//           >
//             <Link to="#">Claims</Link>
//             {isClaimsOpen && (
//               <ul className="dropdown-menu">
//                 <li><Link to="/dashboard/claims/submit">Submit Claim</Link></li>
//                 <li><Link to="/dashboard/claims/status">Claim Status</Link></li>
//               </ul>
//             )}
//           </li>
//           <li><Link to="/dashboard/support">Support</Link></li>
//         </ul>
//         <div className="notifications" >
//        {/* <FontAwesomeIcon icon={faBell} onClick={() => setShowPopup(true)}/> */}
//        <NotificationPage showPopup={showPopup} setShowPopup={setShowPopup} />
//  </div>
//         <div className={`auth-dropdown ${isAuthDropdownOpen ? 'open' : ''}`}> {/* Added the 'open' class conditionally */}
//           <div className="auth-toggle" onClick={toggleAuthDropdown}>
//             <FontAwesomeIcon icon={faUser} style={{ color: 'white' }} />
//             <FontAwesomeIcon icon={faCaretDown} className="dropdown-arrow" />
//           </div>
//           {isAuthDropdownOpen && (
//             <ul className="auth-dropdown-menu">
//               <li>
//                 <Link to={`/dashboard/profile/${loggedInUserId}`}>My Profile</Link>
//               </li>
//               <li>
//                 <Link to={`/customers/edit/${loggedInUserId}`}>Update Profile</Link>
//               </li>
//               <li>
//                 <button onClick={handleLogout} className="logout-button">Logout</button>
//               </li>
//             </ul>
//           )}
//         </div>
//       </div>
//     </nav>
//   );
// };
 
// export default CustomerNavbar;
 // src/components/layout/CustomerNavbar.js
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './CustomerNavStyle.css';
// import logo from '../../assets/images/logo.png';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser, faBell, faCaretDown } from '@fortawesome/free-solid-svg-icons';
import NotificationPage from '../notificaton/Notification';

const CustomerNavbar = () => {
  const [isPoliciesOpen, setIsPoliciesOpen] = useState(false);
  const [isClaimsOpen, setIsClaimsOpen] = useState(false);
  const [isAuthDropdownOpen, setIsAuthDropdownOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [showPopup, setShowPopup] = useState(false);

  const navigate = useNavigate();
  const loggedInUserId = localStorage.getItem('userId'); // Replace with your actual way to get the ID

  const togglePoliciesDropdown = () => {
    setIsPoliciesOpen(!isPoliciesOpen);
    setIsClaimsOpen(false);
    setIsAuthDropdownOpen(false);
  };

  const toggleClaimsDropdown = () => {
    setIsClaimsOpen(!isClaimsOpen);
    setIsPoliciesOpen(false);
    setIsAuthDropdownOpen(false);
  };

  const toggleAuthDropdown = () => {
    console.log('toggleAuthDropdown called'); // For debugging
    setIsAuthDropdownOpen(!isAuthDropdownOpen);
    setIsPoliciesOpen(false);
    setIsClaimsOpen(false);
  };

  const handleLogout = () => {
    localStorage.removeItem('userToken');
    localStorage.removeItem('userId');
    localStorage.removeItem('userRole');
 
    sessionStorage.setItem('logoutFlag', 'true'); // ✅ Set logout flag
 
    console.log("Logout initiated. Flag set:", sessionStorage.getItem('logoutFlag'));
 
    window.location.href = '/Login'; // ✅ Redirect to Login
  };
 

  return (
    <nav className="custnav_navbar">
      <div className="custnav_navbar_left">
        <Link to="/dashboard" className="custnav_logo">
          {/* <img src={logo} alt="Insurance Logo" className="custnav_logo_img" /> */}
          <span className="custnav_logo_placeholder">Insurance Management System</span>
        </Link>
      </div>

      <div className="custnav_navbar_right_content">
        <ul className="custnav_nav_links">
          <li><Link to="/dashboard">Home</Link></li>
          <li
            className={`custnav_dropdown ${isPoliciesOpen ? 'custnav_open' : ''}`}
            onClick={togglePoliciesDropdown}
          >
            <Link to="#">My Policies</Link>
            {isPoliciesOpen && (
              <ul className="custnav_dropdown_menu">
                <li><Link to="/dashboard/policies/view">View Policies</Link></li>
                <li><Link to="/dashboard/policies/add">Add New Policy</Link></li>
              </ul>
            )}
          </li>
          <li
            className={`custnav_dropdown ${isClaimsOpen ? 'custnav_open' : ''}`}
            onClick={toggleClaimsDropdown}
          >
            <Link to="#">Claims</Link>
            {isClaimsOpen && (
              <ul className="custnav_dropdown_menu">
                <li><Link to="/dashboard/claims/submit">Submit Claim</Link></li>
                <li><Link to="/dashboard/claims/status">Claim Status</Link></li>
              </ul>
            )}
          </li>
          <li><Link to="/dashboard/support">Support</Link></li>
        </ul>
        <div className="custnav_notifications" >
          {/* <FontAwesomeIcon icon={faBell} onClick={() => setShowPopup(true)}/> */}
          <NotificationPage showPopup={showPopup} setShowPopup={setShowPopup} />
        </div>
        <div className={`custnav_auth_dropdown ${isAuthDropdownOpen ? 'custnav_open' : ''}`}> {/* Added the 'custnav_open' class conditionally */}
          <div className="custnav_auth_toggle" onClick={toggleAuthDropdown}>
            <FontAwesomeIcon icon={faUser} style={{ color: 'white' }} />
            <FontAwesomeIcon icon={faCaretDown} className="custnav_dropdown_arrow" />
          </div>
          {isAuthDropdownOpen && (
            <ul className="custnav_auth_dropdown_menu">
              <li>
                <Link to={`/dashboard/profile/${loggedInUserId}`}>My Profile</Link>
              </li>
              <li>
                <Link to={`/customers/edit/${loggedInUserId}`}>Update Profile</Link>
              </li>
              <li>
                <Link onClick={handleLogout} className="custnav_logout_button">Logout</Link>
              </li>
            </ul>
          )}
        </div>
      </div>
    </nav>
  );
};

export default CustomerNavbar;