// // // import React from 'react';

// // // import './CustomerDashboard.css';
// // // import CustomerNavbar from './CustomerNavbar';
 
// // // const DashboardLayout = ({ children }) => {
// // //   return (
// // //     <div className="dashboard-layout">
// // //       <div
// // //         className="background-image"
// // //       ></div>
// // //       <header className="transparent-header">
// // //       <CustomerNavbar />
// // //       </header>
// // //       <div className="dashboard-content">
// // //         {children}
// // //       </div>
// // //       {/* Optional Footer */}
// // //     </div>
// // //   );

  
  
// // // };
 
// // // export default DashboardLayout;
 
// // // DashboardLayout.js
// // import React from 'react';
// // import './CustomerDashboard.css';
// // import CustomerNavbar from './CustomerNavbar';

// // const DashboardLayout = ({ children }) => {
// //   return (
// //     <div className="dashboard-layout">
// //       <div
// //         className="background-image"
// //       ></div>
// //       <header className="transparent-header">
// //         <CustomerNavbar />
// //       </header>
// //       <div className="dashboard-content">
// //         {children}
// //       </div>
// //       {/* Optional Footer */}
// //     </div>
// //   );
// // };

// // export default DashboardLayout;

// import React, { useState } from 'react';
// import './CustomerDashboard.css'; // Styles for the layout
// import PolicyCard from './PolicyCard';
// import './CustomerDashboard.css'; // Styles for the dashboard content
// import CustomerNavbar from './CustomerNavbar'; // Navigation bar

// const TEST_TOKEN = localStorage.getItem('userToken') // Replace with your actual test token

// const CustomerDashboardPage = () => {
//   const [searchTerm, setSearchTerm] = useState('');
//   const [filteredPolicies, setFilteredPolicies] = useState([]);
//   const [allPolicies, setAllPolicies] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState(null);
//   const premiumRanges = [
//     { label: 'Premium > 5000', endpoint: '/api/v1/policies/greaterPremium/5000' },
//     { label: 'Premium < 5000', endpoint: '/api/v1/policies/lesserPremium/5000' },
//   ];
//   const validityRanges = [
//     { label: 'Validity > 5 Years', endpoint: '/api/v1/policies/greaterValidity/5' },
//     { label: 'Validity < 5 Years', endpoint: '/api/v1/policies/lesserValidity/5' },
//   ];


//   // Function to handle API errors and set appropriate messages
//   const handleApiError = async (response, filterType, filterValue) => {
//     if (!response.ok) {
//       const errorData = await response.json();
//       if (errorData && errorData.message && errorData.message.includes('No policies found')) {
//         setError(`No policies found with ${filterType}: '${filterValue}'.`);
//       } else {
//         throw new Error(`Error fetching policies: ${response.statusText}`);
//       }
//       return true; // Indicate an error was handled
//     }
//     return false; // No error
//   };
 
//   // Fetch policies by name
//   const fetchPoliciesByName = async (searchText) => {
//     setLoading(true);
//     setError(null);
//     setFilteredPolicies([]);
//     try {
//       const url = `/api/v1/policies/startsWith/${searchText}`;
//       const response = await fetch(url, {
//         headers: {
//           Authorization: `Bearer ${TEST_TOKEN}`,
//         },
//       });
//       if (await handleApiError(response, 'name', searchText)) {
//         setFilteredPolicies([]);
//         return;
//       }
//       const responseData = await response.json();
//       setFilteredPolicies(responseData.data || []);
//     } catch (error) {
//       console.error(`Could not fetch policies starting with '${searchText}':`, error);
//       setError('An error occurred while fetching policies.');
//     } finally {
//       setLoading(false);
//     }
//   };
 

//   // Fetch policies based on selected filter
//  // Fetch policies by name

// // Fetch policies based on selected filter
// const fetchPoliciesByRange = async (endpoint, filterType, filterValue) => {
//   setLoading(true);
//   setError(null);
//   setFilteredPolicies([]);
//   try {
//     const url = `http://localhost:8082${endpoint}`;
//     const response = await fetch(url, {
//       headers: {
//         Authorization: `Bearer ${TEST_TOKEN}`,
//       },
//     });
//     if (await handleApiError(response, filterType, filterValue)) {
//       setFilteredPolicies([]);
//       return;
//     }
//     const responseData = await response.json();
//     setFilteredPolicies(responseData.data || []);
//   } catch (error) {
//     console.error('Error fetching policies with range:', error);
//     setError('An error occurred while fetching filtered policies.');
//   } finally {
//     setLoading(false);
//   }
// };

//   // Fetch all policies
//   // Fetch all policies
//   const fetchAllPolicies = async () => {
//     setLoading(true);
//     setError(null);
//     setAllPolicies([]);
//     try {
//       const url = 'http://localhost:8082/api/v1/policies';
//       const response = await fetch(url, {
//         headers: {
//           Authorization: `Bearer ${TEST_TOKEN}`,
//         },
//       });
//       if (await handleApiError(response, 'all', '')) {
//         setAllPolicies([]);
//         return;
//       }
//       const responseData = await response.json();
//       setAllPolicies(responseData.data || []);
//     } catch (error) {
//       console.error('Error fetching all policies:', error);
//       setError('An error occurred while fetching all policies.');
//     } finally {
//       setLoading(false);
//     }
//   };
 

//   return (
//     <div className="dashboard-layout">
//       <div className="background-image"></div>
//       <header className="transparent-header">
//         <CustomerNavbar />
//       </header>
//       <div className="dashboard-content" style={{ maxWidth: '180vh', justifyContent: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '20px', margin: '20px auto' }}>
//         <h2>Policy Dashboard</h2>
//         {/* Input Card with Search and Filters */}
//         <div className="input-card">
//           {/* Search Section */}
//           <section className="search-section">
//             <form onSubmit={(e) => { e.preventDefault(); fetchPoliciesByName(searchTerm); }}>
//               <input
//                 type="text"
//                 placeholder="Search by Policy Name"
//                 value={searchTerm}
//                 onChange={(e) => setSearchTerm(e.target.value)}
//                 className="search-bar"
//               />
//               <button type="submit" className="search-button">
//                 Search
//               </button>
//             </form>
//           </section>
//           {/* Filter Section */}
//           <section className="filter-section">
//             <div className="dropdown-container">
//               <label htmlFor="premium-filter">Filter by Premium:</label>
//               <select
//                 id="premium-filter"
//                 onChange={(e) => {
//                   const selectedEndpoint = e.target.value;
//                   if (selectedEndpoint) fetchPoliciesByRange(selectedEndpoint);
//                 }}
//               >
//                 <option value="">Select Premium Range</option>
//                 {premiumRanges.map((range, index) => (
//                   <option key={index} value={range.endpoint}>
//                     {range.label}
//                   </option>
//                 ))}
//               </select>
//             </div>
//             <div className="dropdown-container">
//               <label htmlFor="validity-filter">Filter by Validity Period:</label>
//               <select
//                 id="validity-filter"
//                 onChange={(e) => {
//                   const selectedEndpoint = e.target.value;
//                   if (selectedEndpoint) fetchPoliciesByRange(selectedEndpoint);
//                 }}
//               >
//                 <option value="">Select Validity Range</option>
//                 {validityRanges.map((range, index) => (
//                   <option key={index} value={range.endpoint}>
//                     {range.label}
//                   </option>
//                 ))}
//               </select>
//             </div>
//             <button onClick={fetchAllPolicies} className="fetch-all-button">
//               Fetch All Policies
//             </button>
//           </section>
//         </div>
//         {loading && <p>Loading policies...</p>}
//         {error && <p className="error-message">Error: {error}</p>}
//         {/* Policies Section */}
//         <section
//           className="policies-grid"
//           style={{ display: 'flex', flexDirection: 'column', width: '100%', alignItems: 'flex-start', gap: '15px' }}
//         >
//           {/* Display filtered policies first */}
//           {!loading && !error && filteredPolicies.length > 0 && (
//             <div className="output-card" style={{ width: '100%' }}>
//               <h3>Filtered Policies:</h3>
//               <div style={{ display: 'flex', flexDirection: 'column', gap: '15px', alignItems: 'flex-start' }}>
//                 {filteredPolicies.map((policy) => (
//                   <PolicyCard key={policy.policyId} policy={policy} />
//                 ))}
//               </div>
//             </div>
//           )}
//           {/* Display all policies after filtered policies */}
//           {!loading && !error && allPolicies.length > 0 && (
//             <div className="output-card" style={{ width: '100%' }}>
//               <h3>All Available Policies:</h3>
//               <div style={{ display: 'flex', flexDirection: 'column', gap: '15px', alignItems: 'flex-start' }}>
//                 {allPolicies.map((policy) => (
//                   <PolicyCard key={policy.policyId} policy={policy} />
//                 ))}
//               </div>
//             </div>
//           )}
//           {!loading && !error && filteredPolicies.length === 0 && allPolicies.length === 0 && (
//             <p>No policies found. Try applying filters or fetching all policies.</p>
//           )}
//         </section>
//       </div>
//       {/* Optional Footer */}
//     </div>
//   );
// };

// export default CustomerDashboardPage;

import React, { useState,useCallback } from 'react';
import './CustomerDashboard.css'; // Import the new CSS file
import PolicyCard from './PolicyCard';
import CustomerNavbar from './CustomerNavbar';
import axios from 'axios';
 

const TEST_TOKEN = localStorage.getItem('userToken'); // Replace with your actual test token

const CustomerDashboardPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredPolicies, setFilteredPolicies] = useState([]);
  const [premiumFilter, setPremiumFilter] = useState('');
  const [validityFilter, setValidityFilter] = useState('');
  const [allPolicies, setAllPolicies] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const premiumRanges = [
    { label: 'Premium > 5000', value: 'greaterThan5000', filterFunc: (policy) => policy.premiumAmount > 5000 },
    { label: 'Premium < 5000', value: 'lessThan5000', filterFunc: (policy) => policy.premiumAmount < 5000 },
  ];
  const validityRanges = [
    { label: 'Validity > 5 Years', value: 'greaterThan5', filterFunc: (policy) => policy.validityPeriod > 5 },
    { label: 'Validity < 5 Years', value: 'lessThan5', filterFunc: (policy) => policy.validityPeriod < 5 },
  ];
  const [filtersApplied, setFiltersApplied] = useState(false);
  const [policiesFetched, setPoliciesFetched] = useState(false); // Track if fetchAllPolicies has been called
 
  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };
 

  // Function to handle API errors and set appropriate messages
   // Function to handle API errors and set appropriate messages
  const handleApiError = useCallback((error) => {
    if (error.response) {
      const errorData = error.response.data;
      if (errorData && errorData.message && errorData.message.includes('No policies found')) {
        return true; // Indicate no policies found
      } else {
        throw new Error(`Error fetching policies: ${error.response.statusText}`);
      }
    } else if (error.request) {
      throw new Error('Error: No response from the server.');
    } else {
      throw new Error(`Error: ${error.message}`);
    }
  }, []);
  const fetchAllPolicies = useCallback(async () => {
    setLoading(true);
    setError(null);
    setAllPolicies([]);
    setFilteredPolicies([]);
    setFiltersApplied(false);
    setPoliciesFetched(true); // Mark that fetchAllPolicies has been called
    try {
      const url = 'http://localhost:8082/api/v1/policies';
      const response = await axios.get(url, {
        headers: {
          Authorization: `Bearer ${TEST_TOKEN}`,
        },
      });
      setAllPolicies(response.data.data || []);
    } catch (error) {
      console.error('Error fetching all policies:', error);
      try {
        if (handleApiError(error)) {
          setAllPolicies([]);
          return;
        }
      } catch (apiError) {
        setError(apiError.message);
      }
    } finally {
      setLoading(false);
    }
  }, [handleApiError]);
 
 
  // Fetch all policies
  // const fetchAllPolicies = useCallback(async () => {
  //   setLoading(true);
  //   setError(null);
  //   setAllPolicies([]);
  //   setFilteredPolicies([]);
  //   setFiltersApplied(false);
  //   setPoliciesFetched(true); // Mark that fetchAllPolicies has been called
  //   try {
  //     const url = 'http://localhost:8082/api/v1/policies';
  //     const response = await fetch(url, {
  //       headers: {
  //         Authorization: `Bearer ${TEST_TOKEN}`,
  //       },
  //     });
  //     if (await handleApiError(response)) {
  //       setAllPolicies([]);
  //       return;
  //     }
  //     const responseData = await response.json();
  //     setAllPolicies(responseData.data || []);
  //   } catch (error) {
  //     console.error('Error fetching all policies:', error);
  //     setError('An error occurred while fetching all policies.');
  //   } finally {
  //     setLoading(false);
  //   }
  // }, [handleApiError]);
  // Filter policies based on search and selected filters
  // const filterPolicies = useCallback(async () => {
  //   setLoading(true);
  //   setError(null);
  //   setFilteredPolicies([]);
  //   setFiltersApplied(true);
 
  //   let url = '/api/v1/policies/filtered'; // Assuming a backend endpoint for filtering
  //   const queryParams = [];
  //   const activeFiltersForMessage = [];
 
  //   if (searchTerm) {
  //     queryParams.push(`nameStartsWith=${searchTerm}`);
  //     activeFiltersForMessage.push(`name starting with: '${searchTerm}'`);
  //   }
  //   if (premiumFilter) {
  //     const selectedRange = premiumRanges.find(range => range.value === premiumFilter);
  //     if (selectedRange) {
  //       queryParams.push(`premium=${selectedRange.value}`); // Adjust based on your backend API
  //       activeFiltersForMessage.push(`premium ${selectedRange.label.split(' ')[1] || ''} ${selectedRange.label.split(' ')[2] || ''}`);
  //     }
  //   }
  //   if (validityFilter) {
  //     const selectedRange = validityRanges.find(range => range.value === validityFilter);
  //     if (selectedRange) {
  //       queryParams.push(`validity=${selectedRange.value}`); // Adjust based on your backend API
  //       activeFiltersForMessage.push(`validity ${selectedRange.label.split(' ')[1] || ''} ${selectedRange.label.split(' ')[2] || ''}`);
  //     }
  //   }
 
  //   if (queryParams.length > 0) {
  //     url += `?${queryParams.join('&')}`;
  //   }
 
  //   try {
  //     const response = await fetch(url, {
  //       headers: {
  //         Authorization: `Bearer ${TEST_TOKEN}`,
  //       },
  //     });
 
  //     if (await handleApiError(response)) {
  //       setError(`No policies found with the given constraints: ${activeFiltersForMessage.join(', and ')}`);
  //       setFilteredPolicies([]); // Ensure filteredPolicies is empty when no results
  //       return;
  //     }
 
  //     const responseData = await response.json();
  //     setFilteredPolicies(responseData.data || []);
  //     setError(null); // Clear any previous "no policies found" message
 
  //   } catch (error) {
  //     console.error('Error fetching filtered policies:', error);
  //     setError('An error occurred while fetching policies.');
  //   } finally {
  //     setLoading(false);
  //   }
  // }, [searchTerm, premiumFilter, validityFilter, handleApiError, premiumRanges, validityRanges]);

  // Filter policies based on search and selected filters
  const filterPolicies = useCallback(async () => {
    setLoading(true);
    setError(null);
    setFilteredPolicies([]);
    setFiltersApplied(true);
 
    let url = '/api/v1/policies/filtered'; // Assuming a backend endpoint for filtering
    const queryParams = [];
    const activeFiltersForMessage = [];
 
    if (searchTerm) {
      queryParams.push(`nameStartsWith=${searchTerm}`);
      activeFiltersForMessage.push(`name starting with: '${searchTerm}'`);
    }
    if (premiumFilter) {
      const selectedRange = premiumRanges.find(range => range.value === premiumFilter);
      if (selectedRange) {
        queryParams.push(`premium=${selectedRange.value}`); // Adjust based on your backend API
        activeFiltersForMessage.push(`premium ${selectedRange.label.split(' ')[1] || ''} ${selectedRange.label.split(' ')[2] || ''}`);
      }
    }
    if (validityFilter) {
      const selectedRange = validityRanges.find(range => range.value === validityFilter);
      if (selectedRange) {
        queryParams.push(`validity=${selectedRange.value}`); // Adjust based on your backend API
        activeFiltersForMessage.push(`validity ${selectedRange.label.split(' ')[1] || ''} ${selectedRange.label.split(' ')[2] || ''}`);
      }
    }
 
    if (queryParams.length > 0) {
      url += `?${queryParams.join('&')}`;
    }
 
    try {
      const response = await axios.get(url, {
        headers: {
          Authorization: `Bearer ${TEST_TOKEN}`,
        },
      });
      setFilteredPolicies(response.data.data || []);
      setError(null); // Clear any previous "no policies found" message
    } catch (error) {
      console.error('Error fetching filtered policies:', error);
      try {
        if (handleApiError(error)) {
          setError(`No policies found with the given constraints: ${activeFiltersForMessage.join(', and ')}`);
          setFilteredPolicies([]); // Ensure filteredPolicies is empty when no results
          return;
        }
      } catch (apiError) {
        setError('An error occurred while fetching policies.');
      }
    } finally {
      setLoading(false);
    }
  }, [searchTerm, premiumFilter, validityFilter, handleApiError, premiumRanges, validityRanges]);
 
 
 
  const handleSearchSubmit = (e) => {
    e.preventDefault();
    filterPolicies();
  };
 
  const handlePremiumFilterChange = (e) => {
    setPremiumFilter(e.target.value);
  };
 
  const handleValidityFilterChange = (e) => {
    setValidityFilter(e.target.value);
  };
 
  const handleApplyFilters = () => {
    filterPolicies();
  };
 
  const handleClearFilters = () => {
    setSearchTerm('');
    setPremiumFilter('');
    setValidityFilter('');
    setFilteredPolicies([]);
    setError(null);
    setFiltersApplied(false);
  };
 

  return (
    <div className="custdb_layout">
      <div className="custdb_layout_background_image"></div>
      <header className="custdb_layout_header">
        <CustomerNavbar />
      </header>
      <div className="custdb_layout_content">
        <h2 className="custdb_dashboard_header">Uncover Your Perfect Policy</h2>
        <div className="custdb_input_card">
          <section className="custdb_search_section">
            <form onSubmit={handleSearchSubmit}>
              <input
                type="text"
                placeholder="Search by Policy Name"
                value={searchTerm}
                onChange={handleSearchChange}
                className="custdb_search_bar"
              />
              <button type="submit" className="custdb_search_button">
                Search
              </button>
            </form>
          </section>
          <section className="custdb_filter_section">
            <div className="custdb_dropdown_container">
              <label htmlFor="premium-filter" className="custdb_dropdown_label">Filter by Premium:</label>
              <select
                id="premium-filter"
                value={premiumFilter}
                onChange={handlePremiumFilterChange}
                className="custdb_dropdown_select"
              >
                <option value="">Select Premium Range</option>
                {premiumRanges.map((range, index) => (
                  <option key={index} value={range.value}>
                    {range.label}
                  </option>
                ))}
              </select>
            </div>
            <div className="custdb_dropdown_container">
              <label htmlFor="validity-filter" className="custdb_dropdown_label">Filter by Validity Period:</label>
              <select
                id="validity-filter"
                value={validityFilter}
                onChange={handleValidityFilterChange}
                className="custdb_dropdown_select"
              >
                <option value="">Select Validity Range</option>
                {validityRanges.map((range, index) => (
                  <option key={index} value={range.value}>
                    {range.label}
                  </option>
                ))}
              </select>
            </div>
            <div className="fetch-all-button-container">
              <button onClick={fetchAllPolicies} disabled={loading}>
                {loading ? 'Fetching All Policies...' : 'Fetch All Policies'}
              </button>
            </div>
            <button onClick={handleApplyFilters} className="apply-filters-button">
              Apply Filters
            </button>
            <button onClick={handleClearFilters} className="clear-filters-button">
              Clear Filters
            </button>
          </section>
        </div>
        {loading && <p>Loading policies...</p>}
        {error && <p className="custdb_error_message">Error: {error}</p>}
        <section className="custdb_output_card" style={{ width: '100%' }}>
          {!loading && !error && filteredPolicies.length > 0 && filtersApplied &&(
            <div>
              <h3 className="custdb_output_card_header">Filtered Policies:</h3>
              <div className="custdb_policies_grid">
                {filteredPolicies.map((policy) => (
                  <PolicyCard key={policy.policyId} policy={policy} className="custdb_policy_card" />
                ))}
              </div>
            </div>
          )}
          {!loading && error && filtersApplied && filteredPolicies.length === 0 && (
            <div>
              <h3 className="custdb_output_card_header">Didn't find what you want ? Check all policies!</h3>
              <div className="custdb_policies_grid">
              <button onClick={fetchAllPolicies} className="custdb_fetch_all_button">
            Click Here to View All the policies
          </button>
              </div>
            </div>
          )}
          {!loading && !error && policiesFetched && !filtersApplied && allPolicies.length > 0 && filteredPolicies.length === 0 && (
  <div className="custdb_output_card" style={{ width: '100%' }}>
    <h3 className="custdb_output_card_header">Available Policies:</h3>
    <div className="custdb_policies_grid"> {/* Use the grid class here */}
      {allPolicies.map((policy) => (
        <PolicyCard key={policy.policyId} policy={policy} className="custdb_policy_card" />
      ))}
    </div>
  </div>
)}
        </section>
      </div>
    </div>
  );
};

export default CustomerDashboardPage;