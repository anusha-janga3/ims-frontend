import React from 'react';
import { Link } from 'react-router-dom';
import './AdminDashboard.css';
import AdminNavBar from './AdminNavBar';
 
function AdminDashBoard() {
  return (
    <>
    <header className="transparent-header bg-white">
    <AdminNavBar />
      </header>
    <div className="home-page-container">
    <h1>Welcome Admin!</h1>
    <div className="button-container">
      <Link to="/agents" className="home-page-button agent-button">
        Manage Agents
      </Link>
      <Link to="/policies" className="home-page-button policies-button">
        Manage Policies
      </Link>
      <Link to="/assign-policy" className="home-page-button policy-button">
        Assign Policies
      </Link>
    </div>
  </div>
  </>
  );
}
 
export default AdminDashBoard;
 
 