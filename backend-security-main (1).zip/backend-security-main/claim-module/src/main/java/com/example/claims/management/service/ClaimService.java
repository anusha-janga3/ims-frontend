package com.example.claims.management.service;

import com.example.claims.management.client.PolicyClient; // Assuming you have a PolicyClient
import com.example.claims.management.client.CustomerClient; // Assuming you have a CustomerClient
import com.example.claims.management.client.AgentClient; // Assuming you have an AgentClient
import com.example.claims.management.client.AdminClient; // Assuming you have an AdminClient
import com.example.claims.management.dao.ClaimDao;
import com.example.claims.management.dto.AdminDTO;
import com.example.claims.management.dto.AgentDTO;
import com.example.claims.management.dto.ClaimDTO;
import com.example.claims.management.dto.CustomerDTO;
import com.example.claims.management.dto.PolicyDTO;
import com.example.claims.management.exceptions.ClaimNotFoundException;
import com.example.claims.management.exceptions.InvalidClaimStatusException;
import com.example.claims.management.exceptions.UserInputInValidException;
import com.example.claims.management.util.Claim;
import com.example.claims.management.util.ClaimStatus;
import com.example.claims.management.util.ResultResponse;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ClaimService {

    @Autowired
    private ClaimDao claimDao;

    @Autowired
    private PolicyClient policyClient;

    @Autowired
    private CustomerClient customerClient;

    @Autowired
    private AgentClient agentClient;

    @Autowired
    private AdminClient adminClient;
    
    public ClaimDTO fileClaim(ClaimDTO claimDTO) throws UserInputInValidException {
        log.info("Entering fileClaim method with claimDTO: {}", claimDTO);

        // Validation for UUID format
        validateUUID(claimDTO.getPolicyId(), "Policy ID");
        validateUUID(claimDTO.getCustomerId(), "Customer ID");
        validateUUID(claimDTO.getAgentId(), "Agent ID");
        validateUUID(claimDTO.getAdminId(), "Admin ID");

       
        // Check if a similar claim already exists
        boolean claimExists = claimDao.existsByPolicyIdAndCustomerId(
                claimDTO.getPolicyId().toString(),
                claimDTO.getCustomerId().toString()
        );

        if (claimExists) {
            log.warn("Duplicate claim filing attempted for Policy ID: {} and Customer ID: {}",
                     claimDTO.getPolicyId(), claimDTO.getCustomerId());
            throw new UserInputInValidException("A claim for this policy by this customer already exists.");
        }

        Claim claim = new Claim();
        claim.setClaimId(claimDTO.getClaimId());
        claim.setClaimAmount(claimDTO.getClaimAmount());
        claim.setPolicyId(claimDTO.getPolicyId().toString());
        claim.setCustomerId(claimDTO.getCustomerId().toString());
        claim.setAgentId(claimDTO.getAgentId().toString());
        claim.setAdminId(claimDTO.getAdminId().toString());
        claim.setStatus(ClaimStatus.UnderReview);
        claim.setCreatedAt(LocalDateTime.now());
        claim.setUpdatedAt(LocalDateTime.now());

        Claim savedClaim = claimDao.save(claim);
        log.info("Claim filed successfully: {}", savedClaim);
        log.info("Exiting fileClaim method.");
        return convertToDTO(savedClaim);
    }

    public void validateUUID(UUID uuid, String entityName) throws UserInputInValidException {
        if (uuid == null || uuid.toString().length() != 36) {
            throw new UserInputInValidException("Invalid UUID format for " + entityName + ". " + entityName + " must be a 36-character string.");
        }
    }

   

    public List<ClaimDTO> getClaims() {
        log.info("Retrieving all claims.");
        List<Claim> claims = claimDao.findAll();
        log.info("Retrieved {} claims.", claims.size());
        return claims.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    public List<ClaimDTO> getClaimsByStatus(ClaimStatus claimStatus) throws ClaimNotFoundException, InvalidClaimStatusException {
        log.info("Retrieving claims by status: {}", claimStatus);
        List<Claim> claims = claimDao.findByStatus(claimStatus);
        if (claims.isEmpty()) {
            throw new ClaimNotFoundException("No claims found with status: " + claimStatus);
        }
        log.info("Retrieved {} claims with status {}.", claims.size(), claimStatus);
        return claims.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    public ClaimDTO getClaimById(String id) throws ClaimNotFoundException {
        log.info("Retrieving claim by ID: {}", id);
        Claim claim = claimDao.findById(id).orElseThrow(() -> new ClaimNotFoundException("Claim not found "));
        log.info("Claim found: {}", claim);
        return convertToDTO(claim);
    }

    public List<ClaimDTO> findByCustomerId(String id) throws ClaimNotFoundException {
        log.info("Retrieving claims by customer ID: {}", id);
        List<Claim> claims = claimDao.findByCustomerId(id);
        if (claims.isEmpty()) {
            log.warn("No claims found for customer ID: {}", id);
            throw new ClaimNotFoundException("No claims found for customer ID: " + id);
        }
        log.info("Retrieved {} claims for customer ID: {}", claims.size(), id);
        return claims.stream().map(this::convertToDTO).collect(Collectors.toList());
    }
    
    public List<ClaimDTO> findByAgentId(String id) throws ClaimNotFoundException {
        log.info("Retrieving claims by Agent ID: {}", id);
        List<Claim> claims = claimDao.findByAgentId(id);
        if (claims.isEmpty()) {
            log.warn("No claims found for Agent ID: {}", id);
            throw new ClaimNotFoundException("No claims found for Agent ID: " + id);
        }
        log.info("Retrieved {} claims for Agent ID: {}", claims.size(), id);
        return claims.stream().map(this::convertToDTO).collect(Collectors.toList());
    }
    

    public List<ClaimDTO> getClaimsUpdatedYesterdayToToday() {
        LocalTime sixPM = LocalTime.of(18, 0);
        java.time.LocalDate yesterday = java.time.LocalDate.now().minusDays(1);
        java.time.LocalDate today = java.time.LocalDate.now();

        LocalDateTime yesterday6PM = yesterday.atTime(sixPM);
        LocalDateTime today6PM = today.atTime(sixPM);

        List<Claim> claims = claimDao.findByUpdatedAtBetween(yesterday6PM, today6PM);
        return claims.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public ClaimDTO convertToDTO(Claim claim) {
        if (claim == null) {
            return null;
        }

        ClaimDTO dto = new ClaimDTO();
        dto.setClaimId(claim.getClaimId());
        dto.setClaimAmount(claim.getClaimAmount());
        dto.setPolicyId(UUID.fromString(claim.getPolicyId()));
        dto.setCustomerId(UUID.fromString(claim.getCustomerId()));
        dto.setAgentId(UUID.fromString(claim.getAgentId()));
        dto.setAdminId(UUID.fromString(claim.getAdminId()));
        dto.setStatus(claim.getStatus());
        dto.setUpdatedAt(claim.getUpdatedAt());
        dto.setCreatedAt(claim.getCreatedAt());
        return dto;
    }
    
    /**
     * Processes daily claims, approving or rejecting them based on policy validity and claim amount.
     *
     * This method runs daily at midnight.
     */
    @Scheduled(cron = "0 0 0 * * ?")
    @Transactional
    public void processDailyClaims() {
    	
        log.info("Started daily claim processing.");
        LocalDate yesterday = LocalDate.now().minusDays(1);
        log.info("---"+yesterday.atStartOfDay()+"---"+LocalDate.now().atStartOfDay());
        List<Claim> claimsToProcess = claimDao.findByStatusAndCreatedAtBetween(
                ClaimStatus.UnderReview, yesterday.atStartOfDay(), LocalDate.now().atStartOfDay());

        claimsToProcess.forEach(claim -> {
            log.info("---"+ claim);
            ResponseEntity<ResultResponse<PolicyDTO>> response =  policyClient.getPolicyById(UUID.fromString(claim.getPolicyId()));
        	log.info("Policy service response body (raw): {}", response.getBody());
        	PolicyDTO policyDTO = response.getBody().getData();
            log.info("-"+UUID.fromString(claim.getPolicyId()));
            log.info("-"+policyDTO);

            if (policyDTO == null || !isValidPolicy(policyDTO)) {
                log.info("Policy is invalid for claim ID: {}", claim.getClaimId());
                claim.setStatus(ClaimStatus.Rejected);
                claim.setUpdatedAt(LocalDateTime.now());
                
            } else {
                if (isClaimAmountWithinTotalPolicyValue(claim, policyDTO)) {
                    claim.setStatus(ClaimStatus.Approved);
                    claim.setUpdatedAt(LocalDateTime.now());
                    log.info("Claim ID: {} approved.", claim.getClaimId());
                } else {
                    claim.setStatus(ClaimStatus.Rejected);
                    claim.setUpdatedAt(LocalDateTime.now());
                    log.info("Claim ID: {} rejected due to amount exceeding policy value.", claim.getClaimId());
                }
            }
            claimDao.save(claim);
            log.info("Claim processing completed for claim ID: {}", claim.getClaimId());
        });
        log.info("Completed daily claim processing.");
    }


    public boolean isValidPolicy(PolicyDTO policyDTO) {
        if(policyDTO == null || policyDTO.getCreatedAt() == null || policyDTO.getValidityPeriod() <0){
            return false;
        }

        LocalDate policyEndDate = policyDTO.getCreatedAt().toLocalDate().plusYears(policyDTO.getValidityPeriod());
        log.info("Policy end date: {}", policyEndDate);
        return policyEndDate.isAfter(LocalDate.now());
    }

    public boolean isClaimAmountWithinTotalPolicyValue(Claim claim, PolicyDTO policyDTO) {
        if(policyDTO == null || policyDTO.getCreatedAt() == null || policyDTO.getValidityPeriod() <0 || policyDTO.getPremiumAmount() == null){
            return false;
        }
        LocalDate policyEndDate = policyDTO.getCreatedAt().toLocalDate().plusYears(policyDTO.getValidityPeriod());
        long yearsOfValidity = ChronoUnit.YEARS.between(LocalDate.now(), policyEndDate);
        log.info("Years of validity: {}", yearsOfValidity);

        if (yearsOfValidity < 0) {
            return false;
        }

        BigDecimal totalPolicyValue = policyDTO.getPremiumAmount()
                .multiply(BigDecimal.valueOf(12))
                .multiply(BigDecimal.valueOf(yearsOfValidity + 1));

        return claim.getClaimAmount().compareTo(totalPolicyValue) <= 0;
    }
    
}