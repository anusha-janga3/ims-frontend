package com.example.claims.management.util;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "Claim")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@NamedQuery(query = "select c from Claim c where c.customerId = :customerId", name = "claim.findByCustomerId")
@NamedQuery(query = "select c from Claim c where c.status = :claimStatus order by c.createdAt desc", name = "claim.findByStatus")
public class Claim {

    @Id
    @Column(name = "claimId")
    private String claimId;

    @Column(name = "claimAmount", precision = 10, scale = 2, nullable = false)
    private BigDecimal claimAmount;

    @Column(name = "adminId", nullable = false)
    private String adminId;

    @Column(name = "agentId", nullable = false)
    private String agentId;

    @Column(name = "customerId", nullable = false)
    private String customerId;

    @Column(name = "policyId", nullable = false)
    private String policyId;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", columnDefinition = "ENUM('Filed', 'UnderReview', 'Approved', 'Rejected')")
    private ClaimStatus status = ClaimStatus.UnderReview;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    public void generateUuidAndCreatedAt() {
        this.claimId = UUID.randomUUID().toString();
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    public void updateUpdatedAt() {
        this.updatedAt = LocalDateTime.now();
    }
}