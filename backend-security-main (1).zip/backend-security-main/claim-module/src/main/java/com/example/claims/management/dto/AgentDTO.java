package com.example.claims.management.dto;

import java.time.LocalDateTime;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
 
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
 
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AgentDTO {
    
    private String agentId;

    private String name;
    
    private Long contactInfo;

    private String password;

    private String adminId;
    
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;
}