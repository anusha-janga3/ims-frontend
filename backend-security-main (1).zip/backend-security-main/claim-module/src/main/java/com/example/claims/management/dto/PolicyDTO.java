package com.example.claims.management.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import java.util.UUID;
 

 
import lombok.AllArgsConstructor;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
 

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PolicyDTO {
	
	private String policyId;

    private String coverageDetails;
 
    private int validityPeriod;

    private String name;
    
    private BigDecimal premiumAmount;
    
	private UUID adminId;
	
	private LocalDateTime createdAt;
 
	private LocalDateTime updatedAt;
}