package com.example.claims.management.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

 
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AdminDTO {
    
    private String adminId;
    
 
    private String name;
    

    private String email;
}
