package com.example.claims.management.client;

import com.example.claims.management.dto.PolicyDTO;
import com.example.claims.management.util.ResultResponse;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.UUID;

@FeignClient(name = "policy-service") 
public interface PolicyClient {

    @GetMapping("/api/v1/policies/{policyId}")
    ResponseEntity<ResultResponse<PolicyDTO>> getPolicyById(@PathVariable UUID policyId);
    // Add other policy-related endpoints as needed
}