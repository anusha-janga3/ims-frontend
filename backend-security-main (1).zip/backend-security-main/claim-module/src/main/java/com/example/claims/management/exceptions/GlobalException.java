package com.example.claims.management.exceptions;

import java.util.HashMap;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.example.claims.management.util.ResultResponse;

@ControllerAdvice
public class GlobalException {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ResultResponse> handleValidationError(MethodArgumentNotValidException e) {
        Map<String, String> validationError = new HashMap<>();
        for (FieldError error : e.getBindingResult().getFieldErrors()) {
            validationError.put(error.getField(), error.getDefaultMessage());
        }

        ResultResponse result = ResultResponse.builder().data(validationError).message("Validation error").build();
        return ResponseEntity.badRequest().body(result);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ResultResponse> handleException(Exception e) {
        ResultResponse result = ResultResponse.builder().message("An unexpected error occurred: " + e.getMessage()).build();
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(result);
    }
}