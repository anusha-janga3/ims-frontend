package com.example.claims.management.exceptions;

public class UserInputInValidException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public UserInputInValidException(String message) {
		super(message);
	}

}
