package com.example.claims.management.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

import org.springframework.validation.annotation.Validated;

import com.example.claims.management.util.ClaimStatus;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Data
@Validated
@JsonIgnoreProperties(ignoreUnknown=true)
public class ClaimDTO {


	private String claimId;

    @NotNull(message = "Claim amount cannot be null")
    @DecimalMin(value = "0.0", inclusive = false, message = "Claim amount must be greater than zero")
    private BigDecimal claimAmount;

    @NotNull(message = "Policy ID cannot be null")
    private UUID policyId;

    @NotNull(message = "Customer ID cannot be null")
    private UUID customerId;

    @NotNull(message = "Admin ID cannot be null")
    private UUID adminId;


    private UUID agentId;

    private ClaimStatus status;

    @PastOrPresent(message = "Updated at must be in the past or present")
    private LocalDateTime updatedAt;

    @PastOrPresent(message = "Created at must be in the past or present")
    private LocalDateTime createdAt;
}