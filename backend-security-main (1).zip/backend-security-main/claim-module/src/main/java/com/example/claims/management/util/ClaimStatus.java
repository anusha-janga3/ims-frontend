package com.example.claims.management.util;
public enum ClaimStatus {
	Filed,
	UnderReview,
	Approved,
	Rejected;

}

