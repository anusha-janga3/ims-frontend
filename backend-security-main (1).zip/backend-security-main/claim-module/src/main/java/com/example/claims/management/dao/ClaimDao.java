package com.example.claims.management.dao;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.claims.management.util.Claim;
import com.example.claims.management.util.ClaimStatus;

public interface ClaimDao extends JpaRepository<Claim , String> {
	/**
     * Finds all claims with the specified status.
     * This method utilizes a named query defined in the {@link com.example.claims.management.util.Claim} entity.
     * The named query is "claim.findByStatus", and it retrieves claims based on their status.
     * @param claimStatus The status of the claims to find.
     * @return A list of claims matching the specified status.
     */
    @Query(name = "claim.findByStatus")
    List<Claim> findByStatus(ClaimStatus claimStatus);

    /**
     * Finds all claims associated with a specific customer ID.
     * This method utilizes a named query defined in the {@link com.example.claims.management.util.Claim} entity.
     * The named query is "claim.findByCustomerId", and it retrieves claims based on their customer ID.
     * @param customerId The ID of the customer whose claims are to be retrieved.
     * @return A list of claims associated with the specified customer ID.
     */
    
    @Query(name = "claim.findByCustomerId")
    List<Claim> findByCustomerId(String customerId);
    
    List<Claim> findByAgentId(String agentId);
    
    /**
     * Finds all claims with the specified status and created within the given date range.
     * @param status      The status of the claims to find.
     * @param createdAtStart The start of the creation date range (inclusive).
     * @param createdAtEnd   The end of the creation date range (exclusive).
     * @return A list of claims matching the criteria.
     */
    List<Claim> findByStatusAndCreatedAtBetween(ClaimStatus status, LocalDateTime createdAtStart, LocalDateTime createdAtEnd);

    /**
     * Retrieves a list of Claim entities where the 'updatedAt' field falls within the specified date and time range.
     *
     * @param startDateTime The start of the date and time range (inclusive).
     * Must not be null.
     * @param endDateTime   The end of the date and time range (inclusive).
     * Must not be null.
     * @return A List of Claim entities that were updated within the given range.
     * Returns an empty list if no claims match the criteria.
     *
     * @throws IllegalArgumentException if either startDateTime or endDateTime is null.
     *
     */
    List<Claim> findByUpdatedAtBetween(LocalDateTime startDateTime, LocalDateTime endDateTime);

    
    boolean existsByPolicyIdAndCustomerId(String policyId, String customerId);
}
