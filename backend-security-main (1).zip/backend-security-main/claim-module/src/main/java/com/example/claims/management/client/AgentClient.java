package com.example.claims.management.client;

import com.example.claims.management.dto.AgentDTO;
import com.example.claims.management.util.ResultResponse;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.UUID;

@FeignClient(name = "agent-service") 
public interface AgentClient {

    @GetMapping("/api/v1/agents/{agentId}")
    ResponseEntity<ResultResponse<AgentDTO>> getAgentById(@PathVariable UUID agentId);
    // Add other agent-related endpoints as needed
}