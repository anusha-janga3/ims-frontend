//package com.example.claims.management.security;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.security.web.SecurityFilterChain;
//import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
//import org.springframework.web.cors.CorsConfiguration;
//import org.springframework.web.cors.CorsConfigurationSource;
//import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
//// import org.springframework.web.filter.CorsFilter; // Consider removing this
//
//@Configuration
//@EnableWebSecurity
//public class SecurityConfig {
//
//    @Autowired
//    private JwtFilter jwtFilter;
//
//    @Bean
//    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//
//        return http
//                .csrf(customizer -> customizer.disable())
//                .authorizeHttpRequests(request -> request
//                        // Publicly accessible endpoints
//                        .requestMatchers(
//                                "/api/v1/claim/claims/{status}",
//                                "/api/v1/claim/claim/{claimId}"
//                        ).hasAnyAuthority("ADMIN", "CUSTOMER", "AGENT")
//
//                        // Agent specific endpoints
//                        .requestMatchers("/api/v1/claim/{customerId}/customer-claims")
//                        .hasAuthority("AGENT")
//
//                        // Agent specific endpoints
//                        .requestMatchers("/api/v1/claim/{agentId}/agent-claims")
//                        .hasAuthority("AGENT")
//
//                        // Shared endpoints
//                        .requestMatchers("/api/v1/claim/claim")
//                        .hasAnyAuthority("CUSTOMER", "AGENT")
//
//                        // Admin specific endpoints
//                        .requestMatchers("/api/v1/claim/claims",
//                                "/api/v1/updated-yesterday-to-today")
//                        .hasAuthority("ADMIN")
//
//                        // All other requests need authentication
//                        .anyRequest().authenticated())
//                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)
//                .cors(cors -> cors.configurationSource(corsConfigurationSource())) // Enable CORS using the bean
//                .build();
//    }
//
//    // @Bean
//    // public CorsFilter corsFilter() { // Consider removing this
//    //     CorsConfiguration corsConfiguration = new CorsConfiguration();
//    //     corsConfiguration.addAllowedOrigin("http://localhost:3000"); // Allow React frontend
//    //     corsConfiguration.addAllowedHeader("*"); // Allow all headers
//    //     corsConfiguration.addAllowedMethod("*"); // Allow all HTTP methods
//    //     UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
//    //     source.registerCorsConfiguration("/**", corsConfiguration);
//    //     return new CorsFilter(source);
//    // }
//
//    @Bean
//
//    public CorsConfigurationSource corsConfigurationSource() {
//
//        CorsConfiguration configuration = new CorsConfiguration();
//
//        configuration.setAllowedOrigins(java.util.List.of("http://localhost:3000"));
//
//        configuration.setAllowedHeaders(java.util.List.of("*"));
//
//        configuration.setAllowedMethods(java.util.List.of("GET", "POST", "PUT", "DELETE", "OPTIONS")); // Be explicit
//
//        configuration.setAllowCredentials(true);
//
//        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
//
//        source.registerCorsConfiguration("/**", configuration);
//
//        return source;
//
//    }
// 
//
//    @Bean
//    AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
//        return config.getAuthenticationManager();
//    }
//
//    @Bean
//    PasswordEncoder passwordEncoder() {
//        return new BCryptPasswordEncoder(12);
//    }
//}






package com.example.claims.management.security;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Autowired
    private JwtFilter jwtFilter;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        return http .cors(cors -> cors.configurationSource(corsConfigurationSource())) 
        		.csrf(customizer -> customizer.disable()) 
        		.csrf(customizer -> customizer.disable())
                .authorizeHttpRequests(auth -> auth
                		
                		.requestMatchers("/api/v1/claim/updated-yesterday-to-today").permitAll()
                        // Publicly accessible endpoints with roles
                        .requestMatchers(
                                "/api/v1/claim/claims/{status}",
                                "/api/v1/claim/claim/{claimId}"
                        ).hasAnyAuthority("ADMIN", "CUSTOMER", "AGENT")

                        // Agent-specific endpoints
                        .requestMatchers("/api/v1/claim/{customerId}/customer-claims","/api/v1/claim/claim")
                        .hasAuthority("CUSTOMER")
                        .requestMatchers("/api/v1/claim/{agentId}/agent-claims")
                        .hasAuthority("AGENT")

                        // Shared endpoints (CUSTOMER, AGENT)
                        // Admin-specific endpoints
                        .requestMatchers("/api/v1/claim/claims").hasAuthority("ADMIN")

                        // All other requests need to be authenticated
                        .anyRequest().authenticated())
                
                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class) // Add JWT filter before auth filter
                .build();
    }

    @Bean
    CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(Arrays.asList("http://localhost:3000")); // Allow requests from React app
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        configuration.setAllowedHeaders(Arrays.asList("Authorization", "Content-Type", "X-Requested-With", "Accept"));
        configuration.setAllowCredentials(true);
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration); // Apply CORS to all endpoints
        return source;
    }
}
 
//
//
//    @Bean
//    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
//        return config.getAuthenticationManager();
//    }
//
//    @Bean
//    public PasswordEncoder passwordEncoder() {
//        return new BCryptPasswordEncoder(12); // Use BCrypt with strength 12
//    }
//}
