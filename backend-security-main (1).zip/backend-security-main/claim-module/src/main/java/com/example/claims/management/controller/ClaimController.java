
package com.example.claims.management.controller;

import com.example.claims.management.dto.ClaimDTO;
import com.example.claims.management.exceptions.*;
import com.example.claims.management.service.ClaimService;
import com.example.claims.management.util.Claim;
import com.example.claims.management.util.ClaimStatus;
import com.example.claims.management.util.ResultResponse;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * ClaimController handles all claim-related operations.
 * 
 * Author: Janga Anusha
 */

@RestController
@CrossOrigin("http://localhost:3000")
@Slf4j
@RequestMapping("/api/v1/claim")
public class ClaimController {

    @Autowired
    private ClaimService claimService;
    
    /**
     * This method is used to file a claim.
     * It will return ResponseEntity.
     * 
     * @param claim the claim details to be filed
     * @return ResponseEntity containing the result of the claim filing operation
     */
    @PostMapping("/claim")
    public ResponseEntity<ResultResponse<ClaimDTO>> fileClaim(@Valid @RequestBody ClaimDTO claim) {
        log.info("Received request to file claim: {}", claim);
        try {
            ClaimDTO filedClaim = claimService.fileClaim(claim);
            ResultResponse<ClaimDTO> response = ResultResponse.<ClaimDTO>builder()
                    .data(filedClaim)
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (PolicyNotFoundException | AdminNotFoundException | CustomerNotFoundException e) {
            log.error("Claim filing failed: {}", e.getMessage());
            ResultResponse<ClaimDTO> response = ResultResponse.<ClaimDTO>builder()
                    .message(e.getMessage())
                    .data(null)
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (InvalidClaimException e) {
            log.error("Claim filing failed: {}", e.getMessage());
            ResultResponse<ClaimDTO> response = ResultResponse.<ClaimDTO>builder()
                    .message(e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        } 
    }

    /**
     * This method is used to get all claims.
     * It will return ResponseEntity.
     * 
     * @return ResponseEntity containing the list of all claims
     */
    @GetMapping("/claims")
    public ResponseEntity<ResultResponse<List<ClaimDTO>>> getClaims() {
        log.info("Received request to get all claims");
        
            List<ClaimDTO> claims = claimService.getClaims();
            ResultResponse<List<ClaimDTO>> response = ResultResponse.<List<ClaimDTO>>builder()
                    .data(claims)
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.OK);
        
    }

    /**
     * This method is used to get claims by status.
     * It will return ResponseEntity.
     * 
     * @param status the status of the claims to be retrieved
     * @return ResponseEntity containing the list of claims with the specified status
     */
    @GetMapping("/claims/{status}")
    public ResponseEntity<ResultResponse<List<ClaimDTO>>> getClaimByStatus(@PathVariable String status) {
        log.info("Received request to get claims by status: {}", status);
        try {
            ClaimStatus claimStatus = ClaimStatus.valueOf(status);
            List<ClaimDTO> claims = claimService.getClaimsByStatus(claimStatus);
            ResultResponse<List<ClaimDTO>> response = ResultResponse.<List<ClaimDTO>>builder()
                    .data(claims)
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (InvalidClaimStatusException e) {
            ResultResponse<List<ClaimDTO>> response = ResultResponse.<List<ClaimDTO>>builder()
                    .message(e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        } catch (ClaimNotFoundException e) {
            ResultResponse<List<ClaimDTO>> response = ResultResponse.<List<ClaimDTO>>builder()
                    .message(e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
    }

    /**
     * This method is used to get a claim by its ID.
     * It will return ResponseEntity.
     * 
     * @param claimId the ID of the claim to be retrieved
     * @return ResponseEntity containing the details of the specified claim
     */
    @GetMapping("/claim/{claimId}")
    public ResponseEntity<ResultResponse<ClaimDTO>> getClaimById(@PathVariable String claimId) {
        log.info("Received request to get claims by id: {}", claimId);
        try {
            ClaimDTO claim = claimService.getClaimById(claimId);
            ResultResponse<ClaimDTO> response = ResultResponse.<ClaimDTO>builder()
                    .data(claim)
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (ClaimNotFoundException e) {
            ResultResponse<ClaimDTO> response = ResultResponse.<ClaimDTO>builder()
                    .message(e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
    }

    /**
     * This method is used to get claims by customer ID.
     * It will return ResponseEntity.
     * 
     * @param customerId the ID of the customer whose claims are to be retrieved
     * @return ResponseEntity containing the list of claims for the specified customer
     */
    @GetMapping("/{customerId}/customer-claims")
    public ResponseEntity<ResultResponse<List<ClaimDTO>>> getClaimByCustomerId(@PathVariable String customerId) {
        log.info("Received request to get claims by customer id: {}", customerId);
        try {
            List<ClaimDTO> claims = claimService.findByCustomerId(customerId);
            ResultResponse<List<ClaimDTO>> response = ResultResponse.<List<ClaimDTO>>builder()
                    .data(claims)
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (ClaimNotFoundException e) {
            ResultResponse<List<ClaimDTO>> response = ResultResponse.<List<ClaimDTO>>builder()
                    .message(e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } 
    }
    
    @GetMapping("/{agentId}/agent-claims")
    public ResponseEntity<ResultResponse<List<ClaimDTO>>> getClaimByAgentId(@PathVariable String agentId) {
        log.info("Received request to get claims by agent id: {}", agentId);
        try {
            List<ClaimDTO> claims = claimService.findByAgentId(agentId);
            ResultResponse<List<ClaimDTO>> response = ResultResponse.<List<ClaimDTO>>builder()
                    .data(claims)
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (ClaimNotFoundException e) {
            ResultResponse<List<ClaimDTO>> response = ResultResponse.<List<ClaimDTO>>builder()
                    .message(e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } 
    }
    
    @GetMapping("/updated-yesterday-to-today")
    public ResponseEntity<ResultResponse<List<ClaimDTO>>> getClaimsUpdatedYesterdayToToday() {
        log.info("Received request to get claims updated yesterday to today");
        try {
            List<ClaimDTO> claims = claimService.getClaimsUpdatedYesterdayToToday();
            ResultResponse<List<ClaimDTO>> response = ResultResponse.<List<ClaimDTO>>builder()
                    .data(claims)
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build();
            log.info("--" + claims);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (ClaimNotFoundException e) {
            ResultResponse<List<ClaimDTO>> response = ResultResponse.<List<ClaimDTO>>builder()
                    .message(e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
    }
    
    
}
//    @PostMapping("/process-daily-claims")
//    public ResponseEntity<ResultResponse<String>> processDailyClaims() {
//        log.info("Received request to manually trigger daily claim processing.");
//        try {
//            claimService.processDailyClaims();
//            return ResponseEntity.ok(ResultResponse.<String>builder()
//                    .data("Daily claims processing triggered successfully.")
//                    .success(true)
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        } catch (Exception e) {
//            log.error("Error processing daily claims:", e);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<String>builder()
//                    .message("Error processing daily claims: " + e.getMessage())
//                    .success(false)
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        }
//    }
    
