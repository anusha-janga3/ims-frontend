package com.example.claims.management.exceptions;

public class ClaimNotFoundException extends RuntimeException{

	
	private static final long serialVersionUID = 1L;

	public ClaimNotFoundException(String message) {
		super(message);
	}
}
