package com.example.claims.management;

import com.example.claims.management.client.AgentClient;
import com.example.claims.management.client.AdminClient;
import com.example.claims.management.client.CustomerClient;
import com.example.claims.management.client.PolicyClient;
import com.example.claims.management.dao.ClaimDao;
import com.example.claims.management.dto.AdminDTO;
import com.example.claims.management.dto.AgentDTO;
import com.example.claims.management.dto.ClaimDTO;
import com.example.claims.management.dto.CustomerDTO;
import com.example.claims.management.dto.PolicyDTO;
import com.example.claims.management.exceptions.ClaimNotFoundException;
import com.example.claims.management.exceptions.InvalidClaimStatusException;
import com.example.claims.management.exceptions.UserInputInValidException;
import com.example.claims.management.service.ClaimService;
import com.example.claims.management.util.Claim;
import com.example.claims.management.util.ClaimStatus;
import com.example.claims.management.util.ResultResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ClaimServiceSpringBootTest {

    @Mock
    private ClaimDao claimDao;

    @Mock
    private PolicyClient policyClient;

    @Mock
    private CustomerClient customerClient;

    @Mock
    private AgentClient agentClient;

    @Mock
    private AdminClient adminClient;

    @InjectMocks
    private ClaimService claimService;

    private ClaimDTO claimDTO;
    private Claim claim;
    private PolicyDTO policyDTO;

    @BeforeEach
    void setUp() {
        claimDTO = new ClaimDTO();
        claimDTO.setClaimId("claim-123");
        claimDTO.setClaimAmount(BigDecimal.valueOf(1000));
        claimDTO.setPolicyId(UUID.randomUUID());
        claimDTO.setCustomerId(UUID.randomUUID());
        claimDTO.setAgentId(UUID.randomUUID());
        claimDTO.setAdminId(UUID.randomUUID());

        claim = new Claim();
        claim.setClaimId("claim-123");
        claim.setClaimAmount(BigDecimal.valueOf(1000));
        claim.setPolicyId(claimDTO.getPolicyId().toString());
        claim.setCustomerId(claimDTO.getCustomerId().toString());
        claim.setAgentId(claimDTO.getAgentId().toString());
        claim.setAdminId(claimDTO.getAdminId().toString());
        claim.setStatus(ClaimStatus.UnderReview);
        claim.setCreatedAt(LocalDateTime.now());
        claim.setUpdatedAt(LocalDateTime.now());

        policyDTO = new PolicyDTO();
        policyDTO.setPolicyId(claim.getPolicyId());
        policyDTO.setCreatedAt(LocalDateTime.now().minusYears(1));
        policyDTO.setValidityPeriod(2);
        policyDTO.setPremiumAmount(BigDecimal.valueOf(500));
    }

    @Test
    void fileClaim_Success() throws UserInputInValidException {
        AdminDTO adminDTO = new AdminDTO(); // Initialize AdminDTO
        adminDTO.setAdminId(claimDTO.getAdminId().toString());

        ResponseEntity<ResultResponse<PolicyDTO>> policyResponse = ResponseEntity.ok(ResultResponse.<PolicyDTO>builder().data(policyDTO).build());
        ResponseEntity<ResultResponse<CustomerDTO>> customerResponse = ResponseEntity.ok(ResultResponse.<CustomerDTO>builder().data(new CustomerDTO()).build());
        ResponseEntity<ResultResponse<AgentDTO>> agentResponse = ResponseEntity.ok(ResultResponse.<AgentDTO>builder().data(new AgentDTO()).build());
        ResponseEntity<ResultResponse<AdminDTO>> adminResponse = ResponseEntity.ok(ResultResponse.<AdminDTO>builder().data(adminDTO).build());

        when(policyClient.getPolicyById(any(UUID.class))).thenReturn(policyResponse);
        when(customerClient.getCustomerById(any(UUID.class))).thenReturn(customerResponse);
        when(agentClient.getAgentById(any(UUID.class))).thenReturn(agentResponse);
        when(adminClient.getAdminById(any(UUID.class))).thenReturn(adminResponse);
        when(claimDao.save(any(Claim.class))).thenReturn(claim);

        ClaimDTO result = claimService.fileClaim(claimDTO);

        assertNotNull(result);
        assertEquals(claimDTO.getClaimId(), result.getClaimId());
        verify(claimDao, times(1)).save(any(Claim.class));
    }

    @Test
    void fileClaim_EntityNotFound() {
        when(policyClient.getPolicyById(any(UUID.class))).thenReturn(ResponseEntity.notFound().build());
        assertThrows(UserInputInValidException.class, () -> claimService.fileClaim(claimDTO));
    }

    @Test
    void getClaims_Success() {
        when(claimDao.findAll()).thenReturn(Arrays.asList(claim));
        List<ClaimDTO> result = claimService.getClaims();
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
        assertEquals(claimDTO.getClaimId(), result.get(0).getClaimId());
    }

    @Test
    void getClaimsByStatus_Success() throws ClaimNotFoundException, InvalidClaimStatusException {
        when(claimDao.findByStatus(any(ClaimStatus.class))).thenReturn(Arrays.asList(claim));
        List<ClaimDTO> result = claimService.getClaimsByStatus(ClaimStatus.UnderReview);
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
        assertEquals(claimDTO.getClaimId(), result.get(0).getClaimId());
    }

    @Test
    void getClaimsByStatus_NotFound() {
        when(claimDao.findByStatus(any(ClaimStatus.class))).thenReturn(Arrays.asList());
        assertThrows(ClaimNotFoundException.class, () -> claimService.getClaimsByStatus(ClaimStatus.Approved));
    }

    @Test
    void getClaimById_Success() throws ClaimNotFoundException {
        when(claimDao.findById(anyString())).thenReturn(Optional.of(claim));
        ClaimDTO result = claimService.getClaimById("claim-123");
        assertNotNull(result);
        assertEquals(claimDTO.getClaimId(), result.getClaimId());
    }

    @Test
    void getClaimById_NotFound() {
        when(claimDao.findById(anyString())).thenReturn(Optional.empty());
        assertThrows(ClaimNotFoundException.class, () -> claimService.getClaimById("nonexistent"));
    }

    @Test
    void findByCustomerId_Success() throws ClaimNotFoundException {
        when(claimDao.findByCustomerId(anyString())).thenReturn(Arrays.asList(claim));
        List<ClaimDTO> result = claimService.findByCustomerId(claim.getCustomerId());
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
        assertEquals(claimDTO.getClaimId(), result.get(0).getClaimId());
    }

    @Test
    void findByCustomerId_NotFound() {
        when(claimDao.findByCustomerId(anyString())).thenReturn(Arrays.asList());
        assertThrows(ClaimNotFoundException.class, () -> claimService.findByCustomerId("nonexistent"));
    }

    @Test
    void findByAgentId_Success() throws ClaimNotFoundException {
        when(claimDao.findByAgentId(anyString())).thenReturn(Arrays.asList(claim));
        List<ClaimDTO> result = claimService.findByAgentId(claim.getAgentId());
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
        assertEquals(claimDTO.getClaimId(), result.get(0).getClaimId());
    }

    @Test
    void findByAgentId_NotFound() {
        when(claimDao.findByAgentId(anyString())).thenReturn(Arrays.asList());
        assertThrows(ClaimNotFoundException.class, () -> claimService.findByAgentId("nonexistent"));
    }

    @Test
    void getClaimsUpdatedYesterdayToToday_Success() {
        when(claimDao.findByUpdatedAtBetween(any(LocalDateTime.class), any(LocalDateTime.class))).thenReturn(Arrays.asList(claim));
        List<ClaimDTO> result = claimService.getClaimsUpdatedYesterdayToToday();
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
        assertEquals(claimDTO.getClaimId(), result.get(0).getClaimId());
    }


    @Test
    void convertToDTO_Null() {
        ClaimDTO result = claimService.convertToDTO(null);
        assertNull(result);
    }

    @Test
    void processDailyClaims_Approve() {
        Claim claimToProcess = new Claim();
        claimToProcess.setClaimId("claim-to-process");
        claimToProcess.setClaimAmount(BigDecimal.valueOf(1000));
        claimToProcess.setPolicyId(policyDTO.getPolicyId().toString());
        claimToProcess.setCustomerId(UUID.randomUUID().toString());
        claimToProcess.setAgentId(UUID.randomUUID().toString());
        claimToProcess.setAdminId(UUID.randomUUID().toString());
        claimToProcess.setStatus(ClaimStatus.UnderReview);
        claimToProcess.setCreatedAt(LocalDate.now().minusDays(1).atStartOfDay());
        claimToProcess.setUpdatedAt(LocalDateTime.now());

        ResponseEntity<ResultResponse<PolicyDTO>> policyResponse = ResponseEntity.ok(ResultResponse.<PolicyDTO>builder().data(policyDTO).build());

        when(claimDao.findByStatusAndCreatedAtBetween(eq(ClaimStatus.UnderReview), any(LocalDateTime.class), any(LocalDateTime.class)))
                .thenReturn(Arrays.asList(claimToProcess));
        when(policyClient.getPolicyById(any(UUID.class))).thenReturn(policyResponse);

        claimService.processDailyClaims();

        verify(claimDao, times(1)).save(argThat(claimArg -> claimArg.getStatus() == ClaimStatus.Approved));
    }

    @Test
    void processDailyClaims_Reject_InvalidPolicy() {
        Claim claimToProcess = new Claim();
        claimToProcess.setClaimId("claim-to-process");
        claimToProcess.setClaimAmount(BigDecimal.valueOf(1000));
        claimToProcess.setPolicyId(policyDTO.getPolicyId().toString());
        claimToProcess.setCustomerId(UUID.randomUUID().toString());
        claimToProcess.setAgentId(UUID.randomUUID().toString());
        claimToProcess.setAdminId(UUID.randomUUID().toString());
        claimToProcess.setStatus(ClaimStatus.UnderReview);
        claimToProcess.setCreatedAt(LocalDate.now().minusDays(1).atStartOfDay());
        claimToProcess.setUpdatedAt(LocalDateTime.now());

        PolicyDTO invalidPolicyDTO = new PolicyDTO();
        invalidPolicyDTO.setCreatedAt(LocalDateTime.now().minusYears(3));
        invalidPolicyDTO.setValidityPeriod(2);
        invalidPolicyDTO.setPremiumAmount(BigDecimal.valueOf(500));

        ResponseEntity<ResultResponse<PolicyDTO>> policyResponse = ResponseEntity.ok(ResultResponse.<PolicyDTO>builder().data(invalidPolicyDTO).build());

        when(claimDao.findByStatusAndCreatedAtBetween(eq(ClaimStatus.UnderReview), any(LocalDateTime.class), any(LocalDateTime.class)))
                .thenReturn(Arrays.asList(claimToProcess));
        when(policyClient.getPolicyById(any(UUID.class))).thenReturn(policyResponse);

        claimService.processDailyClaims();

        verify(claimDao, times(1)).save(argThat(claimArg -> claimArg.getStatus() == ClaimStatus.Rejected));
    }

    public boolean isClaimAmountWithinTotalPolicyValue(Claim claim, PolicyDTO policyDTO) {
        if (policyDTO == null || policyDTO.getCreatedAt() == null || policyDTO.getValidityPeriod() < 0 || policyDTO.getPremiumAmount() == null) {
            return false;
        }
        LocalDate policyEndDate = policyDTO.getCreatedAt().toLocalDate().plusYears(policyDTO.getValidityPeriod());
        long yearsOfValidity = ChronoUnit.YEARS.between(LocalDate.now(), policyEndDate);

        if (yearsOfValidity < 0) {
            return false;
        }

        BigDecimal totalPolicyValue = policyDTO.getPremiumAmount()
                .multiply(BigDecimal.valueOf(12))
                .multiply(BigDecimal.valueOf(yearsOfValidity + 1));


        return claim.getClaimAmount().compareTo(totalPolicyValue) <= 0;
    }

    @Test
    void processDailyClaims_Reject_AmountExceedsPolicy() {
        Claim claimToProcess = new Claim();
        claimToProcess.setClaimId("claim-to-process");
        claimToProcess.setClaimAmount(BigDecimal.valueOf(10000));
        claimToProcess.setPolicyId(policyDTO.getPolicyId().toString());
        claimToProcess.setCustomerId(UUID.randomUUID().toString());
        claimToProcess.setAgentId(UUID.randomUUID().toString());
        claimToProcess.setAdminId(UUID.randomUUID().toString());
        claimToProcess.setStatus(ClaimStatus.UnderReview);
        claimToProcess.setCreatedAt(LocalDate.now().minusDays(1).atStartOfDay());
        claimToProcess.setUpdatedAt(LocalDateTime.now());

        policyDTO.setPremiumAmount(BigDecimal.valueOf(100)); //Example premium amount.
        ResponseEntity<ResultResponse<PolicyDTO>> policyResponse = ResponseEntity.ok(ResultResponse.<PolicyDTO>builder().data(policyDTO).build());

        when(claimDao.findByStatusAndCreatedAtBetween(eq(ClaimStatus.UnderReview), any(LocalDateTime.class), any(LocalDateTime.class)))
                .thenReturn(Arrays.asList(claimToProcess));
        when(policyClient.getPolicyById(any(UUID.class))).thenReturn(policyResponse);

        claimService.processDailyClaims();

        verify(claimDao, times(1)).save(argThat(claimArg -> claimArg.getStatus() == ClaimStatus.Rejected));
    }

    @Test
    void isValidPolicy_Valid() {
        assertTrue(claimService.isValidPolicy(policyDTO));
    }

    @Test
    void isValidPolicy_Invalid_NullDTO() {
        assertFalse(claimService.isValidPolicy(null));
    }

    @Test
    void isValidPolicy_Invalid_Expired() {
        PolicyDTO expiredPolicyDTO = new PolicyDTO();
        expiredPolicyDTO.setCreatedAt(LocalDateTime.now().minusYears(3));
        expiredPolicyDTO.setValidityPeriod(2);
        assertFalse(claimService.isValidPolicy(expiredPolicyDTO));
    }

    @Test
    void isClaimAmountWithinTotalPolicyValue_Valid() {
        assertTrue(claimService.isClaimAmountWithinTotalPolicyValue(claim, policyDTO));
    }

    @Test
    void isClaimAmountWithinTotalPolicyValue_Invalid_NullDTO() {
        assertFalse(claimService.isClaimAmountWithinTotalPolicyValue(claim, null));
    }

    @Test
    void isClaimAmountWithinTotalPolicyValue_Invalid_AmountExceeds() {
        claim.setClaimAmount(BigDecimal.valueOf(10000000));
        assertFalse(claimService.isClaimAmountWithinTotalPolicyValue(claim, policyDTO));
    }

    @Test
    void isClaimAmountWithinTotalPolicyValue_Invalid_NegativeValidity() {
        PolicyDTO invalidPolicyDTO = new PolicyDTO();
        invalidPolicyDTO.setCreatedAt(LocalDateTime.now().minusYears(1));
        invalidPolicyDTO.setValidityPeriod(-1);
        invalidPolicyDTO.setPremiumAmount(BigDecimal.valueOf(500));
        assertFalse(claimService.isClaimAmountWithinTotalPolicyValue(claim, invalidPolicyDTO));
    }
}