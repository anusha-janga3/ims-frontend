package com.example.auth;
 
import com.example.auth.client.AgentClient;
import com.example.auth.client.CustomerClient;
import com.example.auth.dto.AgentDTO;
import com.example.auth.dto.CustomerDTO;
import com.example.auth.dto.UserDTO;
import com.example.auth.enums.Roles;
import com.example.auth.exception.UserAlreadyExistsException;
import com.example.auth.exception.UserNotFoundException;
import com.example.auth.model.User;
import com.example.auth.repository.UserRepository;
import com.example.auth.service.JWTService;
import com.example.auth.service.UserService;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
 
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
 
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
 
@ExtendWith(MockitoExtension.class)
public class AuthModuleApplicationTests {
 
    @Mock
    private UserRepository userRepository;
 
    @Mock
    private PasswordEncoder passwordEncoder;
 
    @Mock
    private JWTService jwtService;
 
    @Mock
    private AuthenticationManager authManager;
 
    @Mock
    private CustomerClient customerClient;
 
    @Mock
    private AgentClient agentClient;
    
 
    @InjectMocks
    private UserService userService;
 
    private User user;
    private UserDTO userDTO;
    private CustomerDTO customerDTO;
    private AgentDTO agentDTO;
 
    @BeforeEach
    void setUp() {
        user = new User();
        user.setUserId(UUID.randomUUID().toString());
        user.setEmail("test@example.com");
        user.setPassword("encodedPassword");
        user.setRole(Roles.CUSTOMER);
 
        userDTO = new UserDTO();
        userDTO.setUserId(user.getUserId());
        userDTO.setEmail(user.getEmail());
        userDTO.setPassword("password");
        userDTO.setRole(user.getRole());
 
        customerDTO = new CustomerDTO();
        customerDTO.setEmail(user.getEmail());
        customerDTO.setPassword("password");
        customerDTO.setName("Test Customer");
        customerDTO.setAddress("Test Address");
        customerDTO.setPhone("1234567890");
        customerDTO.setCustomerId(user.getUserId()); // Set customerId to match user's id
 
        agentDTO = new AgentDTO();
        agentDTO.setEmail(user.getEmail());
        agentDTO.setPassword("password");
        agentDTO.setName("Test Agent");
        agentDTO.setContactInfo("0987654321");
        agentDTO.setAdminId("1a0f9e24-db82-4499-bb71-610319d68c6d");
        agentDTO.setAgentId(user.getUserId()); // Set agentId to match user's id
    }
 
    @Test
    void getUserById_existingId_returnsUserDTO() {
        when(userRepository.findById(user.getUserId())).thenReturn(Optional.of(user));
 
        UserDTO result = userService.getUserById(user.getUserId());
 
        assertNotNull(result);
        assertEquals(user.getUserId(), result.getUserId());
        assertEquals(user.getEmail(), result.getEmail());
        assertNull(result.getPassword());
        assertEquals(user.getRole(), result.getRole());
    }
 
    @Test
    void getUserById_nonExistingId_throwsUserNotFoundException() {
        when(userRepository.findById(anyString())).thenReturn(Optional.empty());
 
        assertThrows(UserNotFoundException.class, () -> userService.getUserById(UUID.randomUUID().toString()));
    }
 
    @Test
    void registerAdmin_newAdmin_returnsUserDTO() {
        when(userRepository.findByEmail(userDTO.getEmail())).thenReturn(Optional.empty());
        when(passwordEncoder.encode(userDTO.getPassword())).thenReturn("encodedPassword");
 
        // Create a User object with ADMIN role to simulate the saved admin user
        User savedAdmin = new User();
        savedAdmin.setUserId("1a0f9e24-db82-4499-bb71-610319d68c6d"); // Matches the hardcoded ID in UserService
        savedAdmin.setEmail(userDTO.getEmail());
        savedAdmin.setPassword("encodedPassword");
        savedAdmin.setRole(Roles.ADMIN);
 
        when(userRepository.save(any(User.class))).thenReturn(savedAdmin);
 
        UserDTO result = userService.registerAdmin(userDTO);
 
        assertNotNull(result);
        assertEquals(savedAdmin.getUserId(), result.getUserId());
        assertEquals(savedAdmin.getEmail(), result.getEmail());
        assertNull(result.getPassword());
        assertEquals(Roles.ADMIN, result.getRole());
        verify(userRepository, times(1)).save(any(User.class));
    }
 
    @Test
    void registerAdmin_existingAdmin_throwsUserAlreadyExistsException() {
        when(userRepository.findByEmail(userDTO.getEmail())).thenReturn(Optional.of(user));
 
        assertThrows(UserAlreadyExistsException.class, () -> userService.registerAdmin(userDTO));
        verify(userRepository, never()).save(any(User.class));
    }
 
    @Test
    void registerCustomer_newCustomer_returnsUserDTOAndCallsCustomerClient() {
        when(userRepository.findByEmail(customerDTO.getEmail())).thenReturn(Optional.empty());
        when(passwordEncoder.encode(customerDTO.getPassword())).thenReturn("encodedPassword");
        when(userRepository.save(any(User.class))).thenReturn(user);
 
        // Mock the behavior of customerClient.addCustomer() to return a ResponseEntity
        when(customerClient.addCustomer(any(CustomerDTO.class)))
                .thenReturn(new ResponseEntity<>(customerDTO, HttpStatus.CREATED));
 
        UserDTO result = userService.registerCustomer(customerDTO);
 
        assertNotNull(result);
        assertEquals(user.getUserId(), result.getUserId());
        assertEquals(user.getEmail(), result.getEmail());
        assertNull(result.getPassword());
        assertEquals(Roles.CUSTOMER, result.getRole());
        verify(userRepository, times(1)).save(any(User.class));
        verify(customerClient, times(1)).addCustomer(any());
    }
 
    @Test
    void registerCustomer_existingCustomer_throwsUserAlreadyExistsException() {
        when(userRepository.findByEmail(customerDTO.getEmail())).thenReturn(Optional.of(user));
 
        assertThrows(UserAlreadyExistsException.class, () -> userService.registerCustomer(customerDTO));
        verify(userRepository, never()).save(any(User.class));
        verify(customerClient, never()).addCustomer(any());
    }
 
//    @Test
//    void registerAgent_newAgent_returnsUserDTOAndCallsAgentClient() {
//        // Arrange
//        String name = "Test Agent";
//        String phone = "1234567890";
//        String email = "test.agent@gmail.com";
//        String password = "password123";
//        String adminId = "admin123";
//
//        AgentDTO registerRequest = new AgentDTO(null, name, phone, email, password, adminId, null, null);
//        User newUser = new User();
//        newUser.setEmail(registerRequest.getEmail());
//        newUser.setPassword("encodedPassword");
//        newUser.setRole(Roles.AGENT);
//        newUser.setUsername(registerRequest.getEmail()); // Assuming username is derived from email for agents
//
//        AgentDTO createdAgentDTO = new AgentDTO("agent-uuid", name, phone, email, null, adminId, null, null); // Password should not be in response
//
//        UserDTO expectedUserDTO = new UserDTO();
//        expectedUserDTO.setEmail(newUser.getEmail());
//        expectedUserDTO.setEmail(newUser.getEmail());
//        expectedUserDTO.setRole(newUser.getRole().name());
//
//        when(userRepository.findByEmail(registerRequest.getEmail())).thenReturn(Optional.empty()); // Using email as username
//        when(userRepository.findByEmail(registerRequest.getEmail())).thenReturn(Optional.empty());
//        when(passwordEncoder.encode(registerRequest.getPassword())).thenReturn("encodedPassword");
//        when(userRepository.save(any(User.class))).thenReturn(newUser);
//
//        // Mock the AgentClient to return a ResponseEntity with the created AgentDTO
//        ResponseEntity<AgentDTO> mockAgentResponse = new ResponseEntity<>(createdAgentDTO, HttpStatus.CREATED);
//        when(agentClient.createAgent(any(AgentDTO.class))).thenReturn(mockAgentResponse);
//
//        // Act
//        UserDTO actualUserDTO = userService.registerAgent(registerRequest); // Assuming you have a registerAgent method in UserService
//
//        // Assert
//        assertNotNull(actualUserDTO);
//        assertEquals(expectedUserDTO.getUsername(), actualUserDTO.getUsername());
//        assertEquals(expectedUserDTO.getEmail(), actualUserDTO.getEmail());
//        assertEquals(expectedUserDTO.getRole(), actualUserDTO.getRole());
//
//        // Verify that agentClient.createAgent() was called
//        verify(agentClient, times(1)).createAgent(registerRequest);
//    }
    @Test
    void registerAgent_existingAgent_throwsUserAlreadyExistsException() {
        when(userRepository.findByEmail(agentDTO.getEmail())).thenReturn(Optional.of(user));
 
        assertThrows(UserAlreadyExistsException.class, () -> userService.registerAgent(agentDTO));
        verify(userRepository, never()).save(any(User.class));
        verify(agentClient, never()).createAgent(any());
    }
 
    @Test
    void registerAgent_invalidAdminId_throwsUserNotFoundException() {
        agentDTO.setAdminId(UUID.randomUUID().toString());
        when(userRepository.findByEmail(agentDTO.getEmail())).thenReturn(Optional.empty());
 
        assertThrows(UserNotFoundException.class, () -> userService.registerAgent(agentDTO));
        verify(userRepository, never()).save(any(User.class));
        verify(agentClient, never()).createAgent(any());
    }
 
    @Test
    void verify_validCredentialsAndRole_returnsLoginData() {
        Authentication authentication = mock(Authentication.class);
        when(authManager.authenticate(any(UsernamePasswordAuthenticationToken.class))).thenReturn(authentication);
        when(authentication.isAuthenticated()).thenReturn(true);
        when(userRepository.findByEmail(user.getEmail())).thenReturn(Optional.of(user));
        when(jwtService.generateToken(user.getEmail(), user.getRole())).thenReturn("mockToken");
 
        Map<String, String> result = userService.verify(user.getEmail(), "password", user.getRole());
 
        assertNotNull(result);
        assertEquals("mockToken", result.get("token"));
        assertEquals(user.getUserId(), result.get("uuid"));
    }
 
    @Test
    void verify_invalidCredentials_throwsUserNotFoundException() {
        when(authManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
                .thenThrow(new org.springframework.security.core.AuthenticationException("Invalid credentials") {});
 
        assertThrows(UserNotFoundException.class, () -> userService.verify(user.getEmail(), "wrongPassword", user.getRole()));
        verify(userRepository, never()).findByEmail(anyString());
        verify(jwtService, never()).generateToken(anyString(), any());
    }
 
//    @Test
//    void verify_userNotFoundByEmail_throwsUserNotFoundException() {
//        Authentication authentication = mock(Authentication.class);
//        when(authManager.authenticate(any(UsernamePasswordAuthenticationToken.class))).thenReturn(authentication);
//        when(authentication.isAuthenticated()).thenReturn(true);
//        when(userRepository.findByEmail(user.getEmail())).thenReturn(Optional.empty());
//
//        assertThrows(UserNotFoundException.class, () -> userService.verify(user.getEmail(), "password", user.getRole()));
//        verify(jwtService, never()).generateToken(anyString(), any());
//    }
 
    @Test
    @MockitoSettings(strictness = Strictness.LENIENT)
    void verify_incorrectRole_throwsAccessDeniedException() {
        Authentication authentication = mock(Authentication.class);
        when(authManager.authenticate(any(UsernamePasswordAuthenticationToken.class))).thenReturn(authentication);
        when(authentication.isAuthenticated()).thenReturn(true);
        user.setRole(Roles.ADMIN);
        when(userRepository.findByEmail(user.getEmail())).thenReturn(Optional.of(user));
 
        assertThrows(org.springframework.security.access.AccessDeniedException.class,
                () -> userService.verify(user.getEmail(), "password", Roles.CUSTOMER));
        user.setRole(Roles.CUSTOMER); // Reset role for other tests
        verify(jwtService, never()).generateToken(anyString(), any());
    }
 
    @Test
    void getAdminById_existingAdminId_returnsUserDTO() {
        user.setRole(Roles.ADMIN);
        when(userRepository.findById(user.getUserId())).thenReturn(Optional.of(user));
 
        UserDTO result = userService.getAdminById(user.getUserId());
 
        assertNotNull(result);
        assertEquals(user.getUserId(), result.getUserId());
        assertEquals(user.getEmail(), result.getEmail());
        assertEquals(Roles.ADMIN, result.getRole());
    }
 
    @Test
    void getAdminById_nonExistingAdminId_throwsUserNotFoundException() {
        when(userRepository.findById(anyString())).thenReturn(Optional.empty());
 
        assertThrows(UserNotFoundException.class, () -> userService.getAdminById(UUID.randomUUID().toString()));
    }
 
    @Test
    void getAdminById_userIsNotAdmin_throwsUserNotFoundException() {
        when(userRepository.findById(user.getUserId())).thenReturn(Optional.of(user));
 
        assertThrows(UserNotFoundException.class, () -> userService.getAdminById(user.getUserId()));
    }
 
    @Test
    void deleteUser_existingId_deletesUser() {
        String userIdToDelete = UUID.randomUUID().toString();
        when(userRepository.existsById(userIdToDelete)).thenReturn(true);
        doNothing().when(userRepository).deleteById(userIdToDelete);
 
        userService.deleteUser(userIdToDelete);
 
        verify(userRepository, times(1)).existsById(userIdToDelete);
        verify(userRepository, times(1)).deleteById(userIdToDelete);
    }
 
    @Test
    void deleteUser_nonExistingId_throwsUserNotFoundException() {
        String userIdToDelete = UUID.randomUUID().toString();
        when(userRepository.existsById(userIdToDelete)).thenReturn(false);
 
        assertThrows(UserNotFoundException.class, () -> userService.deleteUser(userIdToDelete));
        verify(userRepository, times(1)).existsById(userIdToDelete);
        verify(userRepository, never()).deleteById(anyString());
    }
 
    @Test
    void loadUserByUsername_existingUser_returnsUserPrincipal() {
        when(userRepository.findByEmail(user.getEmail())).thenReturn(Optional.of(user));
 
        org.springframework.security.core.userdetails.UserDetails userDetails = userService.loadUserByUsername(user.getEmail());
 
        assertNotNull(userDetails);
        assertEquals(user.getEmail(), userDetails.getUsername());
        assertEquals(user.getPassword(), userDetails.getPassword());
        assertEquals(Collections.singletonList(user.getRole().name()),
                userDetails.getAuthorities().stream().map(Object::toString).toList());
    }
 
//    @Test
//    void loadUserByUsername_nonExistingUser_throwsUsernameNotFoundException() {
//        when(userRepository.findByEmail(anyString())).thenReturn(Optional.empty());
//
//        assertThrows(UsernameNotFoundException.class, () -> userService.loadUserByUsername("nonexistent@example.com"));
//    }
 
    @Test
    void getAllUsers_returnsListOfUserDTOs() {
        User user2 = new User();
        user2.setUserId(UUID.randomUUID().toString());
        user2.setEmail("test2@example.com");
        user2.setRole(Roles.AGENT);
        List<User> users = List.of(user, user2);
        when(userRepository.findAll()).thenReturn(users);
 
        List<UserDTO> userDTOs = userService.getAllUsers();
 
        assertNotNull(userDTOs);
        assertEquals(2, userDTOs.size());
        assertEquals(user.getUserId(), userDTOs.get(0).getUserId());
        assertEquals(user.getEmail(), userDTOs.get(0).getEmail());
        assertEquals(user.getRole(), userDTOs.get(0).getRole());
        assertEquals(user2.getUserId(), userDTOs.get(1).getUserId());
        assertEquals(user2.getEmail(), userDTOs.get(1).getEmail());
        assertEquals(user2.getRole(), userDTOs.get(1).getRole());
    }
}
 