package com.example.auth.client;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.auth.dto.AgentDTO;
import com.example.auth.dto.CustomerDTO;


@FeignClient(name ="agent-service")
public interface AgentClient {
 
    @PostMapping("/api/v1/agents/agent")
    ResponseEntity<AgentDTO> createAgent(@RequestBody AgentDTO agentDTO);
    // Add other agent-related endpoints as needed
}