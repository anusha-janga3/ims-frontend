package com.example.auth.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.example.auth.authFilter.AuthFilter;
import com.example.auth.service.UserService;
 
@Configuration
@EnableWebSecurity
public class SecurityConfig {
 
    @Lazy
    @Autowired
    UserService userDetailsService;
    
    @Autowired
    private AuthFilter authFilter;
 
    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
 
        return http.cors(cors -> cors.configurationSource(corsConfigurationSource()))
        		.csrf(customizer -> customizer.disable())
                .authorizeHttpRequests(request -> request
                        .requestMatchers("/api/v1/users/register-agent",
                        		"/api/v1/users/register-customer",
                        		"/api/v1/users/register-admin",
                        		"/api/v1/users/login",
                        		"/api/v1/users/admin/{adminId}"
                        		).permitAll()
                        .requestMatchers("/api/v1/users/delete/{id}").permitAll()
                        .requestMatchers("/api/v1/users/{id}",
                        		"/api/v1/users/getAllUsers").hasAuthority("ADMIN")                        
                        .anyRequest().authenticated())
                .httpBasic(Customizer.withDefaults())
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .addFilterBefore(authFilter, UsernamePasswordAuthenticationFilter.class)
                .build();
    }
    
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        
        // Explicitly specify the allowed origin
        configuration.setAllowedOrigins(java.util.List.of("http://localhost:3000"));

        // Allow specific headers required by the frontend
        configuration.setAllowedHeaders(java.util.List.of("Authorization", "Content-Type", "Accept"));

        // Allow the required HTTP methods
        configuration.setAllowedMethods(java.util.List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));

        // Enable credentials (for cookies or tokens)
        configuration.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration); // Apply globally to all endpoints
        return source;
    }

 
    @Bean
    AuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setPasswordEncoder(passwordEncoder());
        provider.setUserDetailsService(userDetailsService);
        return provider;
    }
 
    @Bean
    AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }
 
    @Bean
    PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(12);
    }
}