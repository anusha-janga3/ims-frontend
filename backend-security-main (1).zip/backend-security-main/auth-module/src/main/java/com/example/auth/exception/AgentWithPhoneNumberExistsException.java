package com.example.auth.exception;
 
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;
 
@ResponseStatus(HttpStatus.CONFLICT) // HTTP status code 409: Conflict
public class AgentWithPhoneNumberExistsException extends RuntimeException {
    public AgentWithPhoneNumberExistsException(String message) {
        super(message);
    }
}
 