package com.example.auth.client;

import java.net.URI;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;

public class FeignException extends RuntimeException {

    private final int status;
    private final byte[] content;

    protected FeignException(int status, String message, byte[] content) {
        super(message);
        this.status = status;
        this.content = content;
    }

    /**
     * Returns the HTTP status code of the response.
     *
     * @return an integer representing the status code, or {@code -1} if unavailable.
     */
    public int status() {
        return status;
    }

    /**
     * Returns the response body as a byte array. May be {@code null}.
     *
     * @return the response body or an empty {@link Optional}.
     */
    public Optional<byte[]> responseBody() {
        return Optional.ofNullable(content);
    }

    // You might also use getMessage() from the superclass for a general error description.
}