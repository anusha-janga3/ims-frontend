package com.example.auth.dto;
 
import com.example.auth.enums.Roles;
 
import jakarta.validation.constraints.NotBlank;

import jakarta.validation.constraints.NotNull;

import jakarta.validation.constraints.Pattern;

import lombok.Data;
 
@Data

public class UserDTO {	

	private String userId;

	@NotBlank(message="please provide email")

	@NotNull(message="Email should not be null")

	private String email;
 
	@NotBlank(message="please provide password")

	@NotNull(message="password should not be null")

	@Pattern(

            regexp = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]+$",

            message = "Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character"

        )

	private String password;

	@NotBlank(message = "Phone number is mandatory")

    @Pattern(regexp = "^\\d{10}$", message = "Phone number should be 10 digits")

	private Long mobileNo;

 
	@NotNull(message = "Role cannot be null")

    @NotBlank(message = "Role cannot be blank")

	private Roles role;

}

 