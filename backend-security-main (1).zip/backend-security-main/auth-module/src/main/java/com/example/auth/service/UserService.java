package com.example.auth.service;
 
import com.example.auth.client.AgentClient;
import com.example.auth.client.CustomerClient;
import com.example.auth.dto.AgentDTO;
import com.example.auth.dto.CustomerDTO;
import com.example.auth.dto.UserDTO;
import com.example.auth.enums.Roles;
import com.example.auth.model.User;
import com.example.auth.model.UserPrincipal;
import com.example.auth.repository.UserRepository;
 
import jakarta.transaction.Transactional;
 

import com.example.auth.exception.UserAlreadyExistsException;
import com.example.auth.exception.UserNotFoundException;

 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

 
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

 
//import org.springframework.cloud.openfeign.FeignException;
 
@Service
public class UserService implements UserDetailsService{
 
    @Autowired
    private UserRepository userRepository;
 
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
	private JWTService jwtService;
    
    @Lazy
	@Autowired
	private AuthenticationManager authManager;
    
    @Autowired
    private CustomerClient customerClient;
    
    @Autowired
    private AgentClient agentClient;
    
    public UserDTO getUserById(String userId) {
        Optional<User> userOptional = userRepository.findById(userId);
        if (userOptional.isEmpty()) {
            throw new UserNotFoundException("User not found with the provided ID!");
        }
        return convertToDTO(userOptional.get());
    }
    
    
    public UserDTO registerAdmin(UserDTO adminDTO) {
        if (userRepository.findByEmail(adminDTO.getEmail()).isPresent()) {
            throw new UserAlreadyExistsException("User with this email already exists!");
        }
 
        User user = new User();
        user.setUserId("12c99bb1-ebdd-4180-9957-dc5a0497b405"); // Hardcoded admin user ID
        user.setEmail(adminDTO.getEmail());
        user.setPassword(passwordEncoder.encode(adminDTO.getPassword()));
        user.setRole(Roles.ADMIN);
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());
        user.setMobileNo(adminDTO.getMobileNo());
 
        User savedUser = userRepository.save(user);
        return convertToDTO(savedUser);
    }
 
    
 
    public UserDTO registerCustomer(CustomerDTO customerDTO) {
        Long mobileNo;
        try {
            mobileNo = Long.parseLong(customerDTO.getPhone());
        } catch (NumberFormatException e) {
            throw new UserAlreadyExistsException("Invalid mobile number format!");
        }
 
        if (userRepository.findByEmail(customerDTO.getEmail()).isPresent() || userRepository.findByMobileNo(mobileNo).isPresent()) {
            throw new UserAlreadyExistsException("User with this email or mobile number already exists!");
        }
 
        User user = new User();
        user.setEmail(customerDTO.getEmail());
        user.setPassword(passwordEncoder.encode(customerDTO.getPassword()));
        user.setRole(Roles.CUSTOMER);
        user.setMobileNo(mobileNo); // Use the parsed Long
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());
 
        User savedUser = userRepository.save(user);
        UserDTO result = convertToDTO(savedUser);
 
        try {
            CustomerDTO customerDetailsToSend = new CustomerDTO();
            customerDetailsToSend.setCustomerId(savedUser.getUserId());
            customerDetailsToSend.setName(customerDTO.getName());
            customerDetailsToSend.setEmail(customerDTO.getEmail());
            customerDetailsToSend.setPhone(customerDTO.getPhone()); // Still send the String to the customer service
            customerDetailsToSend.setAddress(customerDTO.getAddress());
            customerDetailsToSend.setCreatedAt(LocalDateTime.now());
            customerDetailsToSend.setUpdatedAt(LocalDateTime.now());
 
            customerClient.addCustomer(customerDetailsToSend);
            System.out.println("Customer details sent to customer service successfully.");
        } catch (Exception e) {
            System.err.println("Error sending customer details to customer service: " + e.getMessage());
        }
 
        return result;
    }
    
    
    public UserDTO registerAgent(AgentDTO agentDTO) {
        if (userRepository.findByEmail(agentDTO.getEmail()).isPresent() || userRepository.findByMobileNo(Long.parseLong(agentDTO.getContactInfo())).isPresent()) {
            throw new UserAlreadyExistsException("User with this email or mobile number already exists!");
        }
 
        if (!agentDTO.getAdminId().equals("12c99bb1-ebdd-4180-9957-dc5a0497b405")) {
        	throw new UserNotFoundException("AdminId is Invalid");
        }
 
        User user = new User();
        user.setEmail(agentDTO.getEmail());
        user.setPassword(passwordEncoder.encode(agentDTO.getPassword()));
        user.setRole(Roles.AGENT);
        user.setMobileNo(Long.parseLong(agentDTO.getContactInfo()));
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());
 
        User savedUser = userRepository.save(user);
        UserDTO result = convertToDTO(savedUser);
 
        try {
            AgentDTO customerDetailsToSend = new AgentDTO();
            customerDetailsToSend.setAgentId(savedUser.getUserId());
            customerDetailsToSend.setName(agentDTO.getName());
            customerDetailsToSend.setEmail(agentDTO.getEmail());
            customerDetailsToSend.setContactInfo(agentDTO.getContactInfo());
            customerDetailsToSend.setAdminId("12c99bb1-ebdd-4180-9957-dc5a0497b405");
            customerDetailsToSend.setCreatedAt(LocalDateTime.now());
            customerDetailsToSend.setUpdatedAt(LocalDateTime.now());
 
            agentClient.createAgent(customerDetailsToSend);
            System.out.println("Agent details sent to agent service successfully.");
        } catch (Exception e) {
        	e.printStackTrace();
            System.err.println("Error sending agent details to agent service: " + e.getMessage());
        }
 
        return result;
    }
    
    public Map<String, String> verify(String email, String password, Roles role) {
        Authentication authentication = null;
        try {
            authentication = authManager.authenticate(new UsernamePasswordAuthenticationToken(email, password));
        } catch (org.springframework.security.core.AuthenticationException e) {
            throw new UserNotFoundException("Invalid Email or Password.");
        }
 
        User authUser = userRepository.findByEmail(email)
                .orElseThrow(() -> new UserNotFoundException("User not found"));
 
        if (authUser.getRole() != role) {
            throw new org.springframework.security.access.AccessDeniedException("Forbidden! You don't have access!");
        }
        
        if (authentication.isAuthenticated()) {
	        String token = jwtService.generateToken(email, role);
	        String uuid = authUser.getUserId();
 
	        Map<String, String> loginData = new HashMap<>();
	        loginData.put("token", token);
	        loginData.put("uuid", uuid);
 
	        return loginData;
	    } else {
	        throw new UserNotFoundException("Invalid credentials");
	    }
    }
    
    public UserDTO getAdminById(String adminId) {
        Optional<User> userOptional = userRepository.findById(adminId.toString());
        if (userOptional.isEmpty()) {
            throw new UserNotFoundException("User not found with the provided ID!");
        }
        User user = userOptional.get();
        if (user.getRole() != Roles.ADMIN) {
            throw new UserNotFoundException("The user is not an admin!");
        }
        return convertToDTO(user);
    }
 
    
    @Transactional
    public void deleteUser(String userId) {
        if (!userRepository.existsById(userId)) {
            throw new UserNotFoundException("User not found with id: " + userId);
        }
        userRepository.deleteById(userId);
    }
    
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<User> user = userRepository.findByEmail(username);
		if(user.isEmpty()) {
			throw new UsernameNotFoundException("User Not Found....");
		}
		return new UserPrincipal(user.get());
	}
	
    public List<UserDTO> getAllUsers() {
    	return userRepository.findAll().stream().map(this::convertToDTO).toList();
    }
    
    private UserDTO convertToDTO(User user) {
    	UserDTO userDTO = new UserDTO();
    	userDTO.setUserId(user.getUserId());
    	userDTO.setEmail(user.getEmail());
    	userDTO.setRole(user.getRole());
    	userDTO.setMobileNo(user.getMobileNo());
    	return userDTO;
    }
}
 