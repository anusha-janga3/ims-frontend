package com.example.auth.controller;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.auth.dto.UserDTO;
import com.example.auth.enums.Roles;
import com.example.auth.dto.AgentDTO;
import com.example.auth.dto.CustomerDTO;
import com.example.auth.dto.LoginRequest;
import com.example.auth.exception.UserAlreadyExistsException;
import com.example.auth.exception.UserNotFoundException;
import com.example.auth.response.ResultResponse;
import com.example.auth.service.UserService;

import jakarta.validation.Valid;

/**
 * Controller class to handle HTTP requests related to users.
 */
@RestController
@Slf4j
@RequestMapping("/api/v1/users")
public class UserController {

    @Autowired
    private UserService userService;
    
    /**
     * Handles GET requests to fetch a user by ID.
     *
     * @param userId The ID of the user to be retrieved.
     * @return A ResponseEntity containing a ResultResponse with the UserDTO.
     */
    @GetMapping("/{id}")
    public ResponseEntity<ResultResponse<UserDTO>> getUserById(@PathVariable("id") String userId) {
        log.info("Received request to fetch user by ID: {}", userId);

        try {
            // Fetch the user using the service layer
            UserDTO userDTO = userService.getUserById(userId);

            // Build the ResultResponse object
            ResultResponse<UserDTO> response = ResultResponse.<UserDTO>builder()
                    .data(userDTO)
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build();

            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (UserNotFoundException e) {
            log.error("Failed to fetch user: {}", e.getMessage());

            // Build the ResultResponse object for error
            ResultResponse<UserDTO> response = ResultResponse.<UserDTO>builder()
                    .message(e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build();

            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
    }
    
    
    @PostMapping("/register-admin")
    public ResponseEntity<ResultResponse<UserDTO>> registerAdmin(  @RequestBody UserDTO adminDTO) {
        log.info("Received request to register admin: {}", adminDTO);

        try {
            UserDTO savedAdmin = userService.registerAdmin(adminDTO);
            ResultResponse<UserDTO> response = ResultResponse.<UserDTO>builder()
                    .data(savedAdmin)
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (UserAlreadyExistsException e) {
            log.error("Admin registration failed: {}", e.getMessage());
            ResultResponse<UserDTO> response = ResultResponse.<UserDTO>builder()
                    .message(e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.CONFLICT);
        }
    }
    

    /**
     * Handles POST requests for user registration.
     *
     * @param userDTO The UserDTO object containing user details.
     * @return A ResponseEntity containing a ResultResponse with the saved UserDTO.
     */
    @PostMapping("/register-customer")
    public ResponseEntity<ResultResponse<UserDTO>> registerCustomer( @Valid @RequestBody CustomerDTO userDTO) {
        log.info("Received request to register user: {}", userDTO);

        try {
            // Register the user using the service layer
            UserDTO savedUser = userService.registerCustomer(userDTO);
            ResultResponse<UserDTO> response = ResultResponse.<UserDTO>builder()
                    .data(savedUser)
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (UserAlreadyExistsException e) {
            log.error("User registration failed: {}", e.getMessage());
            ResultResponse<UserDTO> response = ResultResponse.<UserDTO>builder()
                    .message(e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.CONFLICT);
        }
    }

    
    @PostMapping("/register-agent")
    public ResponseEntity<ResultResponse<UserDTO>> registerAgent( @Valid @RequestBody AgentDTO userDTO) {
        log.info("Received request to register user: {}", userDTO);

        try {
            // Register the user using the service layer
            UserDTO savedUser = userService.registerAgent(userDTO);
            ResultResponse<UserDTO> response = ResultResponse.<UserDTO>builder()
                    .data(savedUser)
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (UserAlreadyExistsException e) {
            log.error("User registration failed: {}", e.getMessage());
            ResultResponse<UserDTO> response = ResultResponse.<UserDTO>builder()
                    .message(e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.CONFLICT);
        }catch (UserNotFoundException e) {
            log.error("User registration failed: {}", e.getMessage());
            ResultResponse<UserDTO> response = ResultResponse.<UserDTO>builder()
                    .message(e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.CONFLICT);
        }
        
    }

    /**
     * Handles POST requests for user login.
     *
     * @param loginRequest The login request containing email and password.
     * @return A ResponseEntity containing a ResultResponse indicating login success or failure.
     */
    @PostMapping("/login")
    public ResponseEntity<ResultResponse<Map<String, String>>> loginUser(@RequestBody LoginRequest loginRequest) {
        log.info("Received request to login user with email: {}", loginRequest.getEmail());

        try {
            Map<String, String> loginData = userService.verify(
                    loginRequest.getEmail(),
                    loginRequest.getPassword(),
                    loginRequest.getRole()
            );

            ResultResponse<Map<String, String>> response = ResultResponse.<Map<String, String>>builder()
                    .message("Login Successful")
                    .data(loginData)
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (UserNotFoundException e) {
            log.error("Login failed: {}", e.getMessage());
            ResultResponse<Map<String, String>> response = ResultResponse.<Map<String, String>>builder()
                    .message(e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
        } catch (org.springframework.security.access.AccessDeniedException e) {
            log.error("Access Denied: {}", e.getMessage());
            ResultResponse<Map<String, String>> response = ResultResponse.<Map<String, String>>builder()
                    .message(e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.FORBIDDEN);
        }
    }
    
    @PostMapping("/customer")
    public ResponseEntity<ResultResponse<CustomerDTO>> createCustomer(@RequestBody CustomerDTO customerDTO) {
        // Log the received customerDTO (optional)
        log.info("Received customer data: {}", customerDTO);

        // Build the ResultResponse object
        ResultResponse<CustomerDTO> response = ResultResponse.<CustomerDTO>builder()
                .data(customerDTO)  // Return the received CustomerDTO as data
                .success(true)      // Indicate the operation was successful
                .timestamp(LocalDateTime.now())  // Add timestamp for the response
                .build();

        // Return the response wrapped in ResponseEntity with HTTP status 201 (Created)
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping("/admin/{adminId}")
    public ResponseEntity<ResultResponse<UserDTO>> getAdminById(@PathVariable String adminId) {
        log.info("Received request to fetch admin by ID: {}", adminId);
 
        try {
            // Fetch the user using the service layer
            UserDTO userDTO = userService.getUserById(adminId);
 
            // Validate if the user has the ADMIN role
            if (userDTO.getRole() != Roles.ADMIN) {
                log.error("User with ID {} is not an admin.", adminId);
 
                ResultResponse<UserDTO> response = ResultResponse.<UserDTO>builder()
                        .message("The user is not an admin.")
                        .success(false)
                        .timestamp(LocalDateTime.now())
                        .build();
 
                return new ResponseEntity<>(response, HttpStatus.FORBIDDEN);
            }
 
            // Build the ResultResponse object
            ResultResponse<UserDTO> response = ResultResponse.<UserDTO>builder()
                    .data(userDTO)
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build();
 
            return new ResponseEntity<>(response, HttpStatus.OK);
 
        } catch (UserNotFoundException e) {
            log.error("Failed to fetch admin: {}", e.getMessage());
 
            // Build the ResultResponse object for error
            ResultResponse<UserDTO> response = ResultResponse.<UserDTO>builder()
                    .message(e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build();
 
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
           
    }
    
    @GetMapping("/getAllUsers")
    public ResponseEntity<ResultResponse<List<UserDTO>>> getAllUsers() {
        List<UserDTO> users = userService.getAllUsers();
        ResultResponse<List<UserDTO>> response = ResultResponse.<List<UserDTO>>builder()
                .success(true)
                .message("Fetched all users")
                .data(users)
                .timestamp(LocalDateTime.now())
                .build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteInternalUser(@PathVariable String id) {
        try {
            userService.deleteUser(id); // Reuse your existing deleteUser logic
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (UserNotFoundException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
 
 
}
