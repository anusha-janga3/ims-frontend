package com.example.auth.response;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class ResultResponse<T> {
    private boolean success;         // Indicates if the operation was successful
    private String message;          // Error or success message
    private T data;                  // Optional data for the response (e.g., UserDTO, String, etc.)
    private LocalDateTime timestamp; // Timestamp of the response
}