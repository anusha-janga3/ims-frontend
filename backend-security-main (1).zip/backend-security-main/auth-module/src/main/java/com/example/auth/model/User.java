package com.example.auth.model;
 
import jakarta.persistence.*;

import lombok.AllArgsConstructor;

import lombok.Data;

import lombok.NoArgsConstructor;
 
import java.time.LocalDateTime;

import java.util.UUID;
 
import com.example.auth.enums.Roles;
 
@Entity

@Table(name = "users") // Specify the table name

@Data

@NoArgsConstructor

@AllArgsConstructor

public class User {

    @Id

    @Column(name = "userId") // Specify the column name

    private String userId;
 
    @Column(name = "email", nullable = false, unique = true) // Column for email

    private String email;
 
    @Column(name = "password", nullable = false) // Column for encrypted password

    private String password;

    @Column(name = "mobileNumber", nullable = false, unique = true) 

    private Long mobileNo;

    @Column(name = "roles")

    @Enumerated(EnumType.STRING)

    private Roles role;
 
    @Column(name = "createdAt", nullable = false) // Column for creation timestamp

    private LocalDateTime createdAt;
 
    @Column(name = "updatedAt", nullable = false) // Column for update timestamp

    private LocalDateTime updatedAt;
 
    @PrePersist

    public void onCreate() {

        this.userId = UUID.randomUUID().toString(); // Generate unique String ID for userId

        this.createdAt = LocalDateTime.now();

        this.updatedAt = LocalDateTime.now();

    }
 
    @PreUpdate

    public void onUpdate() {

        this.updatedAt = LocalDateTime.now();

    }

}

 