package com.example.auth.dto;

import java.time.LocalDateTime;


import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
 
import lombok.Data;
 
/**
* Data Transfer Object for Customer.
*/
@Data
@Validated
@JsonIgnoreProperties(ignoreUnknown=true)
public class CustomerDTO {
 
    /**
     * Unique identifier for the customer.
     */
    private String customerId;
 
    /**
     * Address of the customer.
     */
    @NotBlank(message = "Address is mandatory")
    @Size(max = 255, message = "Address cannot exceed 255 characters")
    private String address;
 
    /**
     * Name of the customer.
     */
    @NotBlank(message = "Name is mandatory")
    @Size(max = 100, message = "Name cannot exceed 100 characters")
    private String name;
 
    /**
     * Email of the customer.
     */
    @NotBlank(message = "Email is mandatory")
    @Email(message = "Email should be valid")
    @Pattern(
		    regexp = "^[a-zA-Z0-9._%+-]+@gmail\\.com$",
		    message = "Email must be a valid Gmail address"
		)
    private String email;
 
    /**
     * Phone number of the customer.
     */
    @NotBlank(message = "Phone number is mandatory")
    @Pattern(regexp = "^\\d{10}$", message = "Phone number should be 10 digits")
    private String phone;
 
    /**
     * Password of the customer.
     */
    @NotBlank(message = "Password is mandatory")
    @Size(min = 8, message = "Password should be at least 8 characters long")
    private String password;
 
    /**
     * Timestamp when the customer was created.
     */
    private LocalDateTime createdAt;
 
    /**
     * Timestamp when the customer was last updated.
     */
    private LocalDateTime updatedAt;
    
  
}