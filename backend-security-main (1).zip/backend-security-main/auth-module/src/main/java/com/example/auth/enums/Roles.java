package com.example.auth.enums;

public enum Roles {
		ADMIN,
		AGENT,
		CUSTOMER
}
