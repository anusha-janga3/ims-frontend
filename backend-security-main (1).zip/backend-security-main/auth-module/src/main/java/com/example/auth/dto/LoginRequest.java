package com.example.auth.dto;

import com.example.auth.enums.Roles;

import lombok.Data;

@Data
public class LoginRequest {
	private String Email;
	private String password;
	private Roles role;
}
