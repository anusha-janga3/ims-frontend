package com.ports.gateway.route;

import org.springframework.context.annotation.Bean;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
//import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.cors.reactive.CorsUtils;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;

import reactor.core.publisher.Mono;
@Configuration
public class Route {
	@Bean
    RouteLocator routeLocator(RouteLocatorBuilder builder) {
        return builder.routes()
                .route("auth-service", r -> r.path("/api/v1/users/**")
                        .uri("http://localhost:8086"))
                .route("agent-service", r -> r.path("/api/v1/agents/**")
                        .uri("http://localhost:8084"))
                .route("agent-service", r -> r.path("/api/v1/assigned-policy/**")
                        .uri("http://localhost:8084"))
                .route("claim-service", r -> r.path("/api/v1/claim/**")
                        .uri("http://localhost:8083"))
                .route("customer-service", r -> r.path("/api/v1/customers/**")
                        .uri("http://localhost:8088"))
                .route("notification-service", r -> r.path("/api/v1/notification/**")
                        .uri("http://localhost:8085"))
                .route("policy-service", r -> r.path("/api/v1/policies/**")
                        .uri("http://localhost:8082"))
               
                .build();
    }
	
	
	@Bean
	public WebFilter corsFilter() {
	    return (ServerWebExchange exchange, WebFilterChain chain) -> {
	        ServerHttpRequest request = exchange.getRequest();
	        if (CorsUtils.isCorsRequest(request)) {
	            HttpHeaders headers = new HttpHeaders();
	            headers.add("Access-Control-Allow-Origin", "http://localhost:3000");
	            headers.add("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
	            headers.add("Access-Control-Allow-Headers", "Authorization, Content-Type");
	            headers.add("Access-Control-Allow-Credentials", "true");
	            exchange.getResponse().getHeaders().addAll(headers);
	            if (request.getMethod() == HttpMethod.OPTIONS) {
	                exchange.getResponse().setStatusCode(HttpStatus.OK);
	                return Mono.empty();
	            }
	        }
	        return chain.filter(exchange);
	    };
	}
}