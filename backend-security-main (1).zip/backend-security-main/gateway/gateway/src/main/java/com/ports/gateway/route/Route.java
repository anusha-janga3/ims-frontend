package com.ports.gateway.route;

import org.springframework.context.annotation.Bean;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
//import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
@Configuration
public class Route {
	@Bean
    RouteLocator routeLocator(RouteLocatorBuilder builder) {
        return builder.routes()
                .route("registraton-module", r -> r.path("/api/users/**")
                        .uri("http://localhost:8086"))
                .route("registraton-module", r -> r.path("/api/doctor/**")
                        .uri("http://localhost:8086"))
                .route("registraton-module", r -> r.path("/api/patient/**")
                        .uri("http://localhost:8086"))
                .route("availability-module", r -> r.path("availability/**")
                        .uri("http://localhost:8000"))
                .route("appointment-module", r -> r.path("/appointments/**")
                        .uri("http://localhost:8065"))
                .route("notification-module", r -> r.path("/notifications/**")
                        .uri("http://localhost:8089"))
                .route("consultation-module", r -> r.path("/consultation/**")
                        .uri("http://localhost:8050"))
                .route("consultation-module", r -> r.path("/history/**")
                        .uri("http://localhost:8050"))
               
                .build();
    }
 
}