////package com.example.policy;
////
////import com.example.policy.client.AdminClient;
////import com.example.policy.client.AgentClient;
////import com.example.policy.client.CustomerClient;
////import com.example.policy.controller.PolicyController;
////import com.example.policy.dto.AdminDTO;
////import com.example.policy.dto.AgentDTO;
////import com.example.policy.dto.CustomerDTO;
////import com.example.policy.dto.CustomerPolicyDTO;
////import com.example.policy.dto.PolicyDTO;
////import com.example.policy.exception.InvalidPolicyNameException;
////import com.example.policy.exception.InvalidPremiumAmountException;
////import com.example.policy.exception.InvalidValidityPeriodException;
////import com.example.policy.exception.PolicyNotFoundException;
////import com.example.policy.model.CustomerPolicy;
////import com.example.policy.model.Policy;
////import com.example.policy.model.ResultResponse;
////import com.example.policy.repository.CustomerPolicyRepository;
////import com.example.policy.repository.PolicyRepository;
////import com.example.policy.service.PolicyService;
////
////import org.junit.jupiter.api.BeforeEach;
////import org.junit.jupiter.api.Test;
////import org.junit.jupiter.api.extension.ExtendWith;
////import org.mockito.InjectMocks;
////import org.mockito.Mock;
////import org.mockito.junit.jupiter.MockitoExtension;
////import org.springframework.http.HttpStatus;
////import org.springframework.http.ResponseEntity;
////
////import java.math.BigDecimal;
////import java.time.LocalDateTime;
////import java.util.Arrays;
////import java.util.List;
////import java.util.Optional;
////import java.util.UUID;
////import java.util.stream.Collectors;
////
////import static org.junit.jupiter.api.Assertions.*;
////import static org.mockito.ArgumentMatchers.any;
////import static org.mockito.Mockito.*;
////
////@ExtendWith(MockitoExtension.class)
////class PolicyModuleApplicationTests {
////
////    @Mock
////    private PolicyRepository policyRepository;
////
////    @Mock
////    private CustomerPolicyRepository customerPolicyRepository;
////
////    @InjectMocks
////    private PolicyService policyService;
////    
////    @InjectMocks
////    private PolicyController policyController;
////    
////    @Mock
////    private AdminClient adminFeignClient;
////
////    @Mock
////    private CustomerClient customerFeignClient;
////
////    @Mock
////    private AgentClient agentFeignClient;
////
////    private Policy policy;
////    private PolicyDTO policyDTO;
////    private CustomerPolicy customerPolicy;
////    private CustomerPolicyDTO customerPolicyDTO;
////    private AdminDTO adminDTO;
////    private AgentDTO agentDTO;
////    private CustomerDTO customerDTO;
////
////    @BeforeEach
////    void setUp() {
////        policy = new Policy();
////        policy.setPolicyId("3bda663d-4fbd-43a0-9d35-99cd2519bc5e");
////        policy.setName("Test Policy");
////        policy.setPremiumAmount(BigDecimal.valueOf(100));
////        policy.setValidityPeriod(12);
////        policy.setCoverageDetails("Test Coverage");
////        policy.setAdminId(UUID.randomUUID().toString());
////
////        policyDTO = new PolicyDTO();
////        policyDTO.setPolicyId(policy.getPolicyId());
////        policyDTO.setName(policy.getName());
////        policyDTO.setPremiumAmount(policy.getPremiumAmount());
////        policyDTO.setValidityPeriod(policy.getValidityPeriod());
////        policyDTO.setCoverageDetails(policy.getCoverageDetails());
////        policyDTO.setAdminId(UUID.fromString(policy.getAdminId()));
////
////        customerPolicy = new CustomerPolicy();
////        customerPolicy.setCustomerPolicyId(UUID.randomUUID().toString());
////        customerPolicy.setCustomerId(UUID.randomUUID().toString());
////        customerPolicy.setPolicy(policy);
////        customerPolicy.setAgentId(UUID.randomUUID().toString());
////        customerPolicy.setPurchaseDate(LocalDateTime.now());
////
////        customerPolicyDTO = new CustomerPolicyDTO();
////        customerPolicyDTO.setCustomerPolicyId(customerPolicy.getCustomerPolicyId().toString());
////        customerPolicyDTO.setCustomerId(UUID.fromString(customerPolicy.getCustomerId()));
////        customerPolicyDTO.setPolicyId(UUID.fromString(policy.getPolicyId()));
////        customerPolicyDTO.setAgentId(UUID.fromString(customerPolicy.getAgentId()));
////        customerPolicyDTO.setPurchaseDate(customerPolicy.getPurchaseDate());
////
////        adminDTO = new AdminDTO();
////        adminDTO.setAdminId(policy.getAdminId().toString());
////
////        agentDTO = new AgentDTO();
////        agentDTO.setAgentId(customerPolicy.getAgentId().toString());
////
////        customerDTO = new CustomerDTO();
////        customerDTO.setCustomerId(customerPolicy.getCustomerId().toString());
////    }
////
////    @Test
////    void findAll_shouldReturnListOfPolicyDTOs() {
////        when(policyRepository.findAll()).thenReturn(Arrays.asList(policy));
////        List<PolicyDTO> result = policyService.findAll();
////        assertEquals(1, result.size());
////        assertEquals(policyDTO, result.get(0));
////    }
////
////    @Test
////    void save_shouldReturnSavedPolicyDTO() {
////        when(policyRepository.save(any(Policy.class))).thenReturn(policy);
////        PolicyDTO result = policyService.save(policy);
////        assertEquals(policyDTO, result);
////    }
////
////    @Test
////    void deleteById_shouldDeletePolicyAndReturnSuccessMessage() {
////        when(policyRepository.existsById(policy.getPolicyId())).thenReturn(true);
////        String result = assertDoesNotThrow(() -> policyService.deleteById(policy.getPolicyId()));
////        assertEquals("Deleted Successfully", result);
////        verify(policyRepository, times(1)).deleteById(policy.getPolicyId());
////    }
////
////    @Test
////    void deleteById_shouldThrowPolicyNotFoundException_whenPolicyDoesNotExist() {
////        when(policyRepository.existsById("nonexistentId")).thenReturn(false);
////        assertThrows(PolicyNotFoundException.class, () -> policyService.deleteById("nonexistentId"));
////    }
////
////    @Test
////    void findById_shouldReturnPolicyDTO() {
////        when(policyRepository.findById(policy.getPolicyId())).thenReturn(Optional.of(policy));
////        PolicyDTO result = assertDoesNotThrow(() -> policyService.findById(policy.getPolicyId()));
////        assertEquals(policyDTO, result);
////    }
////
////    @Test
////    void findById_shouldThrowPolicyNotFoundException_whenPolicyNotFound() {
////        when(policyRepository.findById("nonexistentId")).thenReturn(Optional.empty());
////        assertThrows(PolicyNotFoundException.class, () -> policyService.findById("nonexistentId"));
////    }
////
////    @Test
////    void updatePolicy_shouldThrowPolicyNotFoundException_whenPolicyNotFound() {
////        Policy updatedPolicy = new Policy();
////        when(policyRepository.findById("nonexistentId")).thenReturn(Optional.empty());
////        assertThrows(PolicyNotFoundException.class, () -> policyService.updatePolicy("nonexistentId", updatedPolicy));
////    }
////
////    
////    @Test
////    void getCustomerPolicyById_shouldReturnCustomerPolicyDTO() {
////        when(customerPolicyRepository.findById(customerPolicy.getCustomerPolicyId())).thenReturn(Optional.of(customerPolicy));
////        CustomerPolicyDTO result = policyService.getCustomerPolicyById(customerPolicy.getCustomerPolicyId());
////        assertEquals(customerPolicyDTO, result);
////    }
////
////    @Test
////    void getCustomerPolicyById_shouldThrowPolicyNotFoundException_whenCustomerPolicyNotFound() {
////        when(customerPolicyRepository.findById("nonexistentId")).thenReturn(Optional.empty());
////        assertThrows(PolicyNotFoundException.class, () -> policyService.getCustomerPolicyById("nonexistentId"));
////    }
////
////    @Test
////    void findPoliciesByName_shouldReturnListOfPolicyDTOs() {
////        when(policyRepository.findByName(policy.getName())).thenReturn(Arrays.asList(policy));
////        List<PolicyDTO> result = assertDoesNotThrow(() -> policyService.findPoliciesByName(policy.getName()));
////        assertEquals(1, result.size());
////        assertEquals(policyDTO, result.get(0));
////    }
////
////    @Test
////    void findPoliciesByName_shouldThrowInvalidPolicyNameException_whenNameIsEmpty() {
////        assertThrows(InvalidPolicyNameException.class, () -> policyService.findPoliciesByName(""));
////    }
////
////    @Test
////    void findPoliciesByName_shouldThrowInvalidPolicyNameException_whenNameIsNull() {
////        assertThrows(InvalidPolicyNameException.class, () -> policyService.findPoliciesByName(null));
////    }
////
////    @Test
////    void findPoliciesByName_shouldThrowInvalidPolicyNameException_whenNoPoliciesFound() {
////        when(policyRepository.findByName("nonexistentName")).thenReturn(null);
////        assertThrows(InvalidPolicyNameException.class, () -> policyService.findPoliciesByName("nonexistentName"));
////    }
////
////    @Test
////    void findPoliciesByPremiumAmountGreaterThan_shouldReturnListOfPolicyDTOs() {
////        when(policyRepository.findByPremiumAmountGreaterThan(BigDecimal.valueOf(50))).thenReturn(Arrays.asList(policy));
////        List<PolicyDTO> result = assertDoesNotThrow(() -> policyService.findPoliciesByPremiumAmountGreaterThan(BigDecimal.valueOf(50)));
////        assertEquals(1, result.size());
////        assertEquals(policyDTO, result.get(0));
////    }
////
////    @Test
////    void findPoliciesByPremiumAmountGreaterThan_shouldThrowInvalidPremiumAmountException_whenAmountIsNegative() {
////        assertThrows(InvalidPremiumAmountException.class, () -> policyService.findPoliciesByPremiumAmountGreaterThan(BigDecimal.valueOf(-10)));
////    }
////
////    @Test
////    void findPoliciesByPremiumAmountGreaterThan_shouldThrowInvalidPremiumAmountException_whenNoPoliciesFound() {
////        when(policyRepository.findByPremiumAmountGreaterThan(BigDecimal.valueOf(200))).thenReturn(null);
////        assertThrows(InvalidPremiumAmountException.class, () -> policyService.findPoliciesByPremiumAmountGreaterThan(BigDecimal.valueOf(200)));
////    }
////
////    @Test
////    void findPoliciesByPremiumAmountLessThan_shouldReturnListOfPolicyDTOs() {
////        when(policyRepository.findByPremiumAmountLessThan(BigDecimal.valueOf(150))).thenReturn(Arrays.asList(policy));
////        List<PolicyDTO> result = assertDoesNotThrow(() -> policyService.findPoliciesByPremiumAmountLessThan(BigDecimal.valueOf(150)));
////        assertEquals(1, result.size());
////        assertEquals(policyDTO, result.get(0));
////    }
////
////    @Test
////    void findPoliciesByPremiumAmountLessThan_shouldThrowInvalidPremiumAmountException_whenAmountIsNegative() {
////        assertThrows(InvalidPremiumAmountException.class, () -> policyService.findPoliciesByPremiumAmountLessThan(BigDecimal.valueOf(-10)));
////    }
////
////    @Test
////    void findPoliciesByPremiumAmountLessThan_shouldThrowInvalidPremiumAmountException_whenNoPoliciesFound() {
////        when(policyRepository.findByPremiumAmountLessThan(BigDecimal.valueOf(10))).thenReturn(null);
////        assertThrows(InvalidPremiumAmountException.class, () -> policyService.findPoliciesByPremiumAmountLessThan(BigDecimal.valueOf(10)));
////    }
////
////    @Test
////    void findPoliciesByValidityPeriodGreaterThan_shouldReturnListOfPolicyDTOs() {
////        when(policyRepository.findByValidityPeriodGreaterThan(10)).thenReturn(Arrays.asList(policy));
////        List<PolicyDTO> result = assertDoesNotThrow(() -> policyService.findPoliciesByValidityPeriodGreaterThan(10));
////        assertEquals(1, result.size());
////        assertEquals(policyDTO, result.get(0));
////    }
////
////    @Test
////    void findPoliciesByValidityPeriodGreaterThan_shouldThrowInvalidValidityPeriodException_whenPeriodIsNegative() {
////        assertThrows(InvalidValidityPeriodException.class, () -> policyService.findPoliciesByValidityPeriodGreaterThan(-10));
////    }
////
////    @Test
////    void findPoliciesByValidityPeriodGreaterThan_shouldThrowInvalidValidityPeriodException_whenNoPoliciesFound() {
////        when(policyRepository.findByValidityPeriodGreaterThan(20)).thenReturn(null);
////        assertThrows(InvalidValidityPeriodException.class, () -> policyService.findPoliciesByValidityPeriodGreaterThan(20));
////    }
////
////    @Test
////    void findPoliciesByValidityPeriodLessThan_shouldReturnListOfPolicyDTOs() {
////        when(policyRepository.findByValidityPeriodLessThan(15)).thenReturn(Arrays.asList(policy));
////        List<PolicyDTO> result = assertDoesNotThrow(() -> policyService.findPoliciesByValidityPeriodLessThan(15));
////        assertEquals(1, result.size());
////        assertEquals(policyDTO, result.get(0));
////    }
////
////    @Test
////    void findPoliciesByValidityPeriodLessThan_shouldThrowInvalidValidityPeriodException_whenPeriodIsNegative() {
////        assertThrows(InvalidValidityPeriodException.class, () -> policyService.findPoliciesByValidityPeriodLessThan(-10));
////    }
////
////    @Test
////    void findPoliciesByValidityPeriodLessThan_shouldThrowInvalidValidityPeriodException_whenNoPoliciesFound() {
////        when(policyRepository.findByValidityPeriodLessThan(5)).thenReturn(null);
////        assertThrows(InvalidValidityPeriodException.class, () -> policyService.findPoliciesByValidityPeriodLessThan(5));
////    }
////
////    @Test
////    void getPoliciesByNameRegexStartingWith_shouldReturnListOfPolicyDTOs() {
////        when(policyRepository.findByNameStartingWith("Test")).thenReturn(Arrays.asList(policy));
////        List<PolicyDTO> result = assertDoesNotThrow(() -> policyService.getPoliciesByNameRegexStartingWith("Test"));
////        assertEquals(1, result.size());
////        assertEquals(policyDTO, result.get(0));
////    }
////
////    @Test
////    void getPoliciesByNameRegexStartingWith_shouldThrowPolicyNotFoundException_whenNoPoliciesFound() {
////        when(policyRepository.findByNameStartingWith("Nonexistent")).thenReturn(null);
////        assertThrows(PolicyNotFoundException.class, () -> policyService.getPoliciesByNameRegexStartingWith("Nonexistent"));
////    }
////    
////    @Test
////    void testAddPolicy() {
////        when(adminFeignClient.getAdminById(policyDTO.getAdminId())).thenReturn(new ResponseEntity<>(adminDTO, HttpStatus.OK));
////        when(policyRepository.save(any(Policy.class))).thenReturn(policy);
////
////        PolicyDTO result = policyService.addPolicy(policyDTO);
////
////        assertNotNull(result);
////        assertEquals(policyDTO.getPolicyId(), result.getPolicyId());
////        verify(policyRepository, times(1)).save(any(Policy.class));
////    }
////
////    @Test
////    void testUpdatePolicy() throws PolicyNotFoundException {
////        when(policyRepository.findById(policy.getPolicyId())).thenReturn(Optional.of(policy));
////        when(adminFeignClient.getAdminById(UUID.fromString(policyDTO.getAdminId().toString()))).thenReturn(new ResponseEntity<>(adminDTO, HttpStatus.OK));
////        when(policyRepository.save(any(Policy.class))).thenReturn(policy);
////
////        PolicyDTO result = policyService.updatePolicy(policy.getPolicyId(), policy);
////
////        assertNotNull(result);
////        assertEquals(policy.getPolicyId(), result.getPolicyId());
////        verify(policyRepository, times(1)).save(any(Policy.class));
////    }
////
////    @Test
////    void testPurchasePolicy() {
////        when(policyRepository.findById(policy.getPolicyId())).thenReturn(Optional.of(policy));
////        when(customerFeignClient.getCustomerById(UUID.fromString(customerPolicy.getCustomerId()))).thenReturn(new ResponseEntity<>(customerDTO, HttpStatus.OK));
////        when(agentFeignClient.getAgentById(UUID.fromString(customerPolicy.getAgentId()))).thenReturn(new ResponseEntity<>(agentDTO, HttpStatus.OK));
////        when(customerPolicyRepository.save(any(CustomerPolicy.class))).thenReturn(customerPolicy);
////
////        CustomerPolicyDTO result = policyService.purchasePolicy(UUID.fromString(customerPolicy.getCustomerId()), UUID.fromString(policy.getPolicyId()), UUID.fromString(customerPolicy.getAgentId()));
////
////        assertNotNull(result);
////        assertEquals(customerPolicy.getCustomerPolicyId(), result.getCustomerPolicyId());
////        verify(customerPolicyRepository, times(1)).save(any(CustomerPolicy.class));
////    }
////    
////}
//
//package com.example.policy;
//
//import com.example.policy.client.AdminClient;
//import com.example.policy.client.AgentClient;
//import com.example.policy.client.CustomerClient;
//import com.example.policy.controller.PolicyController;
//import com.example.policy.dto.AdminDTO;
//import com.example.policy.dto.AgentDTO;
//import com.example.policy.dto.CustomerDTO;
//import com.example.policy.dto.CustomerPolicyDTO;
//import com.example.policy.dto.PolicyDTO;
//import com.example.policy.exception.InvalidPolicyNameException;
//import com.example.policy.exception.InvalidPremiumAmountException;
//import com.example.policy.exception.InvalidValidityPeriodException;
//import com.example.policy.exception.PolicyNotFoundException;
//import com.example.policy.model.CustomerPolicy;
//import com.example.policy.model.Policy;
//import com.example.policy.model.ResultResponse;
//import com.example.policy.repository.CustomerPolicyRepository;
//import com.example.policy.repository.PolicyRepository;
//import com.example.policy.service.PolicyService;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//
//import java.math.BigDecimal;
//import java.time.LocalDateTime;
//import java.util.Arrays;
//import java.util.List;
//import java.util.Optional;
//import java.util.UUID;
//import java.util.stream.Collectors;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.*;
//
//@ExtendWith(MockitoExtension.class)
//class PolicyModuleApplicationTests {
//
//    @Mock
//    private PolicyRepository policyRepository;
//
//    @Mock
//    private CustomerPolicyRepository customerPolicyRepository;
//
//    @InjectMocks
//    private PolicyService policyService;
//
//    @InjectMocks
//    private PolicyController policyController;
//
//    @Mock
//    private AdminClient adminFeignClient;
//
//    @Mock
//    private CustomerClient customerFeignClient;
//
//    @Mock
//    private AgentClient agentFeignClient;
//
//    private Policy policy;
//    private PolicyDTO policyDTO;
//    private CustomerPolicy customerPolicy;
//    private CustomerPolicyDTO customerPolicyDTO;
//    private AdminDTO adminDTO;
//    private AgentDTO agentDTO;
//    private CustomerDTO customerDTO;
//
//    @BeforeEach
//    void setUp() {
//        policy = new Policy();
//        policy.setPolicyId("3bda663d-4fbd-43a0-9d35-99cd2519bc5e");
//        policy.setName("Test Policy");
//        policy.setPremiumAmount(BigDecimal.valueOf(100));
//        policy.setValidityPeriod(12);
//        policy.setCoverageDetails("Test Coverage");
//        policy.setAdminId(UUID.randomUUID().toString());
//
//        policyDTO = new PolicyDTO();
//        policyDTO.setPolicyId(policy.getPolicyId());
//        policyDTO.setName(policy.getName());
//        policyDTO.setPremiumAmount(policy.getPremiumAmount());
//        policyDTO.setValidityPeriod(policy.getValidityPeriod());
//        policyDTO.setCoverageDetails(policy.getCoverageDetails());
//        policyDTO.setAdminId(UUID.fromString(policy.getAdminId()));
//
//        customerPolicy = new CustomerPolicy();
//        customerPolicy.setCustomerPolicyId(UUID.randomUUID().toString());
//        customerPolicy.setCustomerId(UUID.randomUUID().toString());
//        customerPolicy.setPolicy(policy);
//        customerPolicy.setAgentId(UUID.randomUUID().toString());
//        customerPolicy.setPurchaseDate(LocalDateTime.now());
//
//        customerPolicyDTO = new CustomerPolicyDTO();
//        customerPolicyDTO.setCustomerPolicyId(customerPolicy.getCustomerPolicyId().toString());
//        customerPolicyDTO.setCustomerId(UUID.fromString(customerPolicy.getCustomerId()));
//        customerPolicyDTO.setPolicyId(UUID.fromString(policy.getPolicyId()));
//        customerPolicyDTO.setAgentId(UUID.fromString(customerPolicy.getAgentId()));
//        customerPolicyDTO.setPurchaseDate(customerPolicy.getPurchaseDate());
//
//        adminDTO = new AdminDTO();
//        adminDTO.setAdminId(policy.getAdminId().toString());
//
//        agentDTO = new AgentDTO();
//        agentDTO.setAgentId(customerPolicy.getAgentId().toString());
//
//        customerDTO = new CustomerDTO();
//        customerDTO.setCustomerId(customerPolicy.getCustomerId().toString());
//    }
//
//    @Test
//    void findAll_shouldReturnListOfPolicyDTOs() {
//        when(policyRepository.findAll()).thenReturn(Arrays.asList(policy));
//        List<PolicyDTO> result = policyService.findAll();
//        assertEquals(1, result.size());
//        assertEquals(policyDTO, result.get(0));
//    }
//
//    @Test
//    void save_shouldReturnSavedPolicyDTO() {
//        when(policyRepository.save(any(Policy.class))).thenReturn(policy);
//        PolicyDTO result = policyService.save(policy);
//        assertEquals(policyDTO, result);
//    }
//
//    @Test
//    void deleteById_shouldDeletePolicyAndReturnSuccessMessage() {
//        when(policyRepository.existsById(policy.getPolicyId())).thenReturn(true);
//        String result = assertDoesNotThrow(() -> policyService.deleteById(policy.getPolicyId()));
//        assertEquals("Deleted Successfully", result);
//        verify(policyRepository, times(1)).deleteById(policy.getPolicyId());
//    }
//
//    @Test
//    void deleteById_shouldThrowPolicyNotFoundException_whenPolicyDoesNotExist() {
//        when(policyRepository.existsById("nonexistentId")).thenReturn(false);
//        assertThrows(PolicyNotFoundException.class, () -> policyService.deleteById("nonexistentId"));
//    }
//
//    @Test
//    void findById_shouldReturnPolicyDTO() {
//        when(policyRepository.findById(policy.getPolicyId())).thenReturn(Optional.of(policy));
//        PolicyDTO result = assertDoesNotThrow(() -> policyService.findById(policy.getPolicyId()));
//        assertEquals(policyDTO, result);
//    }
//
//    @Test
//    void findById_shouldThrowPolicyNotFoundException_whenPolicyNotFound() {
//        when(policyRepository.findById("nonexistentId")).thenReturn(Optional.empty());
//        assertThrows(PolicyNotFoundException.class, () -> policyService.findById("nonexistentId"));
//    }
//
//    @Test
//    void updatePolicy_shouldThrowPolicyNotFoundException_whenPolicyNotFound() {
//        Policy updatedPolicy = new Policy();
//        when(policyRepository.findById("nonexistentId")).thenReturn(Optional.empty());
//        assertThrows(PolicyNotFoundException.class, () -> policyService.updatePolicy("nonexistentId", updatedPolicy));
//    }
//
//    @Test
//    void getCustomerPolicyById_shouldReturnCustomerPolicyDTO() {
//        when(customerPolicyRepository.findById(customerPolicy.getCustomerPolicyId())).thenReturn(Optional.of(customerPolicy));
//        CustomerPolicyDTO result = policyService.getCustomerPolicyById(customerPolicy.getCustomerPolicyId());
//        assertEquals(customerPolicyDTO, result);
//    }
//
//    @Test
//    void getCustomerPolicyById_shouldThrowPolicyNotFoundException_whenCustomerPolicyNotFound() {
//        when(customerPolicyRepository.findById("nonexistentId")).thenReturn(Optional.empty());
//        assertThrows(PolicyNotFoundException.class, () -> policyService.getCustomerPolicyById("nonexistentId"));
//    }
//
//    @Test
//    void findPoliciesByName_shouldReturnListOfPolicyDTOs() {
//        when(policyRepository.findByName(policy.getName())).thenReturn(Arrays.asList(policy));
//        List<PolicyDTO> result = assertDoesNotThrow(() -> policyService.findPoliciesByName(policy.getName()));
//        assertEquals(1, result.size());
//        assertEquals(policyDTO, result.get(0));
//    }
//
//    @Test
//    void findPoliciesByName_shouldThrowInvalidPolicyNameException_whenNameIsEmpty() {
//        assertThrows(InvalidPolicyNameException.class, () -> policyService.findPoliciesByName(""));
//    }
//
//    @Test
//    void findPoliciesByName_shouldThrowInvalidPolicyNameException_whenNameIsNull() {
//        assertThrows(InvalidPolicyNameException.class, () -> policyService.findPoliciesByName(null));
//    }
//
//    @Test
//    void findPoliciesByName_shouldThrowInvalidPolicyNameException_whenNoPoliciesFound() {
//        when(policyRepository.findByName("nonexistentName")).thenReturn(null);
//        assertThrows(InvalidPolicyNameException.class, () -> policyService.findPoliciesByName("nonexistentName"));
//    }
//
//    @Test
//    void findPoliciesByPremiumAmountGreaterThan_shouldReturnListOfPolicyDTOs() {
//    	when(policyRepository.findByPremiumAmountGreaterThan(BigDecimal.valueOf(50))).thenReturn(Arrays.asList(policy));
//    	List<PolicyDTO> result = assertDoesNotThrow(() -> policyService.findPoliciesByPremiumAmountGreaterThan(BigDecimal.valueOf(50)));
//    	assertEquals(1, result.size());
//    	assertEquals(policyDTO, result.get(0));
//    	}
//
//    	@Test
//    	void findPoliciesByPremiumAmountGreaterThan_shouldThrowInvalidPremiumAmountException_whenAmountIsNegative() {
//    	    assertThrows(InvalidPremiumAmountException.class, () -> policyService.findPoliciesByPremiumAmountGreaterThan(BigDecimal.valueOf(-10)));
//    	}
//
//    	@Test
//    	void findPoliciesByPremiumAmountGreaterThan_shouldThrowInvalidPremiumAmountException_whenNoPoliciesFound() {
//    	    when(policyRepository.findByPremiumAmountGreaterThan(BigDecimal.valueOf(200))).thenReturn(null);
//    	    assertThrows(InvalidPremiumAmountException.class, () -> policyService.findPoliciesByPremiumAmountGreaterThan(BigDecimal.valueOf(200)));
//    	}
//
//    	@Test
//    	void findPoliciesByPremiumAmountLessThan_shouldReturnListOfPolicyDTOs() {
//    	    when(policyRepository.findByPremiumAmountLessThan(BigDecimal.valueOf(150))).thenReturn(Arrays.asList(policy));
//    	    List<PolicyDTO> result = assertDoesNotThrow(() -> policyService.findPoliciesByPremiumAmountLessThan(BigDecimal.valueOf(150)));
//    	    assertEquals(1, result.size());
//    	    assertEquals(policyDTO, result.get(0));
//    	}
//
//    	@Test
//    	void findPoliciesByPremiumAmountLessThan_shouldThrowInvalidPremiumAmountException_whenAmountIsNegative() {
//    	    assertThrows(InvalidPremiumAmountException.class, () -> policyService.findPoliciesByPremiumAmountLessThan(BigDecimal.valueOf(-10)));
//    	}
//
//    	@Test
//    	void findPoliciesByPremiumAmountLessThan_shouldThrowInvalidPremiumAmountException_whenNoPoliciesFound() {
//    	    when(policyRepository.findByPremiumAmountLessThan(BigDecimal.valueOf(10))).thenReturn(null);
//    	    assertThrows(InvalidPremiumAmountException.class, () -> policyService.findPoliciesByPremiumAmountLessThan(BigDecimal.valueOf(10)));
//    	}
//
//    	@Test
//    	void findPoliciesByValidityPeriodGreaterThan_shouldReturnListOfPolicyDTOs() {
//    	    when(policyRepository.findByValidityPeriodGreaterThan(10)).thenReturn(Arrays.asList(policy));
//    	    List<PolicyDTO> result = assertDoesNotThrow(() -> policyService.findPoliciesByValidityPeriodGreaterThan(10));
//    	    assertEquals(1, result.size());
//    	    assertEquals(policyDTO, result.get(0));
//    	}
//
//    	@Test
//    	void findPoliciesByValidityPeriodGreaterThan_shouldThrowInvalidValidityPeriodException_whenPeriodIsNegative() {
//    	    assertThrows(InvalidValidityPeriodException.class, () -> policyService.findPoliciesByValidityPeriodGreaterThan(-10));
//    	}
//
//    	@Test
//    	void findPoliciesByValidityPeriodGreaterThan_shouldThrowInvalidValidityPeriodException_whenNoPoliciesFound() {
//    	    when(policyRepository.findByValidityPeriodGreaterThan(20)).thenReturn(null);
//    	    assertThrows(InvalidValidityPeriodException.class, () -> policyService.findPoliciesByValidityPeriodGreaterThan(20));
//    	}
//
//    	@Test
//    	void findPoliciesByValidityPeriodLessThan_shouldReturnListOfPolicyDTOs() {
//    	    when(policyRepository.findByValidityPeriodLessThan(15)).thenReturn(Arrays.asList(policy));
//    	    List<PolicyDTO> result = assertDoesNotThrow(() -> policyService.findPoliciesByValidityPeriodLessThan(15));
//    	    assertEquals(1, result.size());
//    	    assertEquals(policyDTO, result.get(0));
//    	}
//
//    	@Test
//    	void findPoliciesByValidityPeriodLessThan_shouldThrowInvalidValidityPeriodException_whenPeriodIsNegative() {
//    	    assertThrows(InvalidValidityPeriodException.class, () -> policyService.findPoliciesByValidityPeriodLessThan(-10));
//    	}
//
//    	@Test
//    	void findPoliciesByValidityPeriodLessThan_shouldThrowInvalidValidityPeriodException_whenNoPoliciesFound() {
//    	    when(policyRepository.findByValidityPeriodLessThan(5)).thenReturn(null);
//    	    assertThrows(InvalidValidityPeriodException.class, () -> policyService.findPoliciesByValidityPeriodLessThan(5));
//    	}
//
//    	@Test
//    	void getPoliciesByNameRegexStartingWith_shouldReturnListOfPolicyDTOs() {
//    	    when(policyRepository.findByNameStartingWith("Test")).thenReturn(Arrays.asList(policy));
//    	    List<PolicyDTO> result = assertDoesNotThrow(() -> policyService.getPoliciesByNameRegexStartingWith("Test"));
//    	    assertEquals(1, result.size());
//    	    assertEquals(policyDTO, result.get(0));
//    	}
//
//    	@Test
//    	void getPoliciesByNameRegexStartingWith_shouldThrowPolicyNotFoundException_whenNoPoliciesFound() {
//    	    when(policyRepository.findByNameStartingWith("Nonexistent")).thenReturn(null);
//    	    assertThrows(PolicyNotFoundException.class, () -> policyService.getPoliciesByNameRegexStartingWith("Nonexistent"));
//    	}
//
//    	@Test
//    	void testAddPolicy() {
//    	    when(adminFeignClient.getAdminById(UUID.fromString(adminDTO.getAdminId())))
//    	        .thenReturn(ResponseEntity.ok(ResultResponse.<AdminDTO>builder()
//    	                .success(true)
//    	                .message(null) // Or "Success" or any message you want
//    	                .data(adminDTO)
//    	                .timestamp(LocalDateTime.now())
//    	                .build()));
//    	    when(policyRepository.save(any(Policy.class))).thenReturn(policy);
//
//    	    PolicyDTO result = policyService.addPolicy(policyDTO);
//
//    	    assertNotNull(result);
//    	    assertEquals(policyDTO.getPolicyId(), result.getPolicyId());
//    	    verify(policyRepository, times(1)).save(any(Policy.class));
//    	}
//
//    	@Test
//    	void testUpdatePolicy() throws PolicyNotFoundException {
//    	    when(policyRepository.findById(policy.getPolicyId())).thenReturn(Optional.of(policy));
//    	    when(adminFeignClient.getAdminById(UUID.fromString(adminDTO.getAdminId())))
//    	        .thenReturn(ResponseEntity.ok(ResultResponse.<AdminDTO>builder()
//    	                .success(true)
//    	                .message(null) // Or "Success" or any message you want
//    	                .data(adminDTO)
//    	                .timestamp(LocalDateTime.now())
//    	                .build()));
//    	    when(policyRepository.save(any(Policy.class))).thenReturn(policy);
//
//    	    PolicyDTO result = policyService.updatePolicy(policy.getPolicyId(), policy);
//
//    	    assertNotNull(result);
//    	    assertEquals(policy.getPolicyId(), result.getPolicyId());
//    	    verify(policyRepository, times(1)).save(any(Policy.class));
//    	}
//
//    	@Test
//    	void testPurchasePolicy() {
//    	    // Set the customerPolicyId before mocking the save method
//    	    customerPolicy.setCustomerPolicyId(UUID.randomUUID().toString());
//
//    	    when(policyRepository.findById(policy.getPolicyId())).thenReturn(Optional.of(policy));
//    	    when(customerFeignClient.getCustomerById(UUID.fromString(customerDTO.getCustomerId())))
//    	        .thenReturn(ResponseEntity.ok(ResultResponse.<CustomerDTO>builder()
//    	                .success(true)
//    	                .message(null)
//    	                .data(customerDTO)
//    	                .timestamp(LocalDateTime.now())
//    	                .build()));
//    	    when(agentFeignClient.getAgentById(UUID.fromString(agentDTO.getAgentId())))
//    	        .thenReturn(ResponseEntity.ok(ResultResponse.<AgentDTO>builder()
//    	                .success(true)
//    	                .message(null)
//    	                .data(agentDTO)
//    	                .timestamp(LocalDateTime.now())
//    	                .build()));
//    	    when(customerPolicyRepository.save(any(CustomerPolicy.class))).thenReturn(customerPolicy);
//
//    	    CustomerPolicyDTO result = policyService.purchasePolicy(UUID.fromString(customerDTO.getCustomerId()), UUID.fromString(policy.getPolicyId()), UUID.fromString(agentDTO.getAgentId()));
//
//    	    assertNotNull(result);
//    	    assertEquals(customerPolicy.getCustomerPolicyId(), result.getCustomerPolicyId());
//    	    verify(customerPolicyRepository, times(1)).save(any(CustomerPolicy.class));
//    	}
//    	}