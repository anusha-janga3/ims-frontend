package com.example.policy.model;

public enum CustomerPolicyStatus {
	Active,
	Expired;
}

