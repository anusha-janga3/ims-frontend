package com.example.policy.exception;

public class InvalidValidityPeriodException extends RuntimeException {

	public InvalidValidityPeriodException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
