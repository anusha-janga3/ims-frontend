package com.example.policy.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.policy.dto.CustomerDTO;
import com.example.policy.model.ResultResponse;

import java.util.UUID;
 
@FeignClient(name = "customer-service")
public interface CustomerClient {
 
    @GetMapping("/api/v1/customers/{customerId}")
    ResponseEntity<ResultResponse<CustomerDTO>> getCustomerById(@PathVariable UUID customerId);
    // Add other customer-related endpoints as needed
}
