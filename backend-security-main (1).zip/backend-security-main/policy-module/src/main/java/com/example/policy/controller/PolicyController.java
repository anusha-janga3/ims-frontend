package com.example.policy.controller;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.example.policy.model.ResultResponse;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.policy.dto.AgentDTO;
import com.example.policy.dto.CustomerDTO;
import com.example.policy.dto.CustomerPolicyDTO;
import com.example.policy.dto.PolicyDTO;
import com.example.policy.exception.AdminNotFoundException;
import com.example.policy.exception.AgentNotFoundException;
import com.example.policy.exception.CustomerNotFoundException;
import com.example.policy.exception.FailedAssignmentException;
import com.example.policy.exception.InvalidPolicyNameException;
import com.example.policy.exception.InvalidPremiumAmountException;
import com.example.policy.exception.InvalidValidityPeriodException;
import com.example.policy.exception.PolicyAlreadyTakenException;
import com.example.policy.exception.PolicyNotFoundException;
import com.example.policy.model.CustomerPolicy;
import com.example.policy.model.Policy;
import com.example.policy.repository.CustomerPolicyRepository;
import com.example.policy.repository.PolicyRepository;
import com.example.policy.service.PolicyService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

// import com.example.JPAProject.entity.Employee;
// import com.example.JPAProject.service.EmployeeService;
@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/v1/policies")
@Slf4j
public class PolicyController {
	@Autowired
	private PolicyService policyService;
	@Autowired
	private Policy policy;
	@Autowired
	private CustomerPolicyRepository customerPolicyRepository;

//Retrieves all policies from the repository and returns the responseEntity containing the status code,header and the message upon successful completion else throws an Exception.
	@GetMapping
	public ResponseEntity<ResultResponse<List<PolicyDTO>>> findAll() {
		try {
			List<PolicyDTO> policies = policyService.findAll();
			return ResponseEntity.ok(ResultResponse.<List<PolicyDTO>>builder().data(policies).success(true)
					.timestamp(LocalDateTime.now()).build());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ResultResponse.<List<PolicyDTO>>builder().message(e.getMessage()).success(false)
							.timestamp(LocalDateTime.now()).build());
		}
	}

//Finds a policy by its ID and returns the responseEntity containing the status code,header and the message upon successful completion else throws a PolicyNotFoundException.
	@GetMapping("/{policyId}")
	public ResponseEntity<ResultResponse<PolicyDTO>> getPolicyById(@Valid @PathVariable String policyId) {
		try {
			PolicyDTO policy = policyService.findById(policyId);
			return ResponseEntity.ok(ResultResponse.<PolicyDTO>builder().data(policy).success(true)
					.timestamp(LocalDateTime.now()).build());
		} catch (PolicyNotFoundException e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<PolicyDTO>builder()
					.message(e.getMessage()).success(false).timestamp(LocalDateTime.now()).build());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<PolicyDTO>builder()
					.message(e.getMessage()).success(false).timestamp(LocalDateTime.now()).build());
		}
	}

//Saves a policy and returns the responseEntity containing the status code,header and the message upon successful completion else throws an Exception.
	@PostMapping
	public ResponseEntity<ResultResponse<PolicyDTO>> save(@Valid @RequestBody Policy policy) {
		try {
			PolicyDTO savedPolicy = policyService.save(policy);
			return ResponseEntity.status(HttpStatus.CREATED).body(ResultResponse.<PolicyDTO>builder().data(savedPolicy)
					.success(true).timestamp(LocalDateTime.now()).build());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<PolicyDTO>builder()
					.message(e.getMessage()).success(false).timestamp(LocalDateTime.now()).build());
		}
	}

//Deletes a policy by its ID and returns the responseEntity containing the status code,header and the message upon successful completion else throws a PolicyNotFoundException.
	@DeleteMapping("/{id}")
	public ResponseEntity<ResultResponse<Void>> deleteById(@Valid @PathVariable String id) {
		try {
			policyService.deleteById(id);
			return ResponseEntity
					.ok(ResultResponse.<Void>builder().success(true).timestamp(LocalDateTime.now()).build());
		} catch (PolicyNotFoundException e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<Void>builder()
					.message(e.getMessage()).success(false).timestamp(LocalDateTime.now()).build());
		}
	}

	/**
	 * Adds a policy to the database and returns the responseEntity containing the
	 * status code,header and the message upon successful completion else throws an
	 * error if the adminId is empty or the given adminId doesn't exists
	 **/
	@PostMapping("/add")
	public ResponseEntity<ResultResponse<PolicyDTO>> addPolicy(@Valid @RequestBody PolicyDTO policyDTO) {
		try {
			log.debug("inside the add policy");
			PolicyDTO savedPolicyDTO = policyService.addPolicy(policyDTO);
			return ResponseEntity.status(HttpStatus.CREATED).body(ResultResponse.<PolicyDTO>builder()
					.data(savedPolicyDTO).success(true).timestamp(LocalDateTime.now()).build());
		} catch (AdminNotFoundException e) {
			return ResponseEntity.badRequest().body(ResultResponse.<PolicyDTO>builder().message(e.getMessage())
					.success(false).timestamp(LocalDateTime.now()).build());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<PolicyDTO>builder()
					.message(e.getMessage()).success(false).timestamp(LocalDateTime.now()).build());
		}
	}

	/**
	 * Retrieves the policies by their name and returns the responseEntity upon
	 * successfully fetching else throws an exception if the policy name specified
	 * by the user is not present in the database
	 **/
	@GetMapping("/name/{name}")
	public ResponseEntity<ResultResponse<List<PolicyDTO>>> getPoliciesByName(@Valid @PathVariable String name) {
		try {
			List<PolicyDTO> policies = policyService.findPoliciesByName(name);
			return ResponseEntity.ok(ResultResponse.<List<PolicyDTO>>builder().data(policies).success(true)
					.timestamp(LocalDateTime.now()).build());
		} catch (InvalidPolicyNameException e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<List<PolicyDTO>>builder()
					.message(e.getMessage()).success(false).timestamp(LocalDateTime.now()).build());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ResultResponse.<List<PolicyDTO>>builder().message(e.getMessage()).success(false)
							.timestamp(LocalDateTime.now()).build());
		}
	}

	/**
	 * Retrieves the policy by the premiumAmount greater than the amount specified
	 * by the user and returns the responseEntity upon successful fetching else
	 * throws an exception if the amount specified by the user is not present in the
	 * database
	 **/
	@GetMapping("/greaterPremium/{premiumAmount}")
	public ResponseEntity<ResultResponse<List<PolicyDTO>>> getPoliciesByPremiumAmountGreaterThan(
			@Valid @PathVariable BigDecimal premiumAmount) {
		try {
			List<PolicyDTO> policies = policyService.findPoliciesByPremiumAmountGreaterThan(premiumAmount);
			return ResponseEntity.ok(ResultResponse.<List<PolicyDTO>>builder().data(policies).success(true)
					.timestamp(LocalDateTime.now()).build());
		} catch (InvalidPremiumAmountException e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<List<PolicyDTO>>builder()
					.message(e.getMessage()).success(false).timestamp(LocalDateTime.now()).build());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ResultResponse.<List<PolicyDTO>>builder().message(e.getMessage()).success(false)
							.timestamp(LocalDateTime.now()).build());
		}
	}

	/**
	 * Retrieves the policy by the premiumAmount lesser than the amount specified by
	 * the user and returns the responseEntity upon successful fetching else throws
	 * an exception if the amount specified by the user is not present in the
	 * database
	 **/
	@GetMapping("/lesserPremium/{premiumAmount}")
	public ResponseEntity<ResultResponse<List<PolicyDTO>>> getPoliciesByPremiumAmountLessThan(
			@Valid @PathVariable BigDecimal premiumAmount) {
		try {
			List<PolicyDTO> policies = policyService.findPoliciesByPremiumAmountLessThan(premiumAmount);
			return ResponseEntity.ok(ResultResponse.<List<PolicyDTO>>builder().data(policies).success(true)
					.timestamp(LocalDateTime.now()).build());
		} catch (InvalidPremiumAmountException e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<List<PolicyDTO>>builder()
					.message(e.getMessage()).success(false).timestamp(LocalDateTime.now()).build());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ResultResponse.<List<PolicyDTO>>builder().message(e.getMessage()).success(false)
							.timestamp(LocalDateTime.now()).build());
		}
	}

	/**
	 * Retrieves the policy by the ValidityPeriod greater than the period specified
	 * by the user and returns the responseEntity upon successful fetching else
	 * throws an exception if the period specified by the user is not present in the
	 * database
	 **/
	@GetMapping("/greaterValidity/{validityPeriod}")
	public ResponseEntity<ResultResponse<List<PolicyDTO>>> getPoliciesByValidityPeriodGreaterThan(
			@Valid @PathVariable int validityPeriod) {
		try {
			List<PolicyDTO> policies = policyService.findPoliciesByValidityPeriodGreaterThan(validityPeriod);
			return ResponseEntity.ok(ResultResponse.<List<PolicyDTO>>builder().data(policies).success(true)
					.timestamp(LocalDateTime.now()).build());
		} catch (InvalidValidityPeriodException e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<List<PolicyDTO>>builder()
					.message(e.getMessage()).success(false).timestamp(LocalDateTime.now()).build());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ResultResponse.<List<PolicyDTO>>builder().message(e.getMessage()).success(false)
							.timestamp(LocalDateTime.now()).build());
		}
	}

	/**
	 * Retrieves the policy by the ValidityPeriod lesser than the period specified
	 * by the user and returns the responseEntity upon successful fetching else
	 * throws an exception if the period specified by the user is not present in the
	 * database
	 **/
	@GetMapping("/lesserValidity/{validityPeriod}")
	public ResponseEntity<ResultResponse<List<PolicyDTO>>> getPoliciesByValidityPeriodLessThan(
			@Valid @PathVariable int validityPeriod) {
		try {
			List<PolicyDTO> policies = policyService.findPoliciesByValidityPeriodLessThan(validityPeriod);
			return ResponseEntity.ok(ResultResponse.<List<PolicyDTO>>builder().data(policies).success(true)
					.timestamp(LocalDateTime.now()).build());
		} catch (InvalidValidityPeriodException e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<List<PolicyDTO>>builder()
					.message(e.getMessage()).success(false).timestamp(LocalDateTime.now()).build());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ResultResponse.<List<PolicyDTO>>builder().message(e.getMessage()).success(false)
							.timestamp(LocalDateTime.now()).build());
		}
	}

	/**
	 * Assigns the agents to the customers and returns the responseEntity upon
	 * successful assignment else throws CustomerNotFoundException or
	 * PolicyNotFoundException or AgentNotFoundException if any of the three fields
	 * is not present in the database.
	 **/
	@PostMapping("/purchase")
	public ResponseEntity<ResultResponse<CustomerPolicyDTO>> purchasePolicy(
			@RequestBody CustomerPolicyDTO purchaseRequest) {
		try {
			CustomerPolicyDTO customerPolicyDTO = policyService.purchasePolicy(purchaseRequest.getCustomerId(),
					purchaseRequest.getPolicyId(), purchaseRequest.getAgentId());
			return ResponseEntity.status(HttpStatus.CREATED).body(ResultResponse.<CustomerPolicyDTO>builder()
					.data(customerPolicyDTO).success(true).timestamp(LocalDateTime.now()).build());
		} catch (CustomerNotFoundException | PolicyNotFoundException | AgentNotFoundException e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<CustomerPolicyDTO>builder()
					.message(e.getMessage()).success(false).timestamp(LocalDateTime.now()).build());
		} catch (PolicyAlreadyTakenException e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ResultResponse.<CustomerPolicyDTO>builder()
					.message(e.getMessage()).success(false).timestamp(LocalDateTime.now()).build());
		}catch (FailedAssignmentException e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ResultResponse.<CustomerPolicyDTO>builder()
					.message(e.getMessage()).success(false).timestamp(LocalDateTime.now()).build());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ResultResponse.<CustomerPolicyDTO>builder().message(e.getMessage()).success(false)
							.timestamp(LocalDateTime.now()).build());
		}
	}
	
	

	/**
	 * Updates the existing policy and returns the responseEntity as a response upon
	 * the successful completion of the updation. else throws an exception if the
	 * given policyId is not present in the database
	 **/
	@PutMapping("/update/{policyId}")
	public ResponseEntity<ResultResponse<PolicyDTO>> updatePolicy(@Valid @PathVariable String policyId,
			@Valid @RequestBody Policy updatedPolicy) {
		try {
			PolicyDTO savedPolicyDTO = policyService.updatePolicy(policyId, updatedPolicy);
			log.info("Policy updated: {}", savedPolicyDTO);
			return ResponseEntity.ok(ResultResponse.<PolicyDTO>builder().data(savedPolicyDTO).success(true)
					.timestamp(LocalDateTime.now()).build());
		} catch (PolicyNotFoundException e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<PolicyDTO>builder()
					.message(e.getMessage()).success(false).timestamp(LocalDateTime.now()).build());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<PolicyDTO>builder()
					.message(e.getMessage()).success(false).timestamp(LocalDateTime.now()).build());
		}
	}

//	@GetMapping("/customerPolicy/{customerPolicyId}")
//	public ResponseEntity<ResultResponse<CustomerPolicyDTO>> getCustomerPolicyById(
//			@PathVariable String customerPolicyId) {
//		try {
//			CustomerPolicyDTO customerPolicy = policyService.getCustomerPolicyById(customerPolicyId);
//
//			return ResponseEntity.ok(ResultResponse.<CustomerPolicyDTO>builder().data(customerPolicy).success(true)
//					.timestamp(LocalDateTime.now()).build());
//
//		} catch (PolicyNotFoundException e) {
//			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<CustomerPolicyDTO>builder()
//					.message(e.getMessage()).success(false).timestamp(LocalDateTime.now()).build());
//		} catch (Exception e) {
//			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//					.body(ResultResponse.<CustomerPolicyDTO>builder().message(e.getMessage()).success(false)
//							.timestamp(LocalDateTime.now()).build());
//		}
//	}

	@GetMapping("/startsWith/{prefix}")
	public ResponseEntity<ResultResponse<List<PolicyDTO>>> getPoliciesStartingWith(@PathVariable String prefix) {
		try {
			List<PolicyDTO> policies = policyService.getPoliciesByNameRegexStartingWith(prefix);
			return ResponseEntity.ok(ResultResponse.<List<PolicyDTO>>builder().data(policies).success(true)
					.timestamp(LocalDateTime.now()).build());
		} catch (InvalidPolicyNameException e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<List<PolicyDTO>>builder()
					.message(e.getMessage()).success(false).timestamp(LocalDateTime.now()).build());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ResultResponse.<List<PolicyDTO>>builder().message(e.getMessage()).success(false)
							.timestamp(LocalDateTime.now()).build());
		}
	}

	@GetMapping("/customer/{customerId}")
	public ResponseEntity<ResultResponse<List<CustomerPolicyDTO>>> getPolicyByCustomerId(
			@PathVariable String customerId) {
		log.info("Received request to get claims by customer id: {}", customerId);
		try {
			List<CustomerPolicyDTO> policies = policyService.findByCustomerId(customerId);
			ResultResponse<List<CustomerPolicyDTO>> response = ResultResponse.<List<CustomerPolicyDTO>>builder()
					.data(policies).success(true).timestamp(LocalDateTime.now()).build();
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (PolicyNotFoundException e) {
			ResultResponse<List<CustomerPolicyDTO>> response = ResultResponse.<List<CustomerPolicyDTO>>builder()
					.message(e.getMessage()).success(false).timestamp(LocalDateTime.now()).build();
			return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/agent/{agentId}")
	public ResponseEntity<ResultResponse<List<CustomerPolicyDTO>>> getPolicyByAgentId(@PathVariable String agentId) {
		log.info("Received request to get claims by agent id: {}", agentId);
		try {
			List<CustomerPolicyDTO> policies = policyService.findByAgentId(agentId);
			ResultResponse<List<CustomerPolicyDTO>> response = ResultResponse.<List<CustomerPolicyDTO>>builder()
					.data(policies).success(true).timestamp(LocalDateTime.now()).build();
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (PolicyNotFoundException e) {
			ResultResponse<List<CustomerPolicyDTO>> response = ResultResponse.<List<CustomerPolicyDTO>>builder()
					.message(e.getMessage()).success(false).timestamp(LocalDateTime.now()).build();
			return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
		}
	}
	@GetMapping("/filtered")
	public ResponseEntity<ResultResponse<List<PolicyDTO>>> getFilteredPolicies(
			@RequestParam(value = "nameStartsWith", required = false) String nameStartsWith,
			@RequestParam(value = "premium", required = false) String premium,
			@RequestParam(value = "validity", required = false) String validity) {
		try {
			List<PolicyDTO> filteredPolicies = policyService.getFilteredPolicies(nameStartsWith, premium, validity);
			if ((nameStartsWith != null && !nameStartsWith.isEmpty()) ||
					(premium != null && !premium.isEmpty()) ||
					(validity != null && !validity.isEmpty())) {
				if (filteredPolicies.isEmpty()) {
					return new ResponseEntity<>(ResultResponse.<List<PolicyDTO>>builder()
							.message("No policies found with the given constraints.")
							.success(false)
							.timestamp(LocalDateTime.now())
							.build(), HttpStatus.NOT_FOUND);
				}
			}
			return ResponseEntity.ok(ResultResponse.<List<PolicyDTO>>builder()
					.data(filteredPolicies)
					.success(true)
					.timestamp(LocalDateTime.now())
					.build());
		}  catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ResultResponse.<List<PolicyDTO>>builder()
							.message(e.getMessage())
							.success(false)
							.timestamp(LocalDateTime.now())
							.build());
		}
	}
 
}
