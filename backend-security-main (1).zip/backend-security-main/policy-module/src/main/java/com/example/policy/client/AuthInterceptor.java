package com.example.policy.client; // Assuming the package is correct

import feign.RequestInterceptor;
import feign.RequestTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import jakarta.servlet.http.HttpServletRequest; // Ensure this import is correct

@Component
public class AuthInterceptor implements RequestInterceptor {
    @Override
    public void apply(RequestTemplate template) {
        ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (requestAttributes != null) {
            HttpServletRequest request = requestAttributes.getRequest();
            String authorizationHeader = request.getHeader("Authorization");
            if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
                template.header("Authorization", authorizationHeader);
                System.out.println("Authorization header set: " + authorizationHeader);
            } else {
                System.out.println("Authorization header not found or invalid");
            }
        }
    }
}
    
    

//    @Bean
//    public RequestInterceptor authInterceptor() {
//        return new AuthInterceptor();
//    }
