package com.example.policy.model;

import java.time.LocalDateTime;
import java.util.UUID;

import org.springframework.stereotype.Component;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Component
@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name="CustomerPolicy")
public class CustomerPolicy {
	
	@Id
	@Column(name="customerPolicyId")
	private String customerPolicyId;
	
	@Column(name="purchaseDate",nullable=false)
	private LocalDateTime purchaseDate;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "status", columnDefinition = "ENUM('Active', 'Expired')", nullable = false)
	private CustomerPolicyStatus status = CustomerPolicyStatus.Active;
	
	
	@Column(name="customerId",nullable=false)
	private String customerId;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="policyId")
	private Policy policy;
	
	@Column(name="agentId")
	private String agentId;
	
	@Column(name = "created_at", updatable = false)
	private LocalDateTime createdAt;

	@Column(name = "updated_at")
	private LocalDateTime updatedAt;

	@PrePersist
	public void generateUuidAndCreatedAt() {
		String uuid=UUID.randomUUID().toString();
		customerPolicyId = uuid;
		this.createdAt = LocalDateTime.now();
		this.updatedAt = LocalDateTime.now();
	   }

	 @PreUpdate
	 public void updateUpdatedAt() {
		 this.updatedAt = LocalDateTime.now();
	   }
	
}
