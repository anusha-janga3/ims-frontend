package com.example.policy.repository;

import org.springframework.stereotype.Repository;

import com.example.policy.dto.PolicyDTO;
import com.example.policy.model.Policy;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

@Repository
public interface PolicyRepository extends JpaRepository<Policy,String> 
{
	@Query("SELECT p FROM Policy p WHERE name=:name")
	List<Policy> findByName(String name);
	
	@Query("SELECT p FROM Policy p WHERE premiumAmount>:premiumAmount")
	List<Policy> findByPremiumAmountGreaterThan(BigDecimal premiumAmount);
	
	@Query("SELECT p FROM Policy p WHERE premiumAmount<:premiumAmount")
	List<Policy> findByPremiumAmountLessThan(BigDecimal premiumAmount);
	
	@Query("SELECT p FROM Policy p WHERE validityPeriod>:validityPeriod")
	List<Policy> findByValidityPeriodGreaterThan(int validityPeriod);
	
	@Query("SELECT p FROM Policy p WHERE validityPeriod<:validityPeriod")
	List<Policy> findByValidityPeriodLessThan(int validityPeriod);
	
	@Query("SELECT p FROM Policy p WHERE p.name LIKE :prefix%")
    List<Policy> findByNameStartingWith(@Param("prefix") String prefix);
}
