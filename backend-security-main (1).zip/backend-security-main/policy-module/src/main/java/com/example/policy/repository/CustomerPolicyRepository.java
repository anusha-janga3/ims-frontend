package com.example.policy.repository;
 
import java.util.List;
import java.util.UUID;
 
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
 
import com.example.policy.model.CustomerPolicy;
import com.example.policy.model.Policy;

import feign.Param;
 
 
@Repository
public interface CustomerPolicyRepository extends JpaRepository<CustomerPolicy,String> {
 
	@Query("SELECT cp FROM CustomerPolicy cp WHERE customerId=:customerId")
	List<CustomerPolicy> findByCustomerId(String customerId);
	
	@Query("SELECT cp FROM CustomerPolicy cp WHERE agentId=:agentId")
	List<CustomerPolicy> findByAgentId(String agentId);
	
	boolean existsByCustomerIdAndPolicy_PolicyId(String customerId, String policyId);
 
}
 
 