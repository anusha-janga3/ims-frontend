package com.example.policy.exception;

public class InvalidPremiumAmountException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

	public InvalidPremiumAmountException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
}
