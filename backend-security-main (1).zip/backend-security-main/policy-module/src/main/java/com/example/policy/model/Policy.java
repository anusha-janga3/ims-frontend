package com.example.policy.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.springframework.stereotype.Component;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import com.fasterxml.jackson.annotation.JsonIgnore;
@Component
@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name="Policy")
public class Policy {
	
	@Id
	@Column(name="policyId")
	private String policyId;
	
	@Column(name="coverageDetails",nullable=false,columnDefinition="TEXT")
	private String coverageDetails;
	
	@Column(name="validityPeriod",nullable=false)
	private int validityPeriod;
	
	@Column(name="name",nullable=false,unique=true)
	private String name;
	
	@Column(name="premiumAmount",nullable=false)
	private BigDecimal premiumAmount;
	
//	@OneToMany(mappedBy="policy",fetch=FetchType.EAGER)
//	private Set<Claim> claims=new HashSet<>();
	
//	@OneToMany(mappedBy="policy",fetch=FetchType.EAGER)
//	private Set<PolicyAssign> policyAssigns=new HashSet<>();
	
	@OneToMany(mappedBy="policy",fetch=FetchType.EAGER)
	private Set<CustomerPolicy> customerPolicies=new HashSet<>();
	
	@Column(name="adminId")
	private String adminId;
	
	@Column(name = "created_at", updatable = false)
	 private LocalDateTime createdAt;
	 
	 @Column(name = "updated_at")
	 private LocalDateTime updatedAt;
	 
	 @PrePersist
	    public void generateUuidAndCreatedAt() {
	        String uuid= UUID.randomUUID().toString();
	        policyId=uuid;
	        this.createdAt = LocalDateTime.now();
	        this.updatedAt = LocalDateTime.now();
	    }
	 
	    @PreUpdate
	    public void updateUpdatedAt() {
	        this.updatedAt = LocalDateTime.now();
	    }

}

