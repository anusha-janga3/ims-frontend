package com.example.policy.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Validated
@EqualsAndHashCode
@JsonIgnoreProperties(ignoreUnknown=true)
public class PolicyDTO {
	
	private String policyId;
	
	@NotBlank(message = "Coverage details cannot be blank")
    private String coverageDetails;

    @Min(value = 1, message = "Validity period must be at least 1")
    private int validityPeriod;

    @NotBlank(message = "Policy name cannot be blank")
    private String name;

    @NotNull(message = "Premium amount cannot be null")
    @DecimalMin(value = "0.01", message = "Premium amount must be greater than 0")
    private BigDecimal premiumAmount;
	
    @NotNull(message="AdminId cannot be null")
	private UUID adminId;
	
	 private LocalDateTime createdAt;

	 private LocalDateTime updatedAt;
	 
	}
