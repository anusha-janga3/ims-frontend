package com.example.policy.service;

import com.example.policy.dto.AdminDTO;
import com.example.policy.dto.AgentDTO;
import com.example.policy.dto.CustomerDTO;
import com.example.policy.dto.CustomerPolicyDTO;
import com.example.policy.dto.PolicyDTO;
import com.example.policy.exception.CustomerNotFoundException;
import com.example.policy.exception.InvalidPolicyNameException;
import com.example.policy.exception.InvalidPremiumAmountException;
import com.example.policy.exception.InvalidValidityPeriodException;
import com.example.policy.exception.PolicyAlreadyTakenException;
import com.example.policy.exception.PolicyNotFoundException;
import com.example.policy.model.CustomerPolicy;
import com.example.policy.model.Policy;
import com.example.policy.model.ResultResponse;
import com.example.policy.repository.CustomerPolicyRepository;
import com.example.policy.repository.PolicyRepository;
import com.example.policy.client.AdminClient;
import com.example.policy.client.AgentClient;
import com.example.policy.client.CustomerClient;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Service
public class PolicyService {

	@Autowired
	private PolicyRepository policyRepository;

	@Autowired
	private CustomerPolicyRepository customerPolicyRepository;

	@Autowired
	private AdminClient adminFeignClient;

	@Autowired
	private AgentClient agentFeignClient;

	@Autowired
	private CustomerClient customerFeignClient;
	@Autowired
	private AdminDTO adminDTO;

	private static final Logger logger = LoggerFactory.getLogger(PolicyService.class);

	public List<PolicyDTO> findAll() {
		log.info("Fetching all policies");
		return policyRepository.findAll().stream().map(this::convertToDTO).collect(Collectors.toList());
	}

	public PolicyDTO save(Policy policy) {
		return convertToDTO(policyRepository.save(policy));
	}

	public String deleteById(String id) throws PolicyNotFoundException {
		if (!policyRepository.existsById(id)) {
			throw new PolicyNotFoundException("Policy with ID: " + id + " not found.");
		}
		policyRepository.deleteById(id);
		return "Deleted Successfully";
	}

	public PolicyDTO findById(String id) {
		Optional<Policy> op = policyRepository.findById(id);
		log.info("enter PolicyService::addPolicy");
		if (op.isPresent()) {
			return convertToDTO(op.get());
		} else {
			throw new PolicyNotFoundException("Policy not found for this policy id: " + id);
		}
	}

	public PolicyDTO addPolicy(PolicyDTO policyDTO) {
		Policy policy = new Policy();
		policy.setName(policyDTO.getName());
		policy.setPremiumAmount(policyDTO.getPremiumAmount());
		policy.setValidityPeriod(policyDTO.getValidityPeriod());
		policy.setCoverageDetails(policyDTO.getCoverageDetails());
		policy.setPolicyId(policyDTO.getPolicyId());
		if (policyDTO.getAdminId() != null) {
			ResponseEntity<ResultResponse<AdminDTO>> response = adminFeignClient.getAdminById(policyDTO.getAdminId());
			policy.setAdminId(policyDTO.getAdminId().toString());
			if (response.getStatusCode() != HttpStatus.OK) {
				throw new RuntimeException("Admin not found with id: " + policyDTO.getAdminId());
			}
		}
		Policy savedPolicy = policyRepository.save(policy);
		log.info("saved policy {}", savedPolicy.getPolicyId());
		PolicyDTO policyDto = convertToDTO(savedPolicy);
		log.info("{} {} {}", policyDto.getPolicyId(), policyDto.getCreatedAt(), policyDto.getUpdatedAt());
		return policyDto;
	}

	public PolicyDTO updatePolicy(String policyId, Policy updatedPolicy) throws PolicyNotFoundException {
		Policy existingPolicy = policyRepository.findById(policyId)
				.orElseThrow(() -> new PolicyNotFoundException("Policy not found with id: " + policyId));

		if (updatedPolicy.getName() != null) {
			existingPolicy.setName(updatedPolicy.getName());
		}
		if (updatedPolicy.getCoverageDetails() != null) {
			existingPolicy.setCoverageDetails(updatedPolicy.getCoverageDetails());
		}
		if (updatedPolicy.getPremiumAmount() != null) {
			existingPolicy.setPremiumAmount(updatedPolicy.getPremiumAmount());
		}
		if (updatedPolicy.getValidityPeriod() != 0) {
			existingPolicy.setValidityPeriod(updatedPolicy.getValidityPeriod());
		}
		if (updatedPolicy.getAdminId() != null) {
			ResponseEntity<ResultResponse<AdminDTO>> response = adminFeignClient
					.getAdminById(UUID.fromString(updatedPolicy.getAdminId()));
			if (response.getStatusCode() != HttpStatus.OK) {
				throw new RuntimeException("Admin not found with id: " + updatedPolicy.getAdminId());
			}
			existingPolicy.setAdminId(updatedPolicy.getAdminId());
		}

		Policy savedPolicy = policyRepository.save(existingPolicy);
		return convertToDTO(savedPolicy);
	}

    public CustomerPolicyDTO purchasePolicy(UUID customerId, UUID policyId, UUID agentId) {
        log.info("Customer {} purchasing policy {} through agent {}", customerId, policyId, agentId);
 
        Policy policy = policyRepository.findById(policyId.toString())
                .orElseThrow(() -> new PolicyNotFoundException("Policy not found with id: " + policyId));
 
        ResponseEntity<ResultResponse<CustomerDTO>> customerResponse = customerFeignClient.getCustomerById(customerId);
        if (customerResponse.getStatusCode() != HttpStatus.OK) {
            throw new RuntimeException("Customer not found with id: " + customerId);
        }
 
        ResponseEntity<ResultResponse<AgentDTO>> agentResponse = agentFeignClient.getAgentById(agentId);
        if (agentResponse.getStatusCode() != HttpStatus.OK) {
            throw new RuntimeException("Agent not found with id: " + agentId);
        }
 
        // Check if the customer already has the policy
        boolean existingCustomerPolicy = customerPolicyRepository.existsByCustomerIdAndPolicy_PolicyId(customerId.toString(),policyId.toString());
        if (existingCustomerPolicy) {
            throw new PolicyAlreadyTakenException("Customer already has this policy: " + policyId);
        }
 
        CustomerPolicy customerPolicy = new CustomerPolicy();
        customerPolicy.setCustomerId(customerId.toString());
        customerPolicy.setPolicy(policy);
        customerPolicy.getPolicy().setPolicyId(policyId.toString());
        customerPolicy.setAgentId(agentId.toString());
        customerPolicy.setPurchaseDate(LocalDateTime.now());
 
        // Save and retrieve the saved entity to get the generated customerPolicyId
        CustomerPolicy savedCustomerPolicy = customerPolicyRepository.save(customerPolicy);
 
        return convertToCustomerPolicyDTO(savedCustomerPolicy);
    }
	
	private PolicyDTO convertToDTO(Policy policy) {
		PolicyDTO dto = new PolicyDTO();
		dto.setPolicyId(policy.getPolicyId());
		dto.setCoverageDetails(policy.getCoverageDetails());
		dto.setValidityPeriod(policy.getValidityPeriod());
		dto.setName(policy.getName());
		dto.setPremiumAmount(policy.getPremiumAmount());
		dto.setCreatedAt(policy.getCreatedAt());
		dto.setUpdatedAt(policy.getUpdatedAt());
		if (policy.getAdminId() != null) {
			dto.setAdminId(UUID.fromString(policy.getAdminId()));
		}
		return dto;
	}

	private CustomerPolicyDTO convertToCustomerPolicyDTO(CustomerPolicy customerPolicy) {
		CustomerPolicyDTO dto = new CustomerPolicyDTO();
		dto.setCustomerPolicyId(customerPolicy.getCustomerPolicyId());
		dto.setCustomerId(UUID.fromString(customerPolicy.getCustomerId()));
		dto.setPolicyId(UUID.fromString(customerPolicy.getPolicy().getPolicyId()));
		dto.setAgentId(UUID.fromString(customerPolicy.getAgentId()));
		dto.setPurchaseDate(customerPolicy.getPurchaseDate());
		return dto;
	}

	/**
	 * Finds policies by name,and checks if the name given by the customer matches
	 * the one in the database which is a case-insensitive match. and returns a list
	 * of PolicyDTOs matching the given name upon successful fetching. else throws a
	 * InvalidPolicyNameException If the name is null, empty, or no matching
	 * policies are found.
	 */
	public List<PolicyDTO> findPoliciesByName(String name) {
		if (name == null || name.trim().isEmpty()) {
			throw new InvalidPolicyNameException("Policy name cannot be empty or null.");
		}

		List<Policy> policies = policyRepository.findByName(name);

		if (policies == null || policies.isEmpty()) {
			throw new InvalidPolicyNameException("No policies found with name: " + name);
		}

// Check for exact name match
		List<Policy> matchingPolicies = policies.stream().filter(policy -> policy.getName().equalsIgnoreCase(name)) // Case-insensitive
																													// comparison
				.collect(Collectors.toList());

		if (matchingPolicies.isEmpty()) {
			throw new InvalidPolicyNameException("No policies found with name: " + name);
		}

		return matchingPolicies.stream().map(this::convertToDTO).collect(Collectors.toList());
	}

	/**
	 * Finds policies with a premium amount greater than the specified amount and
	 * returns a list of PolicyDTOs.
	 */
	public List<PolicyDTO> findPoliciesByPremiumAmountGreaterThan(BigDecimal premiumAmount)
			throws InvalidPremiumAmountException {
		if (premiumAmount == null || premiumAmount.compareTo(BigDecimal.ZERO) < 0) {
			throw new InvalidPremiumAmountException("Premium amount must be a positive number.");
		}

		List<Policy> policies = policyRepository.findByPremiumAmountGreaterThan(premiumAmount);

		if (policies == null || policies.isEmpty()) {
			throw new InvalidPremiumAmountException(
					"No policies found with premium amount greater than: " + premiumAmount);
		}

		List<Policy> matchingPolicies = policies.stream()
				.filter(policy -> policy.getPremiumAmount().compareTo(premiumAmount) > 0).collect(Collectors.toList());

		if (matchingPolicies.isEmpty()) {
			throw new InvalidPremiumAmountException(
					"No policies found with premium amount greater than: " + premiumAmount);
		}

		return matchingPolicies.stream().map(this::convertToDTO).collect(Collectors.toList());
	}

	/**
	 * Finds policies with a premium amount lesser than the specified amount and
	 * returns a list of PolicyDTOs.
	 */
	public List<PolicyDTO> findPoliciesByPremiumAmountLessThan(BigDecimal premiumAmount)
			throws InvalidPremiumAmountException {
		if (premiumAmount == null || premiumAmount.compareTo(BigDecimal.ZERO) < 0) {
			throw new InvalidPremiumAmountException("Premium amount must be a positive number.");
		}

		List<Policy> policies = policyRepository.findByPremiumAmountLessThan(premiumAmount);

		if (policies == null || policies.isEmpty()) {
			throw new InvalidPremiumAmountException(
					"No policies found with premium amount less than: " + premiumAmount);
		}

		List<Policy> matchingPolicies = policies.stream()
				.filter(policy -> policy.getPremiumAmount().compareTo(premiumAmount) < 0).collect(Collectors.toList());

		if (matchingPolicies.isEmpty()) {
			throw new InvalidPremiumAmountException(
					"No policies found with premium amount less than: " + premiumAmount);
		}

		return matchingPolicies.stream().map(this::convertToDTO).collect(Collectors.toList());
	}

	/**
	 * Finds policies with a validity period greater than the specified validity
	 * period and returns a list of PolicyDTOs.
	 */
	public List<PolicyDTO> findPoliciesByValidityPeriodGreaterThan(int validityPeriod)
			throws InvalidValidityPeriodException {
		if (validityPeriod <= 0) {
			throw new InvalidValidityPeriodException("Validity period must be a positive number.");
		}

		List<Policy> policies = policyRepository.findByValidityPeriodGreaterThan(validityPeriod);

		if (policies == null || policies.isEmpty()) {
			throw new InvalidValidityPeriodException(
					"No policies found with validity period greater than: " + validityPeriod);
		}

		List<Policy> matchingPolicies = policies.stream().filter(policy -> policy.getValidityPeriod() > validityPeriod)
				.collect(Collectors.toList());

		if (matchingPolicies.isEmpty()) {
			throw new InvalidValidityPeriodException(
					"No policies found with validity period greater than: " + validityPeriod);
		}

		return matchingPolicies.stream().map(this::convertToDTO).collect(Collectors.toList());
	}

	/**
	 * Finds policies with a validity period lesser than the specified validity
	 * period and returns a list of PolicyDTOs.
	 */
	public List<PolicyDTO> findPoliciesByValidityPeriodLessThan(int validityPeriod)
			throws InvalidValidityPeriodException {
		if (validityPeriod <= 0) {
			throw new InvalidValidityPeriodException("Validity period must be a positive number.");
		}

		List<Policy> policies = policyRepository.findByValidityPeriodLessThan(validityPeriod);

		if (policies == null || policies.isEmpty()) {
			throw new InvalidValidityPeriodException("Nofound with validity period less than: " + validityPeriod);
		}

		List<Policy> matchingPolicies = policies.stream().filter(policy -> policy.getValidityPeriod() < validityPeriod)
				.collect(Collectors.toList());

		if (matchingPolicies.isEmpty()) {
			throw new InvalidValidityPeriodException(
					"No policies found with validity period less than: " + validityPeriod);
		}

		return matchingPolicies.stream().map(this::convertToDTO).collect(Collectors.toList());
	}

	public List<PolicyDTO> getPoliciesByNameRegexStartingWith(String prefix) {
		List<Policy> matchingPolicies = policyRepository.findByNameStartingWith(prefix);

		if (matchingPolicies == null || matchingPolicies.isEmpty()) {
			throw new PolicyNotFoundException("No policies found with name starting with: " + prefix);
		}

		return matchingPolicies.stream().map(this::convertToDTO).collect(Collectors.toList());
	}

// public List<CustomerPolicyDTO> findByCustomerId(String customerId) throws PolicyNotFoundException {
// log.info("Retrieving Policy by customer ID: {}", customerId);
// List<Policy> policies = customerPolicyRepository.findByCustomerId(customerId.toString());
// if (policies.isEmpty()) {
// log.warn("No Policy found for customer ID: {}", customerId);
// throw new PolicyNotFoundException("No Policy found for customer ID: " + customerId);
// }
// log.info("Retrieved {} claims for customer ID: {}", policies.size(), customerId);
// return policies.stream().map(this::convertToCustomerPolicyDTO).collect(Collectors.toList());
// }
	public List<CustomerPolicyDTO> findByCustomerId(String customerId) throws PolicyNotFoundException {
		log.info("Retrieving Customer Policies by customer ID: {}", customerId);
		List<CustomerPolicy> customerPolicies = customerPolicyRepository.findByCustomerId(customerId);
		if (customerPolicies.isEmpty()) {
			log.warn("No Customer Policy found for customer ID: {}", customerId);
			throw new PolicyNotFoundException("No Customer Policy found for customer ID: " + customerId);
		}
		log.info("Retrieved {} customer policies for customer ID: {}", customerPolicies.size(), customerId);
		return customerPolicies.stream().map(this::convertToCustomerPolicyDTO).collect(Collectors.toList());
	}

	public List<CustomerPolicyDTO> findByAgentId(String agentId) throws PolicyNotFoundException {
		log.info("Retrieving Agent Policies by agent ID: {}", agentId);
		List<CustomerPolicy> customerPolicies = customerPolicyRepository.findByAgentId(agentId);
		if (customerPolicies.isEmpty()) {
			log.warn("No Agent Policy found for agent ID: {}", agentId);
			throw new PolicyNotFoundException("No agent Policy found for agent ID: " + agentId);
		}
		log.info("Retrieved {} agent policies for agent ID: {}", customerPolicies.size(), agentId);
		return customerPolicies.stream().map(this::convertToCustomerPolicyDTO).collect(Collectors.toList());
	}
	
	public List<PolicyDTO> getFilteredPolicies(String nameStartsWith, String premium, String validity) {
		log.info("Fetching and filtering policies - nameStartsWith: {}, premium: {}, validity: {}", nameStartsWith, premium, validity);
		List<Policy> allPolicies = policyRepository.findAll();
		List<Policy> filteredPolicies = new ArrayList<>();
 
		for (Policy policy : allPolicies) {
			boolean matchesName = true;
			boolean matchesPremium = true;
			boolean matchesValidity = true;
 
			if (nameStartsWith != null && !nameStartsWith.isEmpty()) {
				if (policy.getName() == null || !policy.getName().toLowerCase().startsWith(nameStartsWith.toLowerCase())) {
					matchesName = false;
				}
			}
 
			if (premium != null && !premium.isEmpty()) {
				try {
					BigDecimal premiumValue = new BigDecimal(premium.replaceAll("[^\\d.]", ""));
					if (premium.startsWith("greaterThan")) {
						if (policy.getPremiumAmount() == null || policy.getPremiumAmount().compareTo(premiumValue) <= 0) {
							matchesPremium = false;
						}
					} else if (premium.startsWith("lessThan")) {
						if (policy.getPremiumAmount() == null || policy.getPremiumAmount().compareTo(premiumValue) >= 0) {
							matchesPremium = false;
						}
					}
				} catch (NumberFormatException e) {
					log.warn("Invalid premium format: {}", premium);
					// Consider how to handle invalid input - maybe skip this filter for this policy
				}
			}
 
			if (validity != null && !validity.isEmpty()) {
				try {
					int validityValue = Integer.parseInt(validity.replaceAll("[^\\d]", ""));
					if (validity.startsWith("greaterThan")) {
						if (policy.getValidityPeriod() <= validityValue) {
							matchesValidity = false;
						}
					} else if (validity.startsWith("lessThan")) {
						if (policy.getValidityPeriod() >= validityValue) {
							matchesValidity = false;
						}
					}
				} catch (NumberFormatException e) {
					log.warn("Invalid validity format: {}", validity);
					// Consider how to handle invalid input - maybe skip this filter for this policy
				}
			}
 
			if (matchesName && matchesPremium && matchesValidity) {
				filteredPolicies.add(policy);
			}
		}
 
		if ((nameStartsWith != null && !nameStartsWith.isEmpty()) ||
				(premium != null && !premium.isEmpty()) ||
				(validity != null && !validity.isEmpty())) {
			if (filteredPolicies.isEmpty()) {
				log.info("No policies found matching the filter criteria.");
				return new ArrayList<>(); // Return an empty list
			}
		}
 
		return filteredPolicies.stream().map(this::convertToDTO).collect(Collectors.toList());
	}
 

}
