package com.example.policy.exception;

public class InvalidPolicyNameException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidPolicyNameException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
