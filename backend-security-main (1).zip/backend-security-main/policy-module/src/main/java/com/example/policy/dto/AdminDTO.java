package com.example.policy.dto;
 
import java.util.UUID;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;
 
import lombok.Data;
 
@Data
@Component
public class AdminDTO {
 
    private String adminId;
    
    private String name;
 
    private String email;
 
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String password;
}