package com.example.policy.dto;

import java.time.LocalDateTime;
import java.util.UUID;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CustomerPolicyDTO {
    private String customerPolicyId;
    @NotBlank(message = "Customer ID cannot be blank")
    private UUID customerId;

    @NotBlank(message = "Policy ID cannot be blank")
    private UUID policyId;
    @NotBlank(message = "Agent ID cannot be blank")
    private UUID agentId;
    @NotNull(message = "Purchase date cannot be null")
    private LocalDateTime purchaseDate;
}