package com.example.policy.security;

import org.apache.catalina.filters.CorsFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.authorization.AuthorityAuthorizationManager;
import org.springframework.security.authorization.AuthorizationManagers;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Autowired
    private JwtFilter jwtFilter;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        return http.cors(cors -> cors.configurationSource(corsConfigurationSource()))
        		.csrf(customizer -> customizer.disable())
                .authorizeHttpRequests(request -> request
                		.requestMatchers("/api/v1/policies/{policyId}").permitAll()
                		.requestMatchers(
                        		 "/api/v1/policies/add",
                        		 "/api/v1/policies/update/{policyId}").hasAuthority("ADMIN")
                        
                        .requestMatchers("/api/v1/policies/purchase","/api/v1/policies/customer/{customerId}").hasAuthority("CUSTOMER")
                        .requestMatchers("/api/v1/policies/agent/{agentId}").hasAuthority("AGENT")
                        // Admin specific endpoints
                        .requestMatchers(
                                "/api/v1/policies",
                                "/api/v1/policies/name/{name}",
                                "/api/v1/policies/greaterPremium/{premiumAmount}",
                                "/api/v1/policies/lesserPremium/{premiumAmount}",
                                "/api/v1/policies/greaterValidity/{validityPeriod}",
                                "/api/v1/policies/lesserValidity/{validityPeriod}",                                
                                "/api/v1/policies/customerPolicy/{customerPolicyId}",
                                "/api/v1/policies/startsWith/{prefix}"
                        ).hasAnyAuthority("ADMIN", "CUSTOMER","AGENT") 
                        .anyRequest().authenticated())
                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)
                .build();
    }
    
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        
        // Explicitly specify the allowed origin
        configuration.setAllowedOrigins(java.util.List.of("http://localhost:3000"));

        // Allow specific headers required by the frontend
        configuration.setAllowedHeaders(java.util.List.of("Authorization", "Content-Type", "Accept"));

        // Allow the required HTTP methods
        configuration.setAllowedMethods(java.util.List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));

        // Enable credentials (for cookies or tokens)
        configuration.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration); // Apply globally to all endpoints
        return source;
    }


    @Bean
    AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(12);
    }

}