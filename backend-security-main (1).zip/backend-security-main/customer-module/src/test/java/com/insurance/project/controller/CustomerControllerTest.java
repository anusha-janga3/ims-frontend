package com.insurance.project.controller;
 
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
 
import java.util.Arrays;
import java.util.List;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
 
import com.fasterxml.jackson.databind.ObjectMapper;
import com.insurance.project.dto.CustomerDTO;
import com.insurance.project.exception.CustomerNotFoundException;
import com.insurance.project.model.Customer;
import com.insurance.project.service.CustomerService;
 
public class CustomerControllerTest {
 
    private MockMvc mockMvc;
 
    @Mock
    private CustomerService customerService;
 
    @InjectMocks
    private CustomerController customerController;
 
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(customerController).build();
    }
 
    @Test
    public void testAddCustomer() throws Exception {
        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setName("John Doe");
        customerDTO.setAddress("123 Main St");
        customerDTO.setEmail("john.doe@example.com");
        customerDTO.setPhone("1234567890");
 
        when(customerService.addCustomer(any(CustomerDTO.class))).thenReturn(customerDTO);
 
        mockMvc.perform(post("/api/v1/customers/addCustomer")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(customerDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Customer added successfully"))
                .andExpect(jsonPath("$.data.name").value("John Doe"));
    }
 
    @Test
    public void testFindAll() throws Exception {
        CustomerDTO customer1 = new CustomerDTO();
        customer1.setName("John Doe");
        customer1.setAddress("123 Main St");
        customer1.setEmail("john.doe@example.com");
        customer1.setPhone("1234567890");
 
        CustomerDTO customer2 = new CustomerDTO();
        customer2.setName("Jane Doe");
        customer2.setAddress("456 Elm St");
        customer2.setEmail("jane.doe@example.com");
        customer2.setPhone("0987654321");
 
        List<CustomerDTO> customers = Arrays.asList(customer1, customer2);
 
        when(customerService.findAll()).thenReturn(customers);
 
        mockMvc.perform(get("/api/v1/customers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Fetched all customers"))
                .andExpect(jsonPath("$.data[0].name").value("John Doe"))
                .andExpect(jsonPath("$.data[1].name").value("Jane Doe"));
    }
 
    @Test
    public void testFindCustomerById() throws Exception {
        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setName("John Doe");
        customerDTO.setAddress("123 Main St");
        customerDTO.setEmail("john.doe@example.com");
        customerDTO.setPhone("1234567890");
 
        when(customerService.findCustomerById("1")).thenReturn(customerDTO);
 
        mockMvc.perform(get("/api/v1/customers/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Customer found"))
                .andExpect(jsonPath("$.data.name").value("John Doe"));
    }
 
    @Test
    public void testFindCustomerByIdNotFound() throws Exception {
        when(customerService.findCustomerById("1")).thenThrow(new CustomerNotFoundException("Customer not found with id: 1"));
 
        mockMvc.perform(get("/api/v1/customers/1"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Customer not found with id: 1"));
    }
 
    @Test
    public void testUpdateCustomer() throws Exception {
        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setName("John Doe");
        customerDTO.setAddress("123 Main St");
        customerDTO.setEmail("john.doe@example.com");
        customerDTO.setPhone("1234567890");
 
        when(customerService.findCustomerEntityById("1")).thenReturn(new Customer());
        when(customerService.updateCustomer(any(CustomerDTO.class), any(Customer.class))).thenReturn(customerDTO);
 
        mockMvc.perform(put("/api/v1/customers/update/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(customerDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Customer updated successfully"))
                .andExpect(jsonPath("$.data.name").value("John Doe"));
    }
 
    @Test
    public void testDeleteCustomer() throws Exception {
        doNothing().when(customerService).deleteCustomer("1");
 
        mockMvc.perform(delete("/api/v1/customers/delete/1"))
                .andExpect(status().isNoContent())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Customer deleted successfully"));
    }
 
    @Test
    public void testDeleteCustomerNotFound() throws Exception {
        doThrow(new CustomerNotFoundException("Customer not found with id: 1")).when(customerService).deleteCustomer("1");
 
        mockMvc.perform(delete("/api/v1/customers/delete/1"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Customer not found with id: 1"));
    }
}
 