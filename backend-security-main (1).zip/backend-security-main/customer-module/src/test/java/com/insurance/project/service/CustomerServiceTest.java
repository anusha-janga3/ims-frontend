package com.insurance.project.service;
 
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
 
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
 
import com.insurance.project.dto.CustomerDTO;
import com.insurance.project.exception.CustomerNotFoundException;
import com.insurance.project.model.Customer;
import com.insurance.project.repository.CustomerRepository;
 
public class CustomerServiceTest {
 
    @Mock
    private CustomerRepository customerRepository;
 
    @InjectMocks
    private CustomerService customerService;
 
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }
 
    @Test
    public void testAddCustomer() {
        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setName("John Doe");
 
        Customer customer = new Customer();
        customer.setName("John Doe");
 
        when(customerRepository.save(any(Customer.class))).thenReturn(customer);
 
        CustomerDTO result = customerService.addCustomer(customerDTO);
 
        assertNotNull(result);
        assertEquals("John Doe", result.getName());
    }
 
    @Test
    public void testUpdateCustomer() {
        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setName("John Doe");
 
        Customer customer = new Customer();
        customer.setName("Jane Doe");
 
        when(customerRepository.save(any(Customer.class))).thenReturn(customer);
 
        CustomerDTO result = customerService.updateCustomer(customerDTO, customer);
 
        assertNotNull(result);
        assertEquals("John Doe", result.getName());
    }
 
    @Test
    public void testFindAll() {
        Customer customer1 = new Customer();
        customer1.setName("John Doe");
        Customer customer2 = new Customer();
        customer2.setName("Jane Doe");
 
        List<Customer> customers = Arrays.asList(customer1, customer2);
 
        when(customerRepository.findAllCustomers()).thenReturn(customers);
 
        List<CustomerDTO> result = customerService.findAll();
 
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("John Doe", result.get(0).getName());
        assertEquals("Jane Doe", result.get(1).getName());
    }
 
    @Test
    public void testFindCustomerById() throws CustomerNotFoundException {
        Customer customer = new Customer();
        customer.setName("John Doe");
 
        when(customerRepository.findById("1")).thenReturn(Optional.of(customer));
 
        CustomerDTO result = customerService.findCustomerById("1");
 
        assertNotNull(result);
        assertEquals("John Doe", result.getName());
    }
 
    @Test
    public void testFindCustomerByIdNotFound() {
        when(customerRepository.findById("1")).thenReturn(Optional.empty());
 
        assertThrows(CustomerNotFoundException.class, () -> {
            customerService.findCustomerById("1");
        });
    }
 
    @Test
    public void testDeleteCustomer() {
        when(customerRepository.existsById("1")).thenReturn(true);
        doNothing().when(customerRepository).deleteById("1");
 
        assertDoesNotThrow(() -> {
            customerService.deleteCustomer("1");
        });
    }
 
    @Test
    public void testDeleteCustomerNotFound() {
        when(customerRepository.existsById("1")).thenReturn(false);
 
        assertThrows(CustomerNotFoundException.class, () -> {
            customerService.deleteCustomer("1");
        });
    }
}
 