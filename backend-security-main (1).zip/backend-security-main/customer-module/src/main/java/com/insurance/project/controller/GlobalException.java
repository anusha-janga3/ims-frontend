package com.insurance.project.controller;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.insurance.project.util.ResultResponse;

/**
 * Global exception handler for handling validation and runtime exceptions.
 */
@ControllerAdvice
public class GlobalException {

    /**
     * Handles validation errors.
     * 
     * @param e the MethodArgumentNotValidException.
     * @return a response entity with validation error details.
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ResultResponse<Map<String, String>>> handleValidationError(MethodArgumentNotValidException e) {
        Map<String, String> validationError = new HashMap<>();
        for (FieldError error : e.getBindingResult().getFieldErrors()) {
            validationError.put(error.getField(), error.getDefaultMessage());
        }

        ResultResponse<Map<String, String>> result = ResultResponse.<Map<String, String>>builder()
                .success(false)
                .message("Validation error")
                .data(validationError)
                .timestamp(LocalDateTime.now())
                .build();
        return ResponseEntity.badRequest().body(result);
    }

    /**
     * Handles runtime exceptions.
     * 
     * @param ex the RuntimeException.
     * @return a response entity with the error message.
     */
    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<ResultResponse<String>> handleRuntimeExceptions(RuntimeException ex) {
        ResultResponse<String> result = ResultResponse.<String>builder()
                .success(false)
                .message(ex.getMessage())
                .timestamp(LocalDateTime.now())
                .build();
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(result);
    }
}