package com.insurance.project.exception;

public class FailedAssignmentException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;
 
	public FailedAssignmentException(String message) {
		super(message);
	}
}
