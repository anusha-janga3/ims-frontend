package com.insurance.project.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
import lombok.extern.slf4j.Slf4j;

/**
 * Aspect for logging execution of service and controller methods.
 */
@Aspect
@Component
@Slf4j
public class LoggingAspect {

    @Pointcut("execution(* com.insurance.project.model.service.*.*(..)) || execution(* com.insurance.project.model.controller.*.*(..))")
    public void applicationPackagePointcut() {
        // Pointcut for service and controller packages
    }

    @Before("applicationPackagePointcut()")
    public void logBefore() {
        log.info("Entering method");
    }

    @AfterReturning(pointcut = "applicationPackagePointcut()", returning = "result")
    public void logAfterReturning(Object result) {
        log.info("Method returned: " + result);
    }

    @AfterThrowing(pointcut = "applicationPackagePointcut()", throwing = "error")
    public void logAfterThrowing(Throwable error) {
        log.error("Method threw exception: " + error);
    }
}