package com.insurance.project.model;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Entity class representing a Customer.
 */
@Component
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Customer")
public class Customer {

    /**
     * Unique identifier for the customer.
     */
    @Id
    @Column(name = "customerId")
    private String customerId;

    /**
     * Address of the customer.
     */
    @Column(name = "address", columnDefinition = "TEXT")
    private String address;

    /**
     * Name of the customer.
     */
    @Column(name = "name", nullable = false)
    private String name;

    /**
     * Email of the customer.
     */
    @Column(name = "email", unique = true, nullable = false)
    private String email;

    /**
     * Phone number of the customer.
     */
    @Column(name = "phone", unique = true, nullable = false)
    private String phone;


    /**
     * Timestamp when the customer was created.
     */
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    /**
     * Timestamp when the customer was last updated.
     */
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    /**
     * Generates a UUID and sets the created and updated timestamps before persisting.
     */
    @PrePersist
    public void generateUuidAndCreatedAt() {
    	this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    /**
     * Updates the updated timestamp before updating.
     */
    @PreUpdate
    public void updateUpdatedAt() {
        this.updatedAt = LocalDateTime.now();
    }
}