package com.insurance.project.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.insurance.project.model.Customer;

/**
 * Repository interface for managing Customer entities.
 */
@Repository
public interface CustomerRepository extends JpaRepository<Customer, String> {

    /**
     * Retrieves all customers.
     *
     * @return a list of all customers
     */
    @Query("SELECT c FROM Customer c")
    List<Customer> findAllCustomers();

    /**
     * Finds a customer by ID.
     *
     * @param id the customer ID
     * @return the customer with the specified ID
     */
    @Query("SELECT c FROM Customer c WHERE c.id = :id")
    Customer findCustomerById(String id);

    /**
     * Finds customers by name.
     *
     * @param name the customer name
     * @return a list of customers with the specified name
     */
    @Query("SELECT c FROM Customer c WHERE c.name = :name")
    List<Customer> findByName(String name);
}