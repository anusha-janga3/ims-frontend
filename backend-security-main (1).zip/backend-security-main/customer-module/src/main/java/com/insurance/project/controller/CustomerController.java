package com.insurance.project.controller;
 
import java.time.LocalDateTime;

import java.util.List;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;
 
import com.insurance.project.dto.CustomerDTO;

import com.insurance.project.exception.CustomerNotFoundException;

//import com.insurance.project.model.Agent;

import com.insurance.project.model.Customer;

//import com.insurance.project.repository.AgentRepository;

import com.insurance.project.service.CustomerService;

import com.insurance.project.util.ResultResponse;
 
import lombok.extern.slf4j.Slf4j;
 
/**

* REST controller for managing customers.

*/

@RestController

@RequestMapping("/api/v1/customers")

@Slf4j

public class CustomerController {
 
    @Autowired

    private CustomerService customerService;
 
    /**

     * Adds a new customer.

     *

     * @param customerDTO the customer data transfer object

     * @return the response entity containing the result response with the added customer

     */

    @PostMapping("/addCustomer")

    public ResponseEntity<ResultResponse<CustomerDTO>> addCustomer(@Valid @RequestBody CustomerDTO customerDTO) {

        log.debug("inside the add customer");

        try {

            CustomerDTO addedCustomer = customerService.addCustomer(customerDTO);

            ResultResponse<CustomerDTO> response = ResultResponse.<CustomerDTO>builder()

                    .success(true)

                    .message("Customer added successfully")

                    .data(addedCustomer)

                    .timestamp(LocalDateTime.now())

                    .build();

            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (Exception e) {

            ResultResponse<CustomerDTO> response = ResultResponse.<CustomerDTO>builder()

                    .success(false)

                    .message(e.getMessage())

                    .timestamp(LocalDateTime.now())

                    .build();

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);

        }

    }
 
    /**

     * Retrieves all customers.

     *

     * @return the response entity containing the result response with the list of customers

     */

    @GetMapping

    public ResponseEntity<ResultResponse<List<CustomerDTO>>> findAll() {

        List<CustomerDTO> customers = customerService.findAll();

        ResultResponse<List<CustomerDTO>> response = ResultResponse.<List<CustomerDTO>>builder()

                .success(true)

                .message("Fetched all customers")

                .data(customers)

                .timestamp(LocalDateTime.now())

                .build();

        return new ResponseEntity<>(response, HttpStatus.OK);

    }
 
    /**

     * Finds a customer by ID.

     *

     * @param id the customer ID

     * @return the response entity containing the result response with the customer

     */

    @GetMapping("/{customerId}")

    public ResponseEntity<ResultResponse<CustomerDTO>> findCustomerById(@PathVariable String customerId) {

        log.debug("inside the find customer by id");

        try {

            CustomerDTO customer = customerService.findCustomerById(customerId);

            ResultResponse<CustomerDTO> response = ResultResponse.<CustomerDTO>builder()

                    .success(true)

                    .message("Customer found")

                    .data(customer)

                    .timestamp(LocalDateTime.now())

                    .build();

            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (CustomerNotFoundException ex) {

            ResultResponse<CustomerDTO> response = ResultResponse.<CustomerDTO>builder()

                    .success(false)

                    .message(ex.getMessage())

                    .timestamp(LocalDateTime.now())

                    .build();

            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);

        }

    }
 
    /**

     * Finds customers by name.

     *

     * @param name the customer name

     * @return the response entity containing the result response with the list of customers

     */

    @GetMapping("/name/{name}")

    public ResponseEntity<ResultResponse<List<CustomerDTO>>> findCustomersByName(@PathVariable String name) {

        log.debug("inside the find customers by name");

        List<CustomerDTO> customers = customerService.findCustomersByName(name);

        ResultResponse<List<CustomerDTO>> response = ResultResponse.<List<CustomerDTO>>builder()

                .success(true)

                .message("Customers found")

                .data(customers)

                .timestamp(LocalDateTime.now())

                .build();

        return new ResponseEntity<>(response, HttpStatus.OK);

    }
 
    /**

     * Updates an existing customer.

     *

     * @param id the customer ID

     * @param customerDTO the customer data transfer object

     * @return the response entity containing the result response with the updated customer

     */

    @PutMapping("/update/{id}")
    public ResponseEntity<ResultResponse<CustomerDTO>> updateCustomer(@PathVariable String id, @Valid @RequestBody CustomerDTO customerDTO) {
        log.debug("inside the update customer");
        try {
            Customer existingCustomer = customerService.findCustomerEntityById(id);
 
            // Check if the provided email is different from the existing email
            if (!customerDTO.getEmail().equals(existingCustomer.getEmail())) {
                ResultResponse<CustomerDTO> response = ResultResponse.<CustomerDTO>builder()
                        .success(false)
                        .message("Email cannot be updated.")
                        .timestamp(LocalDateTime.now())
                        .build();
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }
 
            CustomerDTO updatedCustomer = customerService.updateCustomer(customerDTO, existingCustomer);
 
            ResultResponse<CustomerDTO> response = ResultResponse.<CustomerDTO>builder()
                    .success(true)
                    .message("Customer updated successfully")
                    .data(updatedCustomer)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (CustomerNotFoundException ex) {
            ResultResponse<CustomerDTO> response = ResultResponse.<CustomerDTO>builder()
                    .success(false)
                    .message(ex.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            ResultResponse<CustomerDTO> response = ResultResponse.<CustomerDTO>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
 
 
    /**

     * Deletes a customer by ID.

     *

     * @param id the customer ID

     * @return the response entity containing the result response

     */

    @DeleteMapping("/delete/{id}")

    public ResponseEntity<ResultResponse<Void>> deleteCustomer(@PathVariable String id) {

        log.debug("inside the delete customer");

        try {

            customerService.deleteCustomer(id);

            ResultResponse<Void> response = ResultResponse.<Void>builder()

                    .success(true)

                    .message("Customer deleted successfully")

                    .timestamp(LocalDateTime.now())

                    .build();

            return new ResponseEntity<>(response, HttpStatus.NO_CONTENT);

        } catch (CustomerNotFoundException ex) {

            ResultResponse<Void> response = ResultResponse.<Void>builder()

                    .success(false)

                    .message(ex.getMessage())

                    .timestamp(LocalDateTime.now())

                    .build();

            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);

        }

    }

}
 