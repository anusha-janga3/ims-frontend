package com.insurance.project.util;

import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;

/**
 * A utility class for structuring API responses.
 *
 * @param <T> the type of the response data
 */
@Data
@Builder
public class ResultResponse<T> {
    private boolean success;
    private String message;
    private T data;
    private LocalDateTime timestamp;
}