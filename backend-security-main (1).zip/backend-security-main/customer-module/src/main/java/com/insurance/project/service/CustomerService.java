package com.insurance.project.service;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.insurance.project.client.UserServiceClient;
import com.insurance.project.dto.CustomerDTO;
import com.insurance.project.exception.CustomerNotFoundException;
 
import com.insurance.project.model.Customer;
import com.insurance.project.repository.CustomerRepository;
 
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
//import java.util.stream.Collectors;
 
/**
* Service class for managing customers.
*/
@Slf4j
@Service
public class CustomerService {
 
    @Autowired
    private CustomerRepository customerRepository;
    
    @Autowired
    private UserServiceClient userServiceClient;
 
//    @Autowired
//    private AgentRepository agentRepository;
 
    /**
     * Adds a new customer.
     *
     * @param customerDTO the customer data transfer object
     * @return the added customer data transfer object
     * @throws Exception if an error occurs while adding the customer
     */
    public CustomerDTO addCustomer(CustomerDTO customerDTO){
    	log.info("into customer");
        Customer customer = new Customer();
        customer.setCustomerId(customerDTO.getCustomerId());
        customer.setName(customerDTO.getName());
        customer.setAddress(customerDTO.getAddress());
        customer.setEmail(customerDTO.getEmail());
        customer.setPhone(customerDTO.getPhone());
        Customer savedCustomer = customerRepository.save(customer);
        return convertToDTO(savedCustomer);
    }
 
    /**
     * Updates an existing customer.
     *
     * @param customerDTO the customer data transfer object
     * @param customer the existing customer entity
     * @return the updated customer data transfer object
     * @throws Exception if an error occurs while updating the customer
     */
    public CustomerDTO updateCustomer(CustomerDTO customerDTO, Customer customer) {
        if (customerDTO.getName() != null) {
            customer.setName(customerDTO.getName());
        }
        if (customerDTO.getAddress() != null) {
            customer.setAddress(customerDTO.getAddress());
        }
        // We've already checked in the controller if the email is different.
        // Here, we just use the existing email from the entity.
        customer.setEmail(customer.getEmail());
        if (customerDTO.getPhone() != null) {
            customer.setPhone(customerDTO.getPhone());
        }
 
        // Ensure the ID is maintained
        customer.setCustomerId(customer.getCustomerId()); // Ensure the id is set correctly.
 
        Customer updatedCustomer = customerRepository.save(customer);
        return convertToDTO(updatedCustomer);
    }
 
    /**
     * Retrieves all customers.
     *
     * @return a list of customer data transfer objects
     */
    public List<CustomerDTO> findAll() {
        log.info("Fetching all customers");
        List<Customer> list= customerRepository.findAllCustomers();
        List<CustomerDTO> dto=new ArrayList<>();
        for(Customer c: list) {
            dto.add(convertToDTO(c));
        }
        return dto;
    }
 
    /**
     * Finds a customer by ID.
     *
     * @param id the customer ID
     * @return the customer data transfer object
     * @throws CustomerNotFoundException if the customer is not found
     */
    public CustomerDTO findCustomerById(String id) throws CustomerNotFoundException {
        Optional<Customer> customer = customerRepository.findById(id);
        if(customer.isPresent()) {
            Customer c=customer.get();
            return convertToDTO(c);
        }else {
            throw new CustomerNotFoundException("Customer not found with id: " + id);
        }
 
    }
 
    /**
     * Finds a customer entity by ID.
     *
     * @param id the customer ID
     * @return the customer entity
     * @throws CustomerNotFoundException if the customer is not found
     */
    public Customer findCustomerEntityById(String id) throws CustomerNotFoundException {
        Optional<Customer> customer = customerRepository.findById(id);
        if(customer.isPresent()) {
            Customer c=customer.get();
            return c;
        }else {
            throw new CustomerNotFoundException("Customer not found with id: " + id);
        }
    }
 
    /**
     * Finds customers by name.
     *
     * @param name the customer name
     * @return a list of customer data transfer objects
     */
    public List<CustomerDTO> findCustomersByName(String name) {
        log.info("Searching for customers with name: {}", name);
        List<Customer> customers = customerRepository.findByName(name);
        log.info("customers: "+customers);
        List<CustomerDTO> dto = new ArrayList<>();
        for(Customer c : customers) {
            dto.add(convertToDTO(c));
        }
        return dto;
    }
 
    /**
     * Deletes a customer by ID.
     *
     * @param id the customer ID
     * @throws CustomerNotFoundException if the customer is not found
     */
    @Transactional
    public void deleteCustomer(String id) {
        // Check if the customer exists
        if (!customerRepository.existsById(id)) {
            throw new CustomerNotFoundException("Customer not found with id: " + id);
        }
 
        // Delete the customer
        customerRepository.deleteById(id);
 
        // Call the User Service to delete the corresponding user
        try {
            userServiceClient.deleteUser(id);
            System.out.println("Successfully triggered user deletion for id: " + id);
        } catch (Exception e) {
            System.err.println("Error while calling User Service to delete user for id: " + id + ": " + e.getMessage());
            // Decide how to handle this error. Options include:
            // 1. Logging the error and continuing (customer is deleted, user might remain).
            // 2. Implementing a compensating transaction or retry mechanism.
            // 3. Potentially rolling back the customer deletion if user deletion is critical (more complex with separate services).
        }
    }
 
    /**
     * Converts a customer entity to a customer data transfer object.
     *
     * @param customer the customer entity
     * @return the customer data transfer object
     */
    private CustomerDTO convertToDTO(Customer customer) {
        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setCustomerId(customer.getCustomerId());
        customerDTO.setName(customer.getName());
        customerDTO.setAddress(customer.getAddress());
        customerDTO.setEmail(customer.getEmail());
        customerDTO.setPhone(customer.getPhone());
        customerDTO.setCreatedAt(customer.getCreatedAt());
        customerDTO.setUpdatedAt(customer.getUpdatedAt());
        return customerDTO;
    }
    
    
    
}
 