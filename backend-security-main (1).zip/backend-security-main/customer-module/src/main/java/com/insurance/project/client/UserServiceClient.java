package com.insurance.project.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
 
@FeignClient(name = "auth-service") // Correctly targets your User Service
public interface UserServiceClient {
 
    @DeleteMapping("/api/v1/users/delete/{id}") // Calls the internal delete endpoint
    void deleteUser(@PathVariable("id") String id);
}
