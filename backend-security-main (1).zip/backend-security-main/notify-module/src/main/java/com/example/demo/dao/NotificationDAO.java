package com.example.demo.dao;
 
import com.example.demo.model.Notification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
 
import java.time.LocalDateTime;
import java.util.List;
 
@Repository
public interface NotificationDAO extends JpaRepository<Notification, String> {
 
    List<Notification> findByCustomerId(@Param("customerId") String customerId);
 
    @Query("SELECT n FROM Notification n WHERE n.timestamp > :timestamp")
    List<Notification> findNotificationsAfter(@Param("timestamp") LocalDateTime timestamp);
 
    List<Notification> findByTimestampAfter(LocalDateTime timestamp);
 
    List<Notification> findByClaimIdAndCustomerId(@Param("claimId") String claimId, @Param("customerId") String customerId);
 
    @Query("SELECT n FROM Notification n WHERE n.customerId = :customerId AND n.starred = true")
    List<Notification> findStarredNotificationsByCustomerId(@Param("customerId") String customerId);
 
    // you can add more queries based on your needs.
}
 