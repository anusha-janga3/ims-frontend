package com.example.demo.model;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class ResultResponse<T> {
    private T data;
    private String message;
    private boolean success;
    private LocalDateTime timestamp;
}