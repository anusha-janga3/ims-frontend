package com.example.demo.controller;
 
import com.example.demo.dto.Notificationdto;
import com.example.demo.exceptions.InvalidNotificationDataException;
import com.example.demo.exceptions.NotificationNotFoundException;
import com.example.demo.exceptions.NotificationServiceException;
import com.example.demo.service.NotificationService;
import jakarta.validation.Valid;
import com.example.demo.model.ResultResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
 
@RestController
@Slf4j
@RequestMapping("/api/v1/notification")
public class NotificationController {
 
    @Autowired
    private NotificationService notificationService;
 
    public ResponseEntity<ResultResponse<Notificationdto>> saveNotification(@Valid @RequestBody Notificationdto notificationDTO) {
        log.info("Received request to save notification: {}", notificationDTO);
        try {
            Notificationdto savedNotification = notificationService.saveNotification(notificationDTO);
            ResultResponse<Notificationdto> response = ResultResponse.<Notificationdto>builder()
                    .data(savedNotification)
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (InvalidNotificationDataException e) {
            log.error("Invalid notification data: {}", e.getMessage());
            return ResponseEntity.badRequest().body(ResultResponse.<Notificationdto>builder()
                    .message(e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (NotificationServiceException e) {
            log.error("Service error saving notification: {}", e.getMessage());
            return ResponseEntity.internalServerError().body(ResultResponse.<Notificationdto>builder()
                    .message("Error saving notification: " + e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Unexpected error saving notification: {}", e.getMessage());
            return ResponseEntity.internalServerError().body(ResultResponse.<Notificationdto>builder()
                    .message("Unexpected error: " + e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
 
    @GetMapping("/{notificationId}")
    public ResponseEntity<ResultResponse<Notificationdto>> getNotificationById(@PathVariable String notificationId) {
        log.info("Received request to get notification by id: {}", notificationId);
        try {
            Notificationdto notification = notificationService.getNotificationById(notificationId);
            ResultResponse<Notificationdto> response = ResultResponse.<Notificationdto>builder()
                    .data(notification)
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (NotificationNotFoundException e) {
            log.error("Notification not found: {}", e.getMessage());
            return ResponseEntity.notFound().build();
        } catch (NotificationServiceException e) {
            log.error("Service error getting notification: {}", e.getMessage());
            return ResponseEntity.internalServerError().body(ResultResponse.<Notificationdto>builder()
                    .message("Error getting notification: " + e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error getting notification: {}", e.getMessage());
            return ResponseEntity.internalServerError().body(ResultResponse.<Notificationdto>builder()
                    .message("Unexpected error: " + e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
 
    @GetMapping("/notifications")
    public ResponseEntity<ResultResponse<List<Notificationdto>>> getAllNotifications() {
        log.info("Received request to get all notifications");
        try {
            List<Notificationdto> notifications = notificationService.getAllNotifications();
            ResultResponse<List<Notificationdto>> response = ResultResponse.<List<Notificationdto>>builder()
                    .data(notifications)
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (NotificationServiceException e) {
            log.error("Service error getting all notifications: {}", e.getMessage());
            return ResponseEntity.internalServerError().body(ResultResponse.<List<Notificationdto>>builder()
                    .message("Error getting all notifications: " + e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error getting all notifications: {}", e.getMessage());
            return ResponseEntity.internalServerError().body(ResultResponse.<List<Notificationdto>>builder()
                    .message("Unexpected error: " + e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
 
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<ResultResponse<List<Notificationdto>>> getNotificationsByCustomerId(@PathVariable String customerId) {
        log.info("Received request to get notifications by customer id: {}", customerId);
        try {
            List<Notificationdto> notifications = notificationService.getNotificationsByCustomerId(customerId);
            ResultResponse<List<Notificationdto>> response = ResultResponse.<List<Notificationdto>>builder()
                    .data(notifications)
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (NotificationServiceException e) {
            log.error("Service error getting notifications by customer id: {}", e.getMessage());
            return ResponseEntity.internalServerError().body(ResultResponse.<List<Notificationdto>>builder()
                    .message("Error getting notifications by customer id: " + e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error getting notifications by customer id: {}", e.getMessage());
            return ResponseEntity.internalServerError().body(ResultResponse.<List<Notificationdto>>builder()
                    .message("Unexpected error: " + e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
 
    @GetMapping("/after/{timestamp}")
    public ResponseEntity<ResultResponse<List<Notificationdto>>> getNotificationsAfter(@PathVariable String timestamp) {
        log.info("Received request to get notifications after timestamp: {}", timestamp);
        try {
            LocalDateTime parsedTimestamp = LocalDateTime.parse(timestamp);
            List<Notificationdto> notifications = notificationService.getNotificationsAfter(parsedTimestamp);
            ResultResponse<List<Notificationdto>> response = ResultResponse.<List<Notificationdto>>builder()
                    .data(notifications)
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (java.time.format.DateTimeParseException e) {
            log.error("Invalid timestamp format: {}", timestamp, e);
            return ResponseEntity.badRequest().body(ResultResponse.<List<Notificationdto>>builder()
                    .message("Invalid timestamp format. Please use ISO 8601 format (e.g., 2024-10-27T10:00:00).")
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (NotificationServiceException e) {
            log.error("Service error getting notifications after timestamp: {}", e.getMessage());
            return ResponseEntity.internalServerError().body(ResultResponse.<List<Notificationdto>>builder()
                    .message("Error getting notifications after timestamp: " + e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error getting notifications after timestamp: {}", e.getMessage());
            return ResponseEntity.internalServerError().body(ResultResponse.<List<Notificationdto>>builder()
                    .message("Unexpected error: " + e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
 
    @PostMapping("/claim-status-notification")
    public ResponseEntity<ResultResponse<String>> sendClaimStatusNotification(
            @Valid @RequestBody Map<String, String> request) {
        log.info("Received request to send claim status notification for claimId: {}, customerId: {}, status: {}",
                request.get("claimId"), request.get("customerId"), request.get("status"));
        try {
            notificationService.sendClaimStatusNotification(
                    request.get("claimId"),
                    request.get("customerId"),
                    request.get("status"));
 
            ResultResponse<String> response = ResultResponse.<String>builder()
                    .data("Claim status notification sent successfully")
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (InvalidNotificationDataException e) {
            log.error("Invalid notification data for claim status notification: {}", e.getMessage());
            return ResponseEntity.badRequest().body(ResultResponse.<String>builder()
                    .message(e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (NotificationServiceException e) {
            log.error("Service error sending claim status notification: {}", e.getMessage());
            return ResponseEntity.internalServerError().body(ResultResponse.<String>builder()
                    .message("Error sending claim status notification: " + e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error sending claim status notification: {}", e.getMessage());
            return ResponseEntity.internalServerError().body(ResultResponse.<String>builder()
                    .message("Unexpected error: " + e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
 
    @PutMapping("/star/{id}")
    public ResponseEntity<ResultResponse<String>> starNotification(@PathVariable String id) {
        log.info("Received request to star notification with id: {}", id);
        try {
            notificationService.starNotification(id);
            ResultResponse<String> response = ResultResponse.<String>builder()
                    .data("Notification starred successfully")
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (NotificationNotFoundException e) {
            log.error("Notification not found: {}", e.getMessage());
            return ResponseEntity.notFound().build();
        } catch (NotificationServiceException e) {
            log.error("Service error starring notification: {}", e.getMessage());
            return ResponseEntity.internalServerError().body(ResultResponse.<String>builder()
                    .message("Error starring notification: " + e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error starring notification: {}", e.getMessage());
            return ResponseEntity.internalServerError().body(ResultResponse.<String>builder()
                    .message("Unexpected error: " + e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
 
    @DeleteMapping("/{id}")
    public ResponseEntity<ResultResponse<String>> deleteNotificationById(@PathVariable String id) {
        log.info("Received request to delete notification by id: {}", id);
        try {
            notificationService.deleteNotificationById(id);
            ResultResponse<String> response = ResultResponse.<String>builder()
                    .data("Notification deleted successfully")
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build();
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (NotificationNotFoundException e) {
            log.error("Notification not found: {}", e.getMessage());
            return ResponseEntity.notFound().build();
        } catch (NotificationServiceException e) {
            log.error("Service error deleting notification: {}", e.getMessage());
            return ResponseEntity.internalServerError().body(ResultResponse.<String>builder()
                    .message("Error deleting notification: " + e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error deleting notification: {}", e.getMessage());
            return ResponseEntity.internalServerError().body(ResultResponse.<String>builder()
                    .message("Unexpected error: " + e.getMessage())
                    .success(false)
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
}
 