package com.example.demo.exceptions;

public class InvalidNotificationDataException extends RuntimeException {
    
    private static final long serialVersionUID = 1L;

    public InvalidNotificationDataException(String message) {
        super(message);
    }
}
