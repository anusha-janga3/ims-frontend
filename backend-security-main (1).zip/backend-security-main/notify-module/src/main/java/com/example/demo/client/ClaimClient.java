package com.example.demo.client;

import com.example.demo.dto.ClaimDTO;
import com.example.demo.model.ResultResponse;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.UUID;
 
@FeignClient(name = "claim-service")
public interface ClaimClient {
 
    @GetMapping("/api/v1/claims/{claimId}")
    ResponseEntity<ResultResponse<ClaimDTO>> getClaimById(@PathVariable("claimId") UUID claimId);
    // Add other customer-related endpoints as needed
    
    @GetMapping("/api/v1/claim/updated-yesterday-to-today")
    ResponseEntity<ResultResponse<List<ClaimDTO>>> getClaimsUpdatedYesterdayToToday();
}
 

	
