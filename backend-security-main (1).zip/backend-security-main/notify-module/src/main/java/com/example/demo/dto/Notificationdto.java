package com.example.demo.dto;
 
import lombok.Data;
import lombok.Setter;
import java.time.LocalDateTime;
import java.util.UUID;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
 
@Data
@Setter
public class Notificationdto {
 
    private String notificationId;
 
    @NotNull(message = "CustomerId is required")
    private UUID customerId;
 
    @NotBlank(message = "Message is required")
    private String message;
 
    @NotNull(message = "ClaimId is required")
    private UUID claimId;
 
    private Boolean starred; // Change to Boolean (object wrapper)
 
    private LocalDateTime timestamp;
 
    private LocalDateTime createdAt;
 
    private LocalDateTime updatedAt;
}
 
 