package com.example.demo.exceptions;

public class NotificationNotFoundException extends RuntimeException {
    
    private static final long serialVersionUID = 1L;

    public NotificationNotFoundException(String message) {
        super(message);
    }
}
