package com.example.demo.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Data
@Validated
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimDTO {

	private String claimId;

	private BigDecimal claimAmount;

	private UUID policyId;

	private UUID customerId;

	private UUID adminId;

	private UUID agentId;

	private ClaimStatus status;

	private LocalDateTime updatedAt;

	private LocalDateTime createdAt;
}
