package com.example.demo.dto;
public enum ClaimStatus {
	Filed,
	UnderReview,
	Approved,
	Rejected;
}
 
 
 