package com.example.demo.model;
 
import java.time.LocalDateTime;
import java.util.UUID;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.Data;
 
@Entity
@Data
@Table(name = "Notification")
public class Notification {
 
    @Id
    @Column(name = "notificationId", nullable = false, updatable = false)
    private String notificationId;
 
    @Column(name = "message", columnDefinition = "TEXT", nullable = false)
    private String message;
 
    @Column(name = "timestamp", nullable = false)
    private LocalDateTime timestamp;
 
    @Column(name = "claimId", nullable = false)
    private String claimId;
 
    @Column(name = "customerId", nullable = false)
    private String customerId;
 
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
 
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
 
    @Column(name = "starred")
    private Boolean starred; // Change to Boolean (object wrapper)
 
    @PrePersist
    public void generateUuidAndCreatedAt() {
        this.notificationId = UUID.randomUUID().toString();
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        this.timestamp = LocalDateTime.now();
        if (this.starred == null) {
            this.starred = false; // Default to false if null on creation
        }
    }
 
    @PreUpdate
    public void updateUpdatedAt() {
        this.updatedAt = LocalDateTime.now();
    }
}
 
 