package com.example.demo.service;
 
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
 
import com.example.demo.client.ClaimClient;
import com.example.demo.dao.NotificationDAO;
import com.example.demo.dto.ClaimDTO;
import com.example.demo.dto.Notificationdto;
import com.example.demo.model.Notification;
import com.example.demo.model.ResultResponse;
 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.http.ResponseEntity;
 
@Service
public class NotificationService {
    private static final Logger logger = LoggerFactory.getLogger(NotificationService.class);
 
    @Autowired
    private NotificationDAO notificationDao;
 
    @Autowired
    private ClaimClient claimClient;
 
    public Notificationdto createNotification(String customerId, String message, String claimId) {
        Notificationdto notificationDTO = new Notificationdto();
        notificationDTO.setCustomerId(UUID.fromString(customerId));
        notificationDTO.setMessage(message);
        notificationDTO.setTimestamp(LocalDateTime.now());
        notificationDTO.setClaimId(UUID.fromString(claimId));
        return saveNotification(notificationDTO);
    }
 
    public Notificationdto saveNotification(Notificationdto notificationDTO) {
        try {
            Notification notification = convertToEntity(notificationDTO);
            Notification savedNotification = notificationDao.save(notification);
            return convertToDTO(savedNotification);
        } catch (Exception e) {
            logger.error("Error saving notification: {}", e.getMessage(), e);
            throw new RuntimeException("Error saving notification", e);
        }
    }
 
    public Notificationdto getNotificationById(String id) {
        Notification notification = notificationDao.findById(id)
                .orElseThrow(() -> new RuntimeException("Notification with ID: " + id + " not found"));
        return convertToDTO(notification);
    }
 
    public List<Notificationdto> getAllNotifications() {
        List<Notification> notifications = notificationDao.findAll();
        return notifications.stream().map(this::convertToDTO).collect(Collectors.toList());
    }
 
    public List<Notificationdto> getNotificationsByCustomerId(String customerId) {
        List<Notification> notifications = notificationDao.findByCustomerId(customerId);
        return notifications.stream().map(this::convertToDTO).collect(Collectors.toList());
    }
 
    public List<Notificationdto> getNotificationsAfter(LocalDateTime timestamp) {
        List<Notification> notifications = notificationDao.findNotificationsAfter(timestamp);
        return notifications.stream().map(this::convertToDTO).collect(Collectors.toList());
    }
 
    public void deleteNotificationById(String id) {
        if (notificationDao.existsById(id)) {
            notificationDao.deleteById(id);
        } else {
            throw new RuntimeException("Notification with ID: " + id + " not found");
        }
    }
 
    public void starNotification(String id) {
        Notification notification = notificationDao.findById(id)
                .orElseThrow(() -> new RuntimeException("Notification with ID: " + id + " not found"));
 
        Boolean currentStarred = notification.getStarred();
        notification.setStarred(currentStarred == null ? true : !currentStarred);
 
        notificationDao.save(notification);
    }
 
    public void sendClaimStatusNotification(String claimId, String customerId, String status) {
        String message = "Your claim with ID " + claimId + " has been " + status.toLowerCase() + ".";
 
        try {
            ResponseEntity<ResultResponse<ClaimDTO>> claimResponse = claimClient.getClaimById(UUID.fromString(claimId));
            if (claimResponse.getStatusCode().is2xxSuccessful() && claimResponse.getBody() != null) {
                ClaimDTO claimDTO = claimResponse.getBody().getData();
                message = "Your claim with ID " + claimId + " has been " + status.toLowerCase() + ". Claim Amount: " + claimDTO.getClaimAmount();
            } else {
                logger.warn("Failed to retrieve claim details from claim-service for claim ID: {}", claimId);
            }
        } catch (Exception e) {
            logger.error("Error fetching claim details from claim-service for claim ID: {}", claimId, e);
        }
 
        Notificationdto notificationDTO = new Notificationdto();
        notificationDTO.setCustomerId(UUID.fromString(customerId));
        notificationDTO.setMessage(message);
        notificationDTO.setTimestamp(LocalDateTime.now());
        notificationDTO.setClaimId(UUID.fromString(claimId));
        saveNotification(notificationDTO);
 
        logger.info("Claim status notification sent for claim ID: {} to customer ID: {}", claimId, customerId);
    }
 
    private Notificationdto convertToDTO(Notification notification) {
        Notificationdto dto = new Notificationdto();
        dto.setNotificationId(notification.getNotificationId());
        dto.setMessage(notification.getMessage());
        dto.setTimestamp(notification.getTimestamp());
        dto.setClaimId(UUID.fromString(notification.getClaimId()));
        dto.setCustomerId(UUID.fromString(notification.getCustomerId()));
        dto.setCreatedAt(notification.getCreatedAt());
        dto.setUpdatedAt(notification.getUpdatedAt());
 
        dto.setStarred(notification.getStarred());
 
        return dto;
    }
 
    private Notification convertToEntity(Notificationdto dto) {
        Notification notification = new Notification();
        notification.setNotificationId(dto.getNotificationId());
        notification.setMessage(dto.getMessage());
        notification.setTimestamp(dto.getTimestamp());
        notification.setClaimId(dto.getClaimId().toString());
        notification.setCustomerId(dto.getCustomerId().toString());
        notification.setCreatedAt(dto.getCreatedAt());
        notification.setUpdatedAt(dto.getUpdatedAt());
 
        notification.setStarred(dto.getStarred());
 
        return notification;
    }
 
    @Scheduled(cron = "0 0 0 * * ?")
    public void sendScheduledNotification() {
        logger.info("started save notification");
        ResponseEntity<ResultResponse<List<ClaimDTO>>> claimResponse = claimClient.getClaimsUpdatedYesterdayToToday();
        if (claimResponse.getStatusCode().is2xxSuccessful() && claimResponse.getBody() != null) {
            List<ClaimDTO> claims = claimResponse.getBody().getData();
            logger.info("--" + claims);
            for (ClaimDTO claim : claims) {
                String message = "Your claim with ID: " + claim.getClaimId() + " was updated yesterday" + " to " + claim.getStatus();
                Notificationdto notificationDTO = new Notificationdto();
                notificationDTO.setCustomerId(claim.getCustomerId());
                notificationDTO.setMessage(message);
                notificationDTO.setTimestamp(LocalDateTime.now());
                notificationDTO.setClaimId(UUID.fromString(claim.getClaimId()));
                saveNotification(notificationDTO);
                logger.info("notification sent for claim id: {}", claim.getClaimId());
            }
        } else {
            logger.warn("could not get claims from yesterday");
        }
    }
}
 