package com.example.demo.security;
 
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.annotation.Bean;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;

import org.springframework.security.authorization.AuthorityAuthorizationManager;

import org.springframework.security.authorization.AuthorizationManagers;

import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;

import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import org.springframework.security.crypto.password.PasswordEncoder;

import org.springframework.security.web.SecurityFilterChain;

import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import org.springframework.web.cors.CorsConfiguration;

import org.springframework.web.cors.CorsConfigurationSource;

import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
 
@Configuration

@EnableWebSecurity

public class SecurityConfig {
 
    @Autowired

    private JwtFilter jwtFilter;
 
    @Bean

    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
 
        return http.cors(cors -> cors.configurationSource(corsConfigurationSource()))
        		.csrf(customizer -> customizer.disable())

                .authorizeHttpRequests(request -> request

                        // Customer specific endpoints
                		.requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()

                		.requestMatchers("/api/v1/notification/claim-status-notification").permitAll()

                        .requestMatchers("/api/v1/notification/{notificationId}"

                        		,"/api/v1/notification/customer/{customerId}",

                        		"/api/v1/notification/delete/{id}",

                        		"/api/v1/notification/star/{id}"

                        		).hasAuthority("CUSTOMER")
 
                        .requestMatchers("/api/v1/notification/after/{timestamp}","/api/v1/notification/notifications").hasAuthority("ADMIN")


                        // Publicly accessible endpoints (if any)

                        .anyRequest().authenticated())

                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)

                .build();

    }

    @Bean

    public CorsConfigurationSource corsConfigurationSource() {

        CorsConfiguration configuration = new CorsConfiguration();

        configuration.setAllowedOrigins(java.util.List.of("http://localhost:3000"));

        configuration.setAllowedHeaders(java.util.List.of("*"));

        configuration.setAllowedMethods(java.util.List.of("GET", "POST", "PUT", "DELETE", "OPTIONS")); // Be explicit

        configuration.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();

        source.registerCorsConfiguration("/**", configuration);

        return source;

    }
 
 
    @Bean

    AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {

        return config.getAuthenticationManager();

    }
 
    @Bean

    PasswordEncoder passwordEncoder() {

        return new BCryptPasswordEncoder(12);

    }
 
}
 