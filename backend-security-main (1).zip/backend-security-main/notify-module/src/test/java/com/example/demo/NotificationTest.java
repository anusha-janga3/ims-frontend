package com.example.demo;
 
 
import com.example.demo.client.ClaimClient;
import com.example.demo.dao.NotificationDAO;
import com.example.demo.dto.ClaimDTO;
import com.example.demo.dto.ClaimStatus;
import com.example.demo.dto.Notificationdto;
import com.example.demo.model.Notification;
import com.example.demo.model.ResultResponse;
import com.example.demo.service.NotificationService;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
 
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
 
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
 
@ExtendWith(MockitoExtension.class)
public class NotificationTest {
 
    @Mock
    private NotificationDAO notificationDao;
 
    @Mock
    private ClaimClient claimClient;
 
    @InjectMocks
    private NotificationService notificationService;
 
    private Notification notification;
    private Notificationdto notificationDTO;
    private UUID customerId;
    private UUID claimId;
 
    @BeforeEach
    void setUp() {
        customerId = UUID.randomUUID();
        claimId = UUID.randomUUID();
        notification = new Notification();
        notification.setNotificationId("1");
        notification.setMessage("Test Message");
        notification.setTimestamp(LocalDateTime.now());
        notification.setClaimId(claimId.toString());
        notification.setCustomerId(customerId.toString());
 
        notificationDTO = new Notificationdto();
        notificationDTO.setNotificationId("1");
        notificationDTO.setMessage("Test Message");
        notificationDTO.setTimestamp(LocalDateTime.now());
        notificationDTO.setClaimId(claimId);
        notificationDTO.setCustomerId(customerId);
    }
 
    @Test
    void createNotification_positive() {
        when(notificationDao.save(any(Notification.class))).thenReturn(notification);
        Notificationdto result = notificationService.createNotification(customerId.toString(), "Test Message", claimId.toString());
        assertNotNull(result);
        assertEquals("Test Message", result.getMessage());
    }
 
    @Test
    void saveNotification_positive() {
        when(notificationDao.save(any(Notification.class))).thenReturn(notification);
        Notificationdto result = notificationService.saveNotification(notificationDTO);
        assertNotNull(result);
        assertEquals("Test Message", result.getMessage());
    }
 
    @Test
    void getNotificationById_positive() {
        when(notificationDao.findById("1")).thenReturn(Optional.of(notification));
        Notificationdto result = notificationService.getNotificationById("1");
        assertNotNull(result);
        assertEquals("Test Message", result.getMessage());
    }
 
    @Test
    void getNotificationById_negative() {
        when(notificationDao.findById("1")).thenReturn(Optional.empty());
        assertThrows(RuntimeException.class, () -> notificationService.getNotificationById("1"));
    }
 
    @Test
    void getAllNotifications_positive() {
        when(notificationDao.findAll()).thenReturn(Arrays.asList(notification));
        List<Notificationdto> result = notificationService.getAllNotifications();
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Test Message", result.get(0).getMessage());
    }
 
    @Test
    void getNotificationsByCustomerId_positive() {
        when(notificationDao.findByCustomerId(customerId.toString())).thenReturn(Arrays.asList(notification));
        List<Notificationdto> result = notificationService.getNotificationsByCustomerId(customerId.toString());
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Test Message", result.get(0).getMessage());
    }
 
    @Test
    void getNotificationsAfter_positive() {
        LocalDateTime now = LocalDateTime.now();
        when(notificationDao.findNotificationsAfter(now)).thenReturn(Arrays.asList(notification));
        List<Notificationdto> result = notificationService.getNotificationsAfter(now);
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Test Message", result.get(0).getMessage());
    }
 
    @Test
    void deleteNotificationById_positive() {
        when(notificationDao.existsById("1")).thenReturn(true);
        notificationService.deleteNotificationById("1");
        verify(notificationDao, times(1)).deleteById("1");
    }
 
    @Test
    void deleteNotificationById_negative() {
        when(notificationDao.existsById("1")).thenReturn(false);
        assertThrows(RuntimeException.class, () -> notificationService.deleteNotificationById("1"));
    }
 
    @Test
    void sendClaimStatusNotification_positive() {
        ClaimDTO claimDTO = new ClaimDTO();
        claimDTO.setClaimId(claimId.toString());
        claimDTO.setCustomerId(customerId);
        ResponseEntity<ResultResponse<ClaimDTO>> responseEntity = new ResponseEntity<>(ResultResponse.<ClaimDTO>builder().data(claimDTO).build(), HttpStatus.OK);
 
        when(claimClient.getClaimById(claimId)).thenReturn(responseEntity);
        when(notificationDao.save(any(Notification.class))).thenReturn(notification);
 
        notificationService.sendClaimStatusNotification(claimId.toString(), customerId.toString(), "APPROVED");
        verify(notificationDao, times(1)).save(any(Notification.class));
    }
 
    @Test
    void sendScheduledNotification_positive() {
        ClaimDTO claimDTO = new ClaimDTO();
        claimDTO.setClaimId(claimId.toString());
        claimDTO.setCustomerId(customerId);
        claimDTO.setStatus(ClaimStatus.Approved);
        ResponseEntity<ResultResponse<List<ClaimDTO>>> responseEntity = new ResponseEntity<>(ResultResponse.<List<ClaimDTO>>builder().data(Arrays.asList(claimDTO)).build(), HttpStatus.OK);
 
        when(claimClient.getClaimsUpdatedYesterdayToToday()).thenReturn(responseEntity);
        when(notificationDao.save(any(Notification.class))).thenReturn(notification);
 
        notificationService.sendScheduledNotification();
        verify(notificationDao, times(1)).save(any(Notification.class));
    }
}
 