package com.example.agent.dao;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.agent.model.Agent;

/**
 * Repository interface for Agent entities.
 * 
 * This interface extends JpaRepository, providing CRUD operations for Agent entities.
 */

public interface AgentDao extends JpaRepository<Agent,String>{
	
	// Custom query to find agents by name (case-insensitive)
    @Query("SELECT a FROM Agent a WHERE LOWER(a.name) LIKE LOWER(CONCAT('%', :name, '%'))")
    List<Agent> findAgentsByNameContainingIgnoreCase(@Param("name") String name);

	
//	@Query("SELECT a FROM Agent a WHERE a.policyAssignId = :policyAssignId")
//	List<Agent> findByPolicyAssignId(String policyAssignId);
//	
//	@Query("SELECT a FROM Agent a JOIN a.policyAssigns p WHERE p.policyId = :policyId")
//List<Agent> findAgentsByPolicyId(@Param("policyId") UUID policyId);
//	
//	@Query("SELECT DISTINCT a FROM Agent a JOIN a.policyAssigns p")
//	List<Agent> findAgentsWithPolicy();
//	
//	@Query("SELECT a FROM Agent a WHERE a.policyAssigns IS EMPTY")
//	List<Agent> findAgentsWithoutPolicy();

}
