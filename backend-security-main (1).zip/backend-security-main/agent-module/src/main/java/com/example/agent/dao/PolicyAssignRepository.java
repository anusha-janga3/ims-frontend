package com.example.agent.dao;
 
import java.time.LocalDateTime;

import java.util.List;

import java.util.Optional;
 
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;

import org.springframework.data.repository.query.Param;
 
import com.example.agent.model.PolicyAssign;
 
/**

* Repository interface for PolicyAssign entities.

* 

* This interface extends JpaRepository, providing CRUD operations for PolicyAssign entities.

*/
 
public interface PolicyAssignRepository extends JpaRepository<PolicyAssign, String> {
 
//	// 1. Get all policy assignments for a specific agent:

//    List<PolicyAssign> findByAgentId(String agentId);

//

//    // 2. Get all policy assignments for a specific policy:

//    List<PolicyAssign> findByPolicyId(String policyId);


//	 // 1. Get all policy assignments for a specific agent:

    @Query("SELECT pa FROM PolicyAssign pa WHERE pa.agent.agentId = :agentId")

    List<PolicyAssign> findByAgentId(@Param("agentId") String agentId);

//

//

//    // 2. Get all policy assignments for a specific policy:

    @Query("SELECT pa FROM PolicyAssign pa WHERE pa.policyId = :policyId")

    List<PolicyAssign> findByPolicyId(@Param("policyId") String policyId);


    @Query("SELECT pa FROM PolicyAssign pa WHERE pa.agent.id = :agentId AND pa.policyId = :policyId")

    Optional<PolicyAssign> findByAgentIdAndPolicyId(@Param("agentId") String agentId, @Param("policyId") String policyId);

    //Optional<PolicyAssign> findByPolicyId(String policyId);

    //List<PolicyAssign> findByAgentId(String agentId);
 
}

 