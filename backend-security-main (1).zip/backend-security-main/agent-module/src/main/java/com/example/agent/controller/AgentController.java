package com.example.agent.controller;

import com.example.agent.dto.AgentDTO;
import com.example.agent.exception.AgentNotFoundException;
import com.example.agent.exception.InvalidDataException;
import com.example.agent.service.AgentService;

import jakarta.validation.Valid;

import com.example.agent.model.ResultResponse;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * REST controller for managing Agent entities.
 */

@RestController
@RequestMapping("/api/v1/agents")
@Slf4j
public class AgentController {

    @Autowired
    private AgentService agentService;

    /**
     * Creates a new agent.
     * 
     * @param agentDTO The AgentDto object containing agent details.
     * @return The created AgentDto object.
     */
    @PostMapping("/agent")
    public ResponseEntity<ResultResponse<AgentDTO>> createAgent(@Valid @RequestBody AgentDTO agentDTO) {
        log.debug("Inside the Add agent");

        try {
            AgentDTO createdAgent = agentService.saveAgent(agentDTO);
            ResultResponse<AgentDTO> resultResponse = ResultResponse.<AgentDTO>builder()
                    .success(true)
                    .data(createdAgent)
                    .timestamp(LocalDateTime.now())
                    .build();
            return ResponseEntity.ok(resultResponse);
        } catch (AgentNotFoundException e) {
            log.error("Error creating agent: {}", e.getMessage());
            ResultResponse<AgentDTO> resultResponse = ResultResponse.<AgentDTO>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build();
            return ResponseEntity.status(404).body(resultResponse);
        } catch (InvalidDataException e) {
            log.error("Error creating agent: {}", e.getMessage());
            ResultResponse<AgentDTO> resultResponse = ResultResponse.<AgentDTO>builder()
                    .success(false)
                    .message("Invalid data provided. " + e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build();
            return ResponseEntity.status(400).body(resultResponse);
        } catch (Exception e) {
            log.error("Unexpected error creating agent: {}", e.getMessage());
            ResultResponse<AgentDTO> resultResponse = ResultResponse.<AgentDTO>builder()
                    .success(false)
                    .message("An unexpected error occurred")
                    .timestamp(LocalDateTime.now())
                    .build();
            return ResponseEntity.status(500).body(resultResponse);
        }
    }

    /**
     * Retrieves an agent by ID.
     * 
     * @param agentId The ID of the agent to retrieve.
     * @return ResponseEntity containing the AgentDto object.
     */
    @GetMapping("/{agentId}")
    public ResponseEntity<ResultResponse<AgentDTO>> getAgentById(@PathVariable String agentId) {
        try {
            AgentDTO agentDTO = agentService.readAgent(agentId);
            ResultResponse<AgentDTO> resultResponse = ResultResponse.<AgentDTO>builder()
                    .success(true)
                    .data(agentDTO)
                    .timestamp(LocalDateTime.now())
                    .build();
            return ResponseEntity.ok(resultResponse);
        } catch (AgentNotFoundException e) {
            log.error("Error retrieving agent: {}", e.getMessage());
            ResultResponse<AgentDTO> resultResponse = ResultResponse.<AgentDTO>builder()
                    .success(false)
                    .message("Agent with ID " + agentId + " not found.")
                    .timestamp(LocalDateTime.now())
                    .build();
            return ResponseEntity.status(404).body(resultResponse);
        } catch (InvalidDataException e) {
            log.error("Unexpected error retrieving agent: {}", e.getMessage());
            ResultResponse<AgentDTO> resultResponse = ResultResponse.<AgentDTO>builder()
                    .success(false)
                    .message("Invalid data provided. " + e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build();
            return ResponseEntity.status(500).body(resultResponse);
        }
    }

    /**
     * Updates an existing agent.
     * 
     * @param agentId The ID of the agent to update.
     * @param agentDTO The AgentDto object containing updated agent details.
     * @return ResponseEntity containing the updated AgentDto object.
     */
    @PutMapping("/update/{agentId}")
    public ResponseEntity<ResultResponse<AgentDTO>> updateAgent(@PathVariable String agentId,  @Valid @RequestBody AgentDTO agentDTO) {
        try {
            AgentDTO updatedAgentDTO = agentService.updateAgent(agentId, agentDTO);
            ResultResponse<AgentDTO> resultResponse = ResultResponse.<AgentDTO>builder()
                    .success(true)
                    .data(updatedAgentDTO)
                    .timestamp(LocalDateTime.now())
                    .build();
            return ResponseEntity.ok(resultResponse);
        } catch (AgentNotFoundException e) {
            log.error("Error updating agent: {}", e.getMessage());
            ResultResponse<AgentDTO> resultResponse = ResultResponse.<AgentDTO>builder()
                    .success(false)
                    .message("Agent with ID " + agentId + " not found.")
                    .timestamp(LocalDateTime.now())
                    .build();
            return ResponseEntity.status(404).body(resultResponse);
        } catch (InvalidDataException e) {
            log.error("Error updating agent: {}", e.getMessage());
            ResultResponse<AgentDTO> resultResponse = ResultResponse.<AgentDTO>builder()
                    .success(false)
                    .message("Invalid data provided. " + e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build();
            return ResponseEntity.status(400).body(resultResponse);
        }
    }
    
  

    
    /**
     * Retrieves all agents.
     * 
     * @return List of all AgentDto objects.
     */
    @GetMapping
    public ResponseEntity<ResultResponse<List<AgentDTO>>> getAllAgents() {
        try {
            List<AgentDTO> agents = agentService.getAllAgents();
            ResultResponse<List<AgentDTO>> resultResponse = ResultResponse.<List<AgentDTO>>builder()
                    .success(true)
                    .data(agents)
                    .timestamp(LocalDateTime.now())
                    .build();
            return ResponseEntity.ok(resultResponse);
        } catch (AgentNotFoundException e) {
            log.error("Unexpected error retrieving agents: {}", e.getMessage());
            ResultResponse<List<AgentDTO>> resultResponse = ResultResponse.<List<AgentDTO>>builder()
                    .success(false)
                    .message("Agent not found")
                    .timestamp(LocalDateTime.now())
                    .build();
            return ResponseEntity.status(500).body(resultResponse);
        }
    }
}