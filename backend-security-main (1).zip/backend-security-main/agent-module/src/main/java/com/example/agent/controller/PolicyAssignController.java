package com.example.agent.controller;
 
import com.example.agent.dto.PolicyAssignDTO;
import com.example.agent.exception.PolicyAlreadyAssignedException;
import com.example.agent.service.PolicyAssignService;
 
import jakarta.validation.Valid;
 
import com.example.agent.model.ResultResponse;
 
import lombok.extern.slf4j.Slf4j;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
 
import java.time.LocalDateTime;
import java.util.List;
 
/**
* REST controller for managing PolicyAssign entities.
*/
 
@RestController
@RequestMapping("api/v1/assigned-policy")
@Slf4j
@CrossOrigin(origins = "http://localhost:3000")
public class PolicyAssignController {
 
    @Autowired
    private PolicyAssignService policyAssignService;
 
    /**
     * Assigns a policy to an agent.
     *
    Dto object containing policy assignment details.
     * @return ResponseEntity containing the created PolicyAssignDto object.
     */
    @PostMapping("/addPolicy")
    public ResponseEntity<ResultResponse<PolicyAssignDTO>> assignPolicyToAgent(@Valid @RequestBody PolicyAssignDTO policyAssignDto) {
        try {
            PolicyAssignDTO assignedPolicy = policyAssignService.assignPolicyToAgent(policyAssignDto);
            ResultResponse<PolicyAssignDTO> resultResponse = ResultResponse.<PolicyAssignDTO>builder()
                    .success(true)
                    .data(assignedPolicy)
                    .timestamp(LocalDateTime.now())
                    .build();
            return ResponseEntity.status(HttpStatus.CREATED).body(resultResponse);
        } catch (PolicyAlreadyAssignedException e) {
            log.warn("Policy {} already assigned to agent {}: {}", policyAssignDto.getPolicyId(), policyAssignDto.getAgentId(), e.getMessage());
            ResultResponse<PolicyAssignDTO> resultResponse = ResultResponse.<PolicyAssignDTO>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build();
            return ResponseEntity.status(HttpStatus.CONFLICT).body(resultResponse);
        }catch (com.example.agent.exception.InvalidDataException | com.example.agent.exception.PolicyNotFoundException | com.example.agent.exception.AgentNotFoundException e) {
            log.error("Error assigning policy: {}", e.getMessage());
            ResultResponse<PolicyAssignDTO> resultResponse = ResultResponse.<PolicyAssignDTO>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(resultResponse);
        }catch (Exception e) {
            log.error("Unexpected error assigning policy: {}", e.getMessage());
            ResultResponse<PolicyAssignDTO> resultResponse = ResultResponse.<PolicyAssignDTO>builder()
                    .success(false)
                    .message("An unexpected error occurred")
                    .timestamp(LocalDateTime.now())
                    .build();
            return ResponseEntity.status(500).body(resultResponse);
        }
    }
 
    /**
     * Deletes a policy assignment by ID.
     *
     * @param assignId The ID of the policy assignment to delete.
     * @return ResponseEntity with no content.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<ResultResponse<Void>> deletePolicyAssign(@PathVariable(value = "id") String assignId) {
        try {
            PolicyAssignDTO policyAssignDto = new PolicyAssignDTO();
            policyAssignDto.setAssignId(assignId);
            policyAssignService.deletePolicyAssign(policyAssignDto);
            ResultResponse<Void> resultResponse = ResultResponse.<Void>builder()
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build();
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            log.error("Unexpected error deleting policy assignment: {}", e.getMessage());
            ResultResponse<Void> resultResponse = ResultResponse.<Void>builder()
                    .success(false)
                    .message("An unexpected error occurred")
                    .timestamp(LocalDateTime.now())
                    .build();
            return ResponseEntity.status(500).body(resultResponse);
        }
    }
 
    /**
     * Retrieves all policy assignments.
     *
     * @return ResponseEntity containing the list of PolicyAssignDto objects.
     */
    @GetMapping()
    public ResponseEntity<ResultResponse<List<PolicyAssignDTO>>> getAllPolicyAssignments() {
        try {
            List<PolicyAssignDTO> policyAssignments = policyAssignService.getAllPolicyAssignments();
            ResultResponse<List<PolicyAssignDTO>> resultResponse = ResultResponse.<List<PolicyAssignDTO>>builder()
                    .success(true)
                    .data(policyAssignments)
                    .timestamp(LocalDateTime.now())
                    .build();
            return ResponseEntity.ok(resultResponse);
        } catch (Exception e) {
            log.error("Unexpected error retrieving policy assignments: {}", e.getMessage());
            ResultResponse<List<PolicyAssignDTO>> resultResponse = ResultResponse.<List<PolicyAssignDTO>>builder()
                    .success(false)
                    .message("An unexpected error occurred")
                    .timestamp(LocalDateTime.now())
                    .build();
            return ResponseEntity.status(500).body(resultResponse);
        }
    }
    
    @GetMapping("/agent/{agentId}")
    public ResponseEntity<ResultResponse<List<PolicyAssignDTO>>> getPolicyAssignmentsByAgentId(@PathVariable String agentId) {
        try {
            List<PolicyAssignDTO> policyAssignDTOs = policyAssignService.getPolicyAssignmentsByAgentId(agentId);
            ResultResponse<List<PolicyAssignDTO>> resultResponse = ResultResponse.<List<PolicyAssignDTO>>builder()
                    .success(true)
                    .data(policyAssignDTOs)
                    .timestamp(LocalDateTime.now())
                    .build();
            return ResponseEntity.ok(resultResponse);
        } catch (Exception e) {
            log.error("Error retrieving policy assignments for agent ID {}: {}", agentId, e.getMessage());
            ResultResponse<List<PolicyAssignDTO>> resultResponse = ResultResponse.<List<PolicyAssignDTO>>builder()
                    .success(false)
                    .message("Error retrieving policy assignments")
                    .timestamp(LocalDateTime.now())
                    .build();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resultResponse);
        }
    }
    
}
 
 
 
 
 
 
 
 
 
 
 
 