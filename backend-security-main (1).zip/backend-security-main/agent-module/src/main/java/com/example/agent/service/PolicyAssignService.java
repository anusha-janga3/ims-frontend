package com.example.agent.service;

import java.time.LocalDateTime;

import java.util.List;

import java.util.Optional;

import java.util.UUID;

import java.util.stream.Collectors;
 
import org.slf4j.Logger;

import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;

import org.springframework.stereotype.Service;
 
import com.example.agent.client.PolicyClient;

import com.example.agent.dao.AgentDao;

import com.example.agent.dao.PolicyAssignRepository;

import com.example.agent.dto.PolicyAssignDTO;

import com.example.agent.dto.PolicyDTO;

import com.example.agent.exception.AgentNotFoundException;

import com.example.agent.exception.PolicyNotFoundException;

import com.example.agent.exception.InvalidDataException;

import com.example.agent.exception.PolicyAlreadyAssignedException;

import com.example.agent.model.Agent;

import com.example.agent.model.PolicyAssign;

import com.example.agent.model.ResultResponse;
 
@Service

public class PolicyAssignService {

    private static final Logger logger = LoggerFactory.getLogger(PolicyAssignService.class);
 
    @Autowired

    private PolicyAssignRepository policyAssignRepo;
 
    @Autowired

    private PolicyClient policyClient;
 
    @Autowired

    private AgentDao agentRepo;
 
    public boolean policyExists(UUID policyId) {

        ResponseEntity<ResultResponse<PolicyDTO>> response = policyClient.getPolicyById(policyId);

        return response.getStatusCode() == HttpStatus.OK;

    }
 
    public boolean agentExists(String agentId) {

        return agentRepo.existsById(agentId);

    }

    private void policyAlreadyAssignedExists(String agentId, UUID policyId) throws PolicyAlreadyAssignedException {

        // Check if the policy is already assigned to this agent

        Optional<PolicyAssign> existingAssignmentForAgent = policyAssignRepo.findByAgentIdAndPolicyId(

                agentId,

                policyId.toString()

        );

        if (existingAssignmentForAgent.isPresent()) {

            throw new PolicyAlreadyAssignedException(String.format("Policy is already assigned to Agent "));

        }
 
        // Check if the policy is already assigned to any other agent

        List<PolicyAssign> existingAssignmentForPolicy = policyAssignRepo.findByPolicyId(policyId.toString());

        if (!existingAssignmentForPolicy.isEmpty()) {

            throw new PolicyAlreadyAssignedException(String.format("Policy %s is already assigned to another agent.", policyId));

        }

    }
 
    public PolicyAssignDTO assignPolicyToAgent(PolicyAssignDTO policyAssignDto) throws InvalidDataException, PolicyNotFoundException, AgentNotFoundException, PolicyAlreadyAssignedException {

        logger.info("Assigning policy with ID {} to agent with ID {}", policyAssignDto.getPolicyId(), policyAssignDto.getAgentId());
 
        if (policyAssignDto.getPolicyId() == null) {

            throw new InvalidDataException("Policy ID cannot be null.");

        }
 
        if (policyAssignDto.getAgentId() == null || policyAssignDto.getAgentId().length() != 36) {

            throw new InvalidDataException("Invalid UUID format for Agent ID. Agent ID must be a 36-character string.");

        }
 
        if (!policyExists(policyAssignDto.getPolicyId())) {

            throw new PolicyNotFoundException("Policy does not exist.");

        }
 
        if (!agentExists(policyAssignDto.getAgentId())) {

            throw new AgentNotFoundException("Agent does not exist.");

        }

        // Check if the policy is already assigned

        policyAlreadyAssignedExists(policyAssignDto.getAgentId(), policyAssignDto.getPolicyId());
 
        PolicyAssign policyAssign = new PolicyAssign();
 
        UUID policyId = policyAssignDto.getPolicyId();
 
        ResponseEntity<ResultResponse<PolicyDTO>> policyDto = policyClient.getPolicyById(policyId);

        Agent agent = agentRepo.findById(policyAssignDto.getAgentId())

                .orElseThrow(() -> new AgentNotFoundException("Agent not found with id: " + policyAssignDto.getAgentId()));
 
//        PolicyAssign.Policy policy = new PolicyAssign.Policy();

//        policy.setPolicyId(policyDto.getPolicyId());
 
        policyAssign.setPolicyId(policyId.toString());

        policyAssign.setAgent(agent);

        policyAssign.setAssignedDate(policyAssignDto.getAssignedDate());
 
        PolicyAssign savedPolicyAssign = policyAssignRepo.save(policyAssign);

        return convertToDto(savedPolicyAssign);

    }
 
    public void deletePolicyAssign(PolicyAssignDTO policyAssignDto) {

        logger.info("Deleting policy assignment with ID {}", policyAssignDto.getAssignId());

        policyAssignRepo.deleteById(policyAssignDto.getAssignId());

        logger.info("Policy assignment deleted successfully with ID {}", policyAssignDto.getAssignId());

    }
 
    public List<PolicyAssignDTO> getAllPolicyAssignments() {

        logger.info("Fetching all policy assignments");

        return policyAssignRepo.findAll().stream()

                .map(this::convertToDto)

                .collect(Collectors.toList());

    }
 
    public PolicyAssignDTO getPolicyAssignById(String id) throws PolicyNotFoundException {

        logger.info("Retrieving Policy Assign by ID: {}", id);

        PolicyAssign policyAssign = policyAssignRepo.findById(id).orElseThrow(() -> new PolicyNotFoundException("Policy Assign not found "));

        logger.info("Policy Assign found: {}", policyAssign);

        return convertToDto(policyAssign);

    }

    public List<PolicyAssignDTO> getPolicyAssignmentsByAgentId(String agentId) {

        logger.info("Fetching policy assignments for agent ID: {}", agentId);

        List<PolicyAssign> policyAssigns = policyAssignRepo.findByAgentId(agentId);

        return policyAssigns.stream()

                .map(this::convertToDto)

                .collect(Collectors.toList());

    }
 
    private PolicyAssignDTO convertToDto(PolicyAssign policyAssign) {

        return new PolicyAssignDTO(

                policyAssign.getPolicyAssignId(),

                UUID.fromString(policyAssign.getPolicyId().toString()),

                policyAssign.getAgent().getAgentId(),

                policyAssign.getAssignedDate()

        );

    }

}
 
 