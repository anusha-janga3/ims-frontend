//package com.example.agent.security;
//
//import org.springframework.beans.factory.annotation.Autowired;
//
//import org.springframework.context.annotation.Bean;
//
//import org.springframework.context.annotation.Configuration;
//
//import org.springframework.security.authentication.AuthenticationManager;
//
//import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
//
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//
//import org.springframework.security.crypto.password.PasswordEncoder;
//
//import org.springframework.security.web.SecurityFilterChain;
//
//import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
//
//import org.springframework.web.cors.CorsConfiguration;
//
//import org.springframework.web.cors.CorsConfigurationSource;
//
//import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
// 
//
//
//@Configuration
//
//@EnableWebSecurity
//
//public class SecurityConfig {
//
//    @Autowired
//
//    private JwtFilter jwtFilter;
//
//    @Bean
//
//    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//
//        return http.csrf(customizer -> customizer.disable())
//
//                .authorizeHttpRequests(request -> request
//
//                		.requestMatchers("/api/v1/policies").authenticated()
//
//                		.requestMatchers(
//
//                        		"/api/v1/policies/{policyId}","/api/v1/agents/agent","api/v1/assigned-policy").permitAll()
//
//                		.requestMatchers(
//
//                                "/api/v1/agents",
//                                "/api/v1/agents/update/{agentId}",
//
//                                "/api/v1/assigned-policy/addPolicy"
//
//                        ).hasAuthority("ADMIN")
//
//
////                		.requestMatchers(
//
////                                "/api/v1/agents/update/{agentId}"
//
////                        ).hasAnyAuthority("ADMIN","AGENT")
//
//                		.requestMatchers(org.springframework.http.HttpMethod.PUT, "/api/v1/agents/update/{agentId}")
//
//                		.hasAnyAuthority("ADMIN")
//
//
//                     // Shared endpoints
//
//                        
//
//
////                       
//
//                        // Publicly accessible endpoints (if any)
//
//                        .anyRequest().authenticated())
//
//                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)
//
//                .cors(cors -> cors.configurationSource(corsConfigurationSource())) // Enable CORS using the bean
//
//                .build();
//
//    }
//
////        		.authorizeHttpRequests(request -> request
//
////
//
////        		        .requestMatchers(
//
////        		                "/api/v1/agents/agent"
//
////        		        ).permitAll()
//
////        		        .requestMatchers(
//
////        		                "/api/v1/agents",
//
////        		                "/api/v1/assigned-policy/addPolicy"
//
////        		        ).hasAuthority("ADMIN")
//
////
//
////
//
////        		        .requestMatchers(org.springframework.http.HttpMethod.GET, "/api/v1/agents/{agentId}")
//
////        		        .hasAnyAuthority("ADMIN", "AGENT", "CUSTOMER")
//
////
//
////        		        .requestMatchers(org.springframework.http.HttpMethod.PUT, "/api/v1/agents/update/{agentId}")
//
////        		        .hasAnyAuthority("ADMIN", "AGENT") // Only ADMIN and AGENT can update
//
////
//
////        		        .requestMatchers("/api/v1/policies").hasAnyAuthority("ADMIN", "AGENT", "CUSTOMER")
//
////
//
////
//
////        		        // Publicly accessible endpoints (if any)
//
////        		        .anyRequest().authenticated())
//
////        		.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)
//
////              .build();
//
////          }
//
////    
//
////    @Bean
//
////    public CorsConfigurationSource corsConfigurationSource() {
//
////        CorsConfiguration configuration = new CorsConfiguration();
//
////        configuration.setAllowedOrigins(java.util.List.of("http://localhost:3000")); // Allow React frontend
//
////        configuration.setAllowedHeaders(java.util.List.of("*")); // Allow all headers
//
////        configuration.setAllowedMethods(java.util.List.of("*")); // Allow all HTTP methods
//
////        configuration.setAllowCredentials(true); // Allow credentials
//
////        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
//
////        source.registerCorsConfiguration("/**", configuration);
//
////        return source;
//
////    }
// 
//    
//
//    @Bean
//
//    public CorsConfigurationSource corsConfigurationSource() {
//
//        CorsConfiguration configuration = new CorsConfiguration();
//
//        configuration.setAllowedOrigins(java.util.List.of("http://localhost:3000"));
//
//        configuration.setAllowedHeaders(java.util.List.of("*"));
//
//        configuration.setAllowedMethods(java.util.List.of("GET", "POST", "PUT", "DELETE", "OPTIONS")); // Be explicit
//
//        configuration.setAllowCredentials(true);
//
//        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
//
//        source.registerCorsConfiguration("/**", configuration);
//
//        return source;
//
//    }
//
//    @Bean
//
//    AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
//
//        return config.getAuthenticationManager();
//
//    }
// 
//    @Bean
//
//    PasswordEncoder passwordEncoder() {
//
//        return new BCryptPasswordEncoder(12);
//
//    }
// 
//}
//
// 



package com.example.agent.security;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.annotation.Bean;

import org.springframework.context.annotation.Configuration;

import org.springframework.security.authentication.AuthenticationManager;

import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;

import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import org.springframework.security.crypto.password.PasswordEncoder;

import org.springframework.security.web.SecurityFilterChain;

import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import org.springframework.web.cors.CorsConfiguration;

import org.springframework.web.cors.CorsConfigurationSource;

import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
 


@Configuration

@EnableWebSecurity

public class SecurityConfig {

    @Autowired

    private JwtFilter jwtFilter;

    @Bean

    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        return http.cors(cors -> cors.configurationSource(corsConfigurationSource()))
        		.csrf(customizer -> customizer.disable())

                .authorizeHttpRequests(request -> request


                		.requestMatchers(

                        		"/api/v1/policies/{policyId}","/api/v1/agents/{agentId}").permitAll()

                		.requestMatchers(

                        		"/api/v1/agents/agent"

                        		).permitAll()

                		.requestMatchers("/api/v1/policies").authenticated()

                		.requestMatchers(

                                "/api/v1/agents",

                                "/api/v1/assigned-policy/addPolicy"

                        ).hasAuthority("ADMIN")


//                		.requestMatchers(

//                                "/api/v1/agents/update/{agentId}"

//                        ).hasAnyAuthority("ADMIN","AGENT")

                		.requestMatchers("/api/v1/agents/update/{agentId}").hasAuthority("ADMIN")


                     // Shared endpoints

                        .requestMatchers(

                        		

                        		"/api/v1/policies",

                        		"api/v1/assigned-policy"

                        		).hasAnyAuthority("ADMIN", "AGENT","CUSTOMER")


//                       

                        // Publicly accessible endpoints (if any)

                        .anyRequest().authenticated())

                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)

                 // Enable CORS using the bean

                .build();

    }

//        		.authorizeHttpRequests(request -> request

//

//        		        .requestMatchers(

//        		                "/api/v1/agents/agent"

//        		        ).permitAll()

//        		        .requestMatchers(

//        		                "/api/v1/agents",

//        		                "/api/v1/assigned-policy/addPolicy"

//        		        ).hasAuthority("ADMIN")

//

//

//        		        .requestMatchers(org.springframework.http.HttpMethod.GET, "/api/v1/agents/{agentId}")

//        		        .hasAnyAuthority("ADMIN", "AGENT", "CUSTOMER")

//

//        		        .requestMatchers(org.springframework.http.HttpMethod.PUT, "/api/v1/agents/update/{agentId}")

//        		        .hasAnyAuthority("ADMIN", "AGENT") // Only ADMIN and AGENT can update

//

//        		        .requestMatchers("/api/v1/policies").hasAnyAuthority("ADMIN", "AGENT", "CUSTOMER")

//

//

//        		        // Publicly accessible endpoints (if any)

//        		        .anyRequest().authenticated())

//        		.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)

//              .build();

//          }

//    

//    @Bean

//    public CorsConfigurationSource corsConfigurationSource() {

//        CorsConfiguration configuration = new CorsConfiguration();

//        configuration.setAllowedOrigins(java.util.List.of("http://localhost:3000")); // Allow React frontend

//        configuration.setAllowedHeaders(java.util.List.of("*")); // Allow all headers

//        configuration.setAllowedMethods(java.util.List.of("*")); // Allow all HTTP methods

//        configuration.setAllowCredentials(true); // Allow credentials

//        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();

//        source.registerCorsConfiguration("/**", configuration);

//        return source;

//    }
 
    

    @Bean

    public CorsConfigurationSource corsConfigurationSource() {

        CorsConfiguration configuration = new CorsConfiguration();

        configuration.setAllowedOrigins(java.util.List.of("http://localhost:3000"));

        configuration.setAllowedHeaders(java.util.List.of("*"));

        configuration.setAllowedMethods(java.util.List.of("GET", "POST", "PUT", "DELETE", "OPTIONS")); // Be explicit

        configuration.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();

        source.registerCorsConfiguration("/**", configuration);

        return source;

    }

    @Bean

    AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {

        return config.getAuthenticationManager();

    }
 
    @Bean

    PasswordEncoder passwordEncoder() {

        return new BCryptPasswordEncoder(12);

    }
 
}

 