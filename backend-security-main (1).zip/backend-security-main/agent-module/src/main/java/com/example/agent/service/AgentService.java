package com.example.agent.service;

import com.example.agent.client.AdminClient;
import com.example.agent.dao.AgentDao;
import com.example.agent.dto.AdminDTO;
import com.example.agent.dto.AgentDTO;
import com.example.agent.exception.AgentNotFoundException;
import com.example.agent.exception.InvalidDataException;
import com.example.agent.model.Agent;
import com.example.agent.model.ResultResponse;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Service
public class AgentService {

    private static final Logger logger = LoggerFactory.getLogger(AgentService.class);

    @Autowired
    private AgentDao agentRepo;

    @Autowired
    private AdminClient adminClient;

    public boolean adminExists(String adminId) {
        ResponseEntity<ResultResponse<AdminDTO>> response = adminClient.getAdminById(UUID.fromString(adminId));
        return response.getStatusCode() == HttpStatus.OK;
    }

    public AgentDTO updateAgent(String agentId, AgentDTO agentDTO) throws InvalidDataException, AgentNotFoundException {
        logger.info("Updating agent with ID: {}", agentId);

        if (agentDTO.getAdminId() == null || agentDTO.getAdminId().toString().length() != 36) {
            throw new InvalidDataException("Invalid UUID format for Admin ID. Admin ID must be a 36-character string.");
        }

        if (!adminExists(agentDTO.getAdminId().toString())) {
            throw new AgentNotFoundException("Admin does not exist.");
        }

        Agent existingAgent = agentRepo.findById(agentId)
                .orElseThrow(() -> new AgentNotFoundException("Agent not found with id: " + agentId));

        // Update only the fields that are provided in the DTO
        if (agentDTO.getName() != null) {
            existingAgent.setName(agentDTO.getName());
            logger.debug("Updated agent name to: {}", agentDTO.getName());
        }
        if (agentDTO.getContactInfo() != null) {
            existingAgent.setContactInfo(agentDTO.getContactInfo());
            logger.debug("Updated agent contact info to: {}", agentDTO.getContactInfo());
        }
        if (agentDTO.getAdminId() != null) {
           // existingAgent.setAdminId(agentDTO.getAdminId());
        	// existingAgent.setAdminId(agentDTO.getAdminId().toString());
        	 existingAgent.setAdminId(agentDTO.getAdminId().toString());
            logger.debug("Updated agent admin to: {}", agentDTO.getAdminId());
        }
        existingAgent.setUpdatedAt(LocalDateTime.now());

        logger.info("Agent updated successfully with ID: {}", existingAgent.getAgentId());

        Agent updatedAgent = agentRepo.save(existingAgent);
        return convertToDto(updatedAgent);
    }

    public AgentDTO saveAgent(AgentDTO agentDTO) throws InvalidDataException, AgentNotFoundException {
        logger.info("Saving agent with details: {}", agentDTO);

        if (agentDTO.getAdminId() == null || agentDTO.getAdminId().toString().length() != 36) {
            throw new InvalidDataException("Invalid UUID format for Admin ID. Admin ID must be a 36-character string.");
        }

        if (!adminExists(agentDTO.getAdminId().toString())) {
            throw new AgentNotFoundException("Admin does not exist.");
        }

        Agent agent = new Agent();
        agent.setName(agentDTO.getName());
        agent.setContactInfo(agentDTO.getContactInfo());
        //agent.setPassword(agentDTO.getPassword());
        agent.setAdminId(agentDTO.getAdminId().toString());
        agent.setEmail(agentDTO.getEmail());
        agent.setCreatedAt(LocalDateTime.now());
        agent.setUpdatedAt(LocalDateTime.now());
        agent.setAgentId(agentDTO.getAgentId());

        logger.info("Mapped agent entity: {}", agent);

        Agent savedAgent = agentRepo.save(agent);
        return convertToDto(savedAgent);
    }

    public AgentDTO readAgent(String agentId) throws AgentNotFoundException {
        Agent agent = agentRepo.findById(agentId).orElseThrow(() -> new AgentNotFoundException("Agent not found "));
        return convertToDto(agent);
    }

//    public void deleteAgent(AgentDTO agentDTO) {
//        String agentId = agentDTO.getAgentId();
//        logger.info("Deleting agent with ID: {}", agentId);
//        agentRepo.deleteById(agentId);
//        logger.info("Agent deleted successfully with ID: {}", agentId);
//    }
    
    
   

    public List<AgentDTO> getAllAgents() {
        logger.info("Fetching all agents");
        return agentRepo.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    private AgentDTO convertToDto(Agent agent) {
        if (agent == null) {
            return null;
        }

        AgentDTO dto = new AgentDTO(); // Create a new AgentDTO instance
        dto.setAgentId(agent.getAgentId());
        dto.setName(agent.getName());
        dto.setContactInfo(agent.getContactInfo());
        dto.setEmail(agent.getEmail());
        //dto.setPassword(agent.getPassword());
        dto.setAdminId(UUID.fromString(agent.getAdminId())); // Convert adminId to UUID
        dto.setCreatedAt(agent.getCreatedAt());
        dto.setUpdatedAt(agent.getUpdatedAt());

        return dto;
    }
}