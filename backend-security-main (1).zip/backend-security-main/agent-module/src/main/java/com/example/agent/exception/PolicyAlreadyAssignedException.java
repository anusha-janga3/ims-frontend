
package com.example.agent.exception;
 
public class PolicyAlreadyAssignedException extends Exception{
	private static final long serialVersionUID = 1L;
 
	public PolicyAlreadyAssignedException(String message) {
	        super(message);
	    }
 
}
 
 