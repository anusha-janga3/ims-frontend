package com.example.agent.client;

import com.example.agent.dto.AdminDTO;
import com.example.agent.model.ResultResponse;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
 
import java.util.UUID;
 
@FeignClient(name = "auth-service") 
public interface AdminClient {
 
    @GetMapping("/api/v1/users/admin/{adminId}")
    ResponseEntity<ResultResponse<AdminDTO>> getAdminById(@PathVariable UUID adminId);
    // Add other admin-related endpoints as needed 
}
