package com.example.agent.dto;

import java.time.LocalDateTime;
import java.util.UUID;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor 
public class PolicyAssignDTO {
    
    private String assignId;
    
    @NotNull(message = "Policy ID is mandatory")
    private UUID policyId;
    
    @NotBlank(message = "Agent ID is mandatory")
    private String agentId;
    
    @NotNull(message = "Assigned date is mandatory")
    @PastOrPresent(message = "Assigned date must be in the past or present")
    private LocalDateTime assignedDate;
}