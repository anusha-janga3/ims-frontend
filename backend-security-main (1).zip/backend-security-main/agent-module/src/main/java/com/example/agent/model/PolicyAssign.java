package com.example.agent.model;

import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
 
@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name="PolicyAssign")
public class PolicyAssign {
	@Id
	@Column(name="id")
	private String policyAssignId;
	
	@Column(name="assignedDate",nullable=false)
	private LocalDateTime assignedDate;
	
	@ManyToOne
	@JoinColumn(name="agentId")
	private Agent agent;
	

	@Column(name="policyId" , nullable = false)
	private String  policyId;
	
	@Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
	
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @PrePersist
    public void generateUuidAndCreatedAt() {
        String uuid= UUID.randomUUID().toString();
        policyAssignId=uuid;
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }
    @PreUpdate
    public void updateUpdatedAt() {
        this.updatedAt = LocalDateTime.now();
    }
 
}
