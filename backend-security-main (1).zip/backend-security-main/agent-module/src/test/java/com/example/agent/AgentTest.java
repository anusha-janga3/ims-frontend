package com.example.agent;


import com.example.agent.controller.AgentController;
import com.example.agent.controller.PolicyAssignController;
import com.example.agent.dto.AgentDTO;
import com.example.agent.dto.PolicyAssignDTO;
import com.example.agent.exception.AgentNotFoundException;
import com.example.agent.exception.InvalidDataException;
import com.example.agent.exception.PolicyAlreadyAssignedException;
import com.example.agent.exception.PolicyNotFoundException;
import com.example.agent.model.ResultResponse;
import com.example.agent.service.AgentService;
import com.example.agent.service.PolicyAssignService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

public class AgentTest {

    @Mock
    private AgentService agentService;

    @Mock
    private PolicyAssignService policyAssignService;

    @InjectMocks
    private AgentController agentController;

    @InjectMocks
    private PolicyAssignController policyAssignController;
    
    private PolicyAssignDTO policyAssignDTO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // AgentController Tests

    @Test
    void createAgent_Positive() throws InvalidDataException, AgentNotFoundException {
        AgentDTO agentDTO = new AgentDTO();
        agentDTO.setName("Test Agent");
        agentDTO.setAdminId(UUID.randomUUID());

        AgentDTO createdAgent = new AgentDTO();
        createdAgent.setAgentId("550e8400-e29b-41d4-a716-446655440000");
        createdAgent.setName("Test Agent");
        createdAgent.setAdminId(agentDTO.getAdminId());

        when(agentService.saveAgent(agentDTO)).thenReturn(createdAgent);

        ResponseEntity<ResultResponse<AgentDTO>> response = agentController.createAgent(agentDTO);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().isSuccess());
        assertEquals("550e8400-e29b-41d4-a716-446655440000", response.getBody().getData().getAgentId());
    }

    @Test
    void createAgent_Negative_AgentNotFound() throws InvalidDataException, AgentNotFoundException {
        AgentDTO agentDTO = new AgentDTO();
        agentDTO.setName("Test Agent");
        agentDTO.setAdminId(UUID.randomUUID());

        when(agentService.saveAgent(agentDTO)).thenThrow(new AgentNotFoundException("Admin not found"));

        ResponseEntity<ResultResponse<AgentDTO>> response = agentController.createAgent(agentDTO);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNotNull(response.getBody());
        assertFalse(response.getBody().isSuccess());
        assertEquals("Admin not found", response.getBody().getMessage());
    }

    @Test
    void createAgent_Negative_InvalidData() throws InvalidDataException, AgentNotFoundException {
        AgentDTO agentDTO = new AgentDTO();
        agentDTO.setName("Test Agent");
        agentDTO.setAdminId(UUID.randomUUID());

        when(agentService.saveAgent(agentDTO)).thenThrow(new InvalidDataException("Invalid data"));

        ResponseEntity<ResultResponse<AgentDTO>> response = agentController.createAgent(agentDTO);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertFalse(response.getBody().isSuccess());
        assertEquals("Invalid data provided. Invalid data", response.getBody().getMessage());
    }

    @Test
    void getAgentById_Positive() throws AgentNotFoundException, InvalidDataException {
        AgentDTO agentDTO = new AgentDTO();
        agentDTO.setAgentId("getAgentById_Positive");
        agentDTO.setName("Test Agent");

        when(agentService.readAgent("550e8400-e29b-41d4-a716-446655440000")).thenReturn(agentDTO);

        ResponseEntity<ResultResponse<AgentDTO>> response = agentController.getAgentById("550e8400-e29b-41d4-a716-446655440000");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().isSuccess());
        assertEquals("550e8400-e29b-41d4-a716-446655440000", response.getBody().getData().getAgentId());
    }

    @Test
    void getAgentById_Negative_NotFound() throws AgentNotFoundException, InvalidDataException {
        String agentId = "550e8400-e29b-41d4-a716-446655440000"; // Store the agentId

        when(agentService.readAgent(agentId)).thenThrow(new AgentNotFoundException("Agent not found"));

        ResponseEntity<ResultResponse<AgentDTO>> response = agentController.getAgentById(agentId);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNotNull(response.getBody());
        assertFalse(response.getBody().isSuccess());
        assertEquals("Agent with ID " + agentId + " not found.", response.getBody().getMessage()); // Correct assertion
    }

    @Test
    void updateAgent_Positive() throws AgentNotFoundException, InvalidDataException {
        AgentDTO agentDTO = new AgentDTO();
        agentDTO.setName("Updated Agent");

        AgentDTO updatedAgent = new AgentDTO();
        updatedAgent.setAgentId("550e8400-e29b-41d4-a716-446655440000");
        updatedAgent.setName("Updated Agent");

        when(agentService.updateAgent("550e8400-e29b-41d4-a716-446655440000", agentDTO)).thenReturn(updatedAgent);

        ResponseEntity<ResultResponse<AgentDTO>> response = agentController.updateAgent("550e8400-e29b-41d4-a716-446655440000", agentDTO);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().isSuccess());
        assertEquals("Updated Agent", response.getBody().getData().getName());
    }

    @Test
    void updateAgent_Negative_NotFound() throws AgentNotFoundException, InvalidDataException {
        AgentDTO agentDTO = new AgentDTO();
        agentDTO.setName("Updated Agent");

        when(agentService.updateAgent("550e8400-e29b-41d4-a716-446655440000", agentDTO)).thenThrow(new AgentNotFoundException("Agent not found"));

        ResponseEntity<ResultResponse<AgentDTO>> response = agentController.updateAgent("550e8400-e29b-41d4-a716-446655440000", agentDTO);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNotNull(response.getBody());
        assertFalse(response.getBody().isSuccess());
        assertEquals("Agent with ID not found.", response.getBody().getMessage());
    }

    @Test
    void getAllAgents_Positive() {
        List<AgentDTO> agents = new ArrayList<>();
        AgentDTO agent1 = new AgentDTO();
        agent1.setAgentId("1");
        agents.add(agent1);
        AgentDTO agent2 = new AgentDTO();
        agent2.setAgentId("2");
        agents.add(agent2);

        when(agentService.getAllAgents()).thenReturn(agents);

        ResponseEntity<ResultResponse<List<AgentDTO>>> response = agentController.getAllAgents();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().isSuccess());
        assertEquals(2, response.getBody().getData().size());
    }

    // PolicyAssignController Tests

    @Test
    void assignPolicyToAgent_Positive() throws  PolicyNotFoundException, InvalidDataException, AgentNotFoundException, PolicyAlreadyAssignedException {
    	 PolicyAssignDTO assignedPolicy = policyAssignDTO;
         when(policyAssignService.assignPolicyToAgent(policyAssignDTO)).thenReturn(assignedPolicy);

         ResponseEntity<ResultResponse<PolicyAssignDTO>> response = policyAssignController.assignPolicyToAgent(policyAssignDTO);

         assertEquals(HttpStatus.CREATED, response.getStatusCode());
         assertNotNull(response.getBody());
         assertEquals(assignedPolicy, response.getBody().getData());
         assertTrue(response.getBody().isSuccess());
    }


    @Test
    void getAllPolicyAssignments_Positive() {
        List<PolicyAssignDTO> assignments = new ArrayList<>();
        PolicyAssignDTO assign1 = new PolicyAssignDTO();
        assign1.setAssignId("1");
        assignments.add(assign1);
        PolicyAssignDTO assign2 = new PolicyAssignDTO();
        assign2.setAssignId("2");
        assignments.add(assign2);

        when(policyAssignService.getAllPolicyAssignments()).thenReturn(assignments);
    }
    }
