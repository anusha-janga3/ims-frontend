// NotificationItem.js
import React from 'react';
import { FaStar, FaRegStar } from 'react-icons/fa';
import './Notification.css'; // Assuming you have a Notification.css file
import 'bootstrap-icons/font/bootstrap-icons.css';

const NotificationItem = ({ notification, starNotification, deleteNotification }) => {
    const isApproved = notification.message.slice(-8).toLowerCase() === 'approved';
    const itemClass = isApproved ? 'notification-item approved' : 'notification-item rejected';
    const formattedTimestamp = notification.timestamp ? new Date(notification.timestamp).toLocaleString() : 'N/A';

    return (
        <div className="notification-item-container">
            <div className="notification-item-with-star">
                <div className={itemClass}>
                    <div className="notification-content-partition">
                        <div className="notification-details">
                            <div className="notification-header">
                                <p className="notification-message">
                                    Dear User,
                                    <br />
                                    {notification.message}
                                    <br />
                                    Time of action: {formattedTimestamp}
                                </p>
                                <div className="notification-timestamp">
                                    {notification.timestamp && new Date(notification.timestamp).toLocaleString()}
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="delete-partition">
                        <button
                            className={`star-button ${notification.starred ? 'starred' : ''}`}
                            onClick={() => starNotification(notification.notificationId)}
                        >
                            {notification.starred ? (
                                <FaStar className="star-icon" />
                            ) : (
                                <FaRegStar className="star-icon" />
                            )}
                        </button>
                        <i className="bi bi-trash delete-icon" onClick={() => deleteNotification(notification.notificationId)}></i>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default NotificationItem;