import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import NotificationItem from './NotificationItem';
import './Notification.css';
import 'bootstrap-icons/font/bootstrap-icons.css';

const NotificationPage = () => {
    const [notifications, setNotifications] = useState([]);
    const [notificationMessage, setNotificationMessage] = useState('');
    const [showPopup, setShowPopup] = useState(false);
    const [notificationCount, setNotificationCount] = useState(0);
    const popupRef = useRef(null);

    // Replace with your actual UUID and token retrieval logic
    const uuid = localStorage.getItem("userId");
    const token = localStorage.getItem('userToken');

    useEffect(() => {
        if (showPopup) {
            fetchAllNotifications();
            const handleClickOutside = (event) => {
                if (popupRef.current && !popupRef.current.contains(event.target)) {
                    setShowPopup(false);
                }
            };

            document.addEventListener('mousedown', handleClickOutside);

            return () => {
                document.removeEventListener('mousedown', handleClickOutside);
            };
        }
    }, [showPopup]);

    const compareTimestamps = (a, b) => {
        // Assuming your timestamp property is named 'createdAt'. Adjust if needed.
        const timestampA = a.createdAt;
        const timestampB = b.createdAt;

        if (!timestampA || !timestampB) {
            return 0; // Keep original order if timestamp is missing
        }

        const dateA = new Date(timestampA);
        const dateB = new Date(timestampB);

        if (isNaN(dateA.getTime()) || isNaN(dateB.getTime())) {
            console.error("Invalid date format:", timestampA, timestampB);
            return 0; // Keep original order if parsing fails
        }

        return dateB.getTime() - dateA.getTime(); // Sort newest first
    };

    const fetchAllNotifications = async () => {
        try {
            const response = await axios.get(`/api/v1/notification/customer/${uuid}`, {
                headers: {
                    'Authorization': `Bearer ${token}`,
                },
            });
            console.log("API Response:", response);
            if (response.data && response.data.data) {
                console.log("Raw Notification Data:", response.data.data);
                const sortedByTimestamp = [...response.data.data].sort(compareTimestamps);
                console.log("Sorted Notification Data:", sortedByTimestamp);
                setNotifications(sortedByTimestamp);
                setNotificationCount(sortedByTimestamp.length);
            } else {
                console.log("API Response Invalid Data:", response.data);
            }
        } catch (error) {
            console.error('Error fetching notifications:', error);
            setNotificationMessage('Error fetching notifications.');
        }
    };

    const deleteNotification = async (id) => {
        console.log('Deleting notification with ID:', id, typeof id);
        try {
            await axios.delete(`http://localhost:8085/api/v1/notification/${id}`, {
                headers: {
                    'X-UUID': uuid,
                    'Authorization': `Bearer ${token}`,
                },
            });

            setNotifications((prevNotifications) =>
                prevNotifications.filter((notification) => notification.notificationId !== id)
            );
            setNotificationCount((prevCount) => prevCount - 1);
            console.log('Notification deleted successfully');
        } catch (error) {
            console.error('Error deleting notification:', error);
            console.error("Delete notifications error: ", error.response);
            setNotificationMessage('Error deleting notification.');
        }
    };

    const starNotification = async (id) => {
        console.log('Starring notification with ID:', id, typeof id);
        try {
            const response = await axios.put(`http://localhost:8085/api/v1/notification/star/${id}`, {}, {
                headers: {
                    'Authorization': `Bearer ${token}`
                },
            });
            console.log("Star Notification Response: ", response);

            if (response.status === 200) {
                setNotifications((prevNotifications) => {
                    const updatedNotifications = prevNotifications.map((notification) =>
                        notification.notificationId === id
                            ? { ...notification, starred: !notification.starred }
                            : notification
                    );
                    // Re-sort after toggling the starred status: starred first, then by timestamp
                    const sortedNotifications = [...updatedNotifications].sort((a, b) => {
                        if (a.starred && !b.starred) return -1;
                        if (!a.starred && b.starred) return 1;
                        return compareTimestamps(a, b);
                    });
                    console.log("Sorted Notifications after star:", sortedNotifications);
                    return sortedNotifications;
                });
            } else {
                console.error('API call failed: ', response);
                setNotificationMessage('Error starring notification: API call failed.');
            }
        } catch (error) {
            console.error('Error starring notification:', error);
            console.error("Star notifications error: ", error.response);
            setNotificationMessage('Error starring notification.');
        }
    };

    return (
        <div className="notification-page">
            <div className="notification-button" onClick={() => setShowPopup(true)}>
                <i className="bi bi-bell notification-icon"></i>
                {notificationCount > 0 && <span className="notification-count">{notificationCount}</span>}
            </div>

            {showPopup && (
                <div className="notification-popup" ref={popupRef}>
                    <i className="bi bi-x close-icon" onClick={() => setShowPopup(false)}></i>
                    <div className="notification-content">
                        <h2 className="notification-heading">Notifications</h2>
                        {notificationMessage && <p>{notificationMessage}</p>}
                        <div className="notifications-list">
                            {notifications.map((notification) => (
                                <NotificationItem
                                    key={notification.notificationId}
                                    notification={notification}
                                    starNotification={starNotification}
                                    deleteNotification={deleteNotification}
                                />
                            ))}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default NotificationPage;