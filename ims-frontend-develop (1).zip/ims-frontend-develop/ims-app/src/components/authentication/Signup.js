import React, { useState } from 'react';
import './Signup.css';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import details from '../admin/Properties';

const Signup = () => {
  const [role, setRole] = useState('AGENT');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    address: '',
    contactInfo: '',
    adminId: details.admin,
  });
  const [errors, setErrors] = useState({});
  const [generalError, setGeneralError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const navigate = useNavigate();

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    setErrors({ ...errors, [name]: '' });
    setGeneralError('');
  };

  const validate = () => {
    const newErrors = {};
    const nameRegex = /^[a-zA-Z\s]*$/;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    const phoneRegex = /^\d{10}$/;
    const contactInfoRegex = /^\d{10}$/;

    if (!formData.name.trim()) {
      newErrors.name = 'Name is required.';
    } else if (!nameRegex.test(formData.name)) {
      newErrors.name = 'Name should only contain letters and spaces.';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email is required.';
    } else if (!emailRegex.test(formData.email)) {
      newErrors.email = 'Invalid email format.';
    }

    if (!formData.password.trim()) {
      newErrors.password = 'Password is required.';
    } else if (!passwordRegex.test(formData.password)) {
      newErrors.password =
        'Password must be at least 8 characters and include one lowercase, one uppercase, one number, and one special character.';
    }

    if (role === 'CUSTOMER') {
      if (!formData.phone.trim()) {
        newErrors.phone = 'Phone number is required.';
      } else if (!phoneRegex.test(formData.phone)) {
        newErrors.phone = 'Phone number must be exactly 10 digits.';
      }

      if (!formData.address.trim()) {
        newErrors.address = 'Address is required.';
      }
    }

    if (role === 'AGENT') {
      if (!formData.contactInfo.trim()) {
        newErrors.contactInfo = 'Contact Info is required.';
      } else if (!contactInfoRegex.test(formData.contactInfo)) {
        newErrors.contactInfo = 'Contact Info must be exactly 10 digits.';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (validate()) {
      const url =
        role === 'AGENT'
          ? 'http://localhost:8086/api/v1/users/register-agent'
          : 'http://localhost:8086/api/v1/users/register-customer';
      const payload =
        role === 'AGENT'
          ? {
              name: formData.name,
              email: formData.email,
              password: formData.password,
              contactInfo: formData.contactInfo,
              adminId: formData.adminId || 'a23b020f-406d-4cff-b858-0ea4b93cebe1',
            }
          : { name: formData.name, email: formData.email, password: formData.password, phone: formData.phone, address: formData.address };

      try {
        const response = await axios.post(url, payload);
        setSuccessMessage('Registration Successful!');
        setErrors({});
        setGeneralError('');
        console.log('Success:', response.data);
        setTimeout(() => {
          navigate('/Login'); // Navigate to the login page
        }, 2000);
      } catch (err) {
        console.error('Registration Failed:', err);
        console.error('Error Response:', err.response);
        console.error('Error Response Data:', err.response?.data);
        const backendErrors = err.response?.data || {};
        console.error('Backend Errors:', backendErrors);
        setErrors(backendErrors);
        setGeneralError(err.response?.data?.message || 'Registration failed. Please try again.');
        setSuccessMessage('');
      }
    }
  };

  return (
    <div className="sign-up">
      <main className="form-signin w-100 m-auto">
        <form onSubmit={handleSubmit} noValidate>
          <h1 className="h3 mb-3 fw-normal text-center">
            Register as {role}
          </h1>

          {/* Role Toggle Buttons */}
          <ul
            className="nav nav-pills nav-fill gap-2 p-1 small bg-secondary rounded-5 shadow-sm"
            id="pillNav2"
            role="tablist"
            style={{
              '--bs-nav-link-color': 'var(--bs-white)',
              '--bs-nav-pills-link-active-color': 'var(--bs-secondary)',
              '--bs-nav-pills-link-active-bg': 'var(--bs-white)',
            }}
          >
            <li className="nav-item" role="presentation">
              <button
                type="button"
                className={`nav-link ${role === 'AGENT' ? 'active' : ''} rounded-5`}
                onClick={() => setRole('AGENT')}
                aria-selected={role === 'AGENT'}
              >
                Agent
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                type="button"
                className={`nav-link ${role === 'CUSTOMER' ? 'active' : ''} rounded-5`}
                onClick={() => setRole('CUSTOMER')}
                aria-selected={role === 'CUSTOMER'}
              >
                Customer
              </button>
            </li>
          </ul>

          <br />

          {/* Form Fields */}

          {/* Name */}
          <div className="col-md-6 w-100 mb-1">
            <div className="input-group">
              <input
                type="text"
                name="name"
                className={`form-control ${errors.name ? 'is-invalid' : ''}`}
                id="floatingName"
                placeholder="Full Name"
                value={formData.name}
                onChange={handleInputChange}
                required
                aria-label="Input group example"
                aria-describedby="basic-addon1"
              />
              {errors.name && <div className="invalid-feedback">{errors.name}</div>}
            </div>
          </div>

          {/* Email */}
          <div className="col-md-6 w-100 mb-1">
            <div className="input-group">
              <input
                type="email"
                name="email"
                className={`form-control ${errors.email ? 'is-invalid' : ''}`}
                id="floatingEmail"
                placeholder="Email"
                value={formData.email}
                onChange={handleInputChange}
                required
                aria-label="Input group example"
                aria-describedby="basic-addon1"
              />
              {errors.email && <div className="invalid-feedback">{errors.email}</div>}
            </div>
          </div>

          {/* Password */}
          <div className="col-md-6 w-100 mb-1">
            <div className="input-group">
              <input
                type="password"
                name="password"
                className={`form-control ${errors.password ? 'is-invalid' : ''}`}
                id="floatingPassword"
                placeholder="Password"
                value={formData.password}
                onChange={handleInputChange}
                required
                aria-label="Input group example"
                aria-describedby="basic-addon1"
              />
              {errors.password && <div className="invalid-feedback">{errors.password}</div>}
            </div>
          </div>

          {role === 'CUSTOMER' && (
            <>
              {/* Mobile Number */}
              <div className="col-md-6 w-100 mb-1">
                <div className="input-group">
                  <input
                    type="tel"
                    name="phone"
                    className={`form-control ${errors.phone ? 'is-invalid' : ''}`}
                    id="floatingPhone"
                    placeholder="Phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    required
                    aria-label="Input group example"
                    aria-describedby="basic-addon1"
                  />
                  {errors.phone && <div className="invalid-feedback">{errors.phone}</div>}
                </div>
              </div>

              {/* Address */}
              <div className="col-md-6 w-100 mb-1">
                <div className="input-group">
                  <input
                    type="text"
                    name="address"
                    className={`form-control ${errors.address ? 'is-invalid' : ''}`}
                    id="floatingAddress"
                    placeholder="Address"
                    value={formData.address}
                    onChange={handleInputChange}
                    required
                    aria-label="Input group example"
                    aria-describedby="basic-addon1"
                  />
                  {errors.address && <div className="invalid-feedback">{errors.address}</div>}
                </div>
              </div>
            </>
          )}

          {role === 'AGENT' && (
            <div className="col-md-6 w-100 mb-1">
              <div className="input-group">
                <input
                  type="text"
                  name="contactInfo"
                  className={`form-control ${errors.contactInfo ? 'is-invalid' : ''}`}
                  id="floatingContactInfo"
                  placeholder="Contact Info"
                  value={formData.contactInfo}
                  onChange={handleInputChange}
                  required
                  aria-label="Input group example"
                  aria-describedby="basic-addon1"
                />
                {errors.contactInfo && <div className="invalid-feedback">{errors.contactInfo}</div>}
              </div>
            </div>
          )}

          <br />

          {/* Submit Button */}
          <button className="btn btn-secondary w-100 py-2 mb-2" type="submit">
            Register
          </button>

          {/* Render general error message */}
          {generalError && <p className="text-danger text-center">{generalError}</p>}

          {/* Render success message */}
          {!generalError && successMessage && <p className="text-success text-center">{successMessage}</p>}

          <p className="text-center">
            Already have an account?{' '}
            <Link to="/Login" className="custom-signup-link">
              Login
            </Link>
          </p>
        </form>
      </main>
    </div>
  );
};

export default Signup;