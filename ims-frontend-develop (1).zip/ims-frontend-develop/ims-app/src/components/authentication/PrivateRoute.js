
import React from 'react';
import { Navigate } from 'react-router-dom';
 
const PrivateRoute = ({ children, allowedRole }) => {
  const token = localStorage.getItem('userToken');
  const userRole = localStorage.getItem('userRole');
  const logoutFlag = sessionStorage.getItem('logoutFlag'); 
  
  if (logoutFlag) {
    console.log("Redirecting due to logout, suppressing alert.");
    return <Navigate to="/Login" />;
  }
 
  
  if ((!token && !logoutFlag) || (userRole !== allowedRole && !logoutFlag)) {
    const roleMessage = allowedRole === 'ADMIN' ? 'Admin' : allowedRole === 'AGENT' ? 'Agent' : allowedRole === 'CUSTOMER' ? 'Customer' : 'User';
   
    alert(`Please login as a ${roleMessage} to access this page.`);
    return <Navigate to="/Login" />;
  }
 
  return children;
};
 
export default PrivateRoute;
 
 