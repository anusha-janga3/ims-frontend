import React from 'react';
import { useNavigate } from 'react-router-dom';
import './FooterStyle.css';
 
const CustomerFooter = () => {
    const navigate = useNavigate();
    const userRole = localStorage.getItem('userRole'); // Get logged-in user's role
 
    // Define dashboard routes dynamically based on user role
    const getDashboardRoute = () => {
        switch (userRole) {
            case 'ADMIN':
                return '/admindashboard';
            case 'AGENT':
                return '/agentdashboard';
            case 'CUSTOMER':
                return '/dashboard';
            default:
                return '/dashboard'; // Default fallback
        }
    };
 
    return (
        <footer className="customer-footer">
            <div className="footer-content">
                <div className="footer-section">
                    <h4>About Us</h4>
                    <p>Your trusted partner for all your insurance needs.</p>
                </div>
                <div className="footer-section">
                    <h4>Contact Us</h4>
                    <p>Email: support@insurancecompany.com</p>
                    <p>Phone: +91 1234567890</p>
                    <p>Address: 123 Main Street, Chennai, India</p>
                </div>
                <div className="footer-section">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href={getDashboardRoute()}>Home</a></li>
                        {userRole === 'CUSTOMER' && (
                            <>
                                <li><a href="/dashboard/policies/view">My Policies</a></li>
                                <li><a href="/dashboard/claims/submit">File a Claim</a></li>
                                <li><a href="/dashboard/support">Support</a></li>
                            </>
                        )}
                        {userRole === 'AGENT' && (
                            <>
                                <li><a href="/agent/customers">Manage Customers</a></li>
                                <li><a href="/agent/policies">Policies</a></li>
                                <li><a href="/agent/claims">Claim Approvals</a></li>
                            </>
                        )}
                        {userRole === 'ADMIN' && (
                            <>
                                <li><a href="/agents">Manage Agents</a></li>
                                <li><a href="/policies">Manage Policies</a></li>
                                <li><a href="/assign-policy">Assign Policy</a></li>
                            </>
                        )}
                    </ul>
                </div>
                <div className="footer-bottom">
                    <p>&copy; {new Date().getFullYear()} Insurance Company. All rights reserved.</p>
                </div>
            </div>
        </footer>
    );
};
 
export default CustomerFooter;
 
 