// CustomerDetails.js
import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser, faEnvelope, faPhone, faMapMarkerAlt ,faIdCard } from '@fortawesome/free-solid-svg-icons';

const CustomerDetails = ({ customer }) => {
    if (!customer) {
        return <div className="card shadow-sm">No customer data available.</div>;
    }

    return (
        <>
       
        <div className="card shadow-sm">
            <div className="card-header bg-primary text-light blue-header">
                <FontAwesomeIcon icon={faUser} className="me-2" />
                <strong>{customer.name || 'N/A'}</strong>
            </div>
            <div className="card-body">
                <ul className="list-group list-group-flush">
                
                    {customer.email && (
                        <li className="list-group-item d-flex align-items-center">
                            <FontAwesomeIcon icon={faEnvelope} className="me-3 text-muted" />
                            <span className="fw-bold">Email:</span> <span className="ms-2">{customer.email}</span>
                        </li>
                    )}
                    {customer.phone && (
                        <li className="list-group-item d-flex align-items-center">
                            <FontAwesomeIcon icon={faPhone} className="me-3 text-muted" />
                            <span className="fw-bold">Phone:</span> <span className="ms-2">{customer.phone}</span>
                        </li>
                    )}
                    {customer.address && (
                        <li className="list-group-item d-flex align-items-start">
                            <FontAwesomeIcon icon={faMapMarkerAlt} className="me-3 text-muted" />
                            <span className="fw-bold">Address:</span> <span className="ms-2">{customer.address}</span>
                        </li>
                    )}
                    {/* Add other customer details you want to display here */}
                </ul>
            </div>
        </div>
        </>
    );
};

export default CustomerDetails;