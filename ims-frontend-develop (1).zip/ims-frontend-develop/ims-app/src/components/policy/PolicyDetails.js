// import React from "react";
// import "./PolicyDetails.css"; // Import the CSS file for styling

// function PolicyDetails({ policyDetails }) {
//   if (!policyDetails) {
//     return <p>No policy details available.</p>;
//   }

//   return (
//     <div className="policy-card">
//       <h3>Policy Details</h3>
//       {policyDetails.policyId && <p><strong>Policy ID:</strong> {policyDetails.policyId}</p>}
//       {policyDetails.name && <p><strong>Policy Name:</strong> {policyDetails.name}</p>}
//       {policyDetails.coverageDetails && <p><strong>Coverage Details:</strong> {policyDetails.coverageDetails}</p>}
//       {policyDetails.premiumAmount && <p><strong>Premium:</strong> ₹{policyDetails.premiumAmount.toFixed(2)}</p>}
//       {policyDetails.validityPeriod && <p><strong>Validity Period:</strong> {policyDetails.validityPeriod} years</p>}
//       {policyDetails.agentId && (
//         <p><strong>Agent Id:</strong> {policyDetails.agentId}</p>
//       )}
//       {policyDetails.purchaseDate && (
//         <p><strong>Purchase Date:</strong> {new Date(policyDetails.purchaseDate).toLocaleString()}</p>
//       )}
//     </div>
//   );
// }

// export default PolicyDetails;

import React from "react";
import "./PolicyDetails.css"; // Import the CSS file for styling

function PolicyDetails({ policyDetails }) {
  if (!policyDetails) {
    return <p>No policy details available.</p>;
  }

  return (
    <div className="policy-card">
      {policyDetails.name && <h3>{policyDetails.name}</h3>}
      {policyDetails.coverageDetails && <p><strong>Coverage Details:</strong> {policyDetails.coverageDetails}</p>}
      {policyDetails.premiumAmount && <p><strong>Premium:</strong> ₹{policyDetails.premiumAmount.toFixed(2)}</p>}
      {policyDetails.validityPeriod && <p><strong>Validity Period:</strong> {policyDetails.validityPeriod} years</p>}

      {policyDetails.agentName && <p><strong>Agent Name:</strong> {policyDetails.agentName}</p>}
      {policyDetails.agentContactInfo && <p><strong>Agent Contact Info:</strong> {policyDetails.agentContactInfo}</p>}
      {policyDetails.purchaseDate && (
        <p><strong>Purchase Date:</strong> {new Date(policyDetails.purchaseDate).toLocaleString()}</p>
      )}
    </div>
  );
}

export default PolicyDetails;
