import React, { useState, useEffect } from 'react';
import PolicyCard from '../layout/PolicyCard';
import '../layout/CustomerDashboard.css'; // Styles for the dashboard content (you might want to rename this)
import CustomerNavbar from '../layout/CustomerNavbar'; // Navigation bar

const TEST_TOKEN = localStorage.getItem('userToken'); // Replace with your actual test token

const RegisterPolicy = () => {
  const [allPolicies, setAllPolicies] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchAllPolicies();
  }, []); 

  const fetchAllPolicies = async () => {
    setLoading(true);
    setError(null);
    setAllPolicies([]);
    try {
      const url = '/api/v1/policies'; // Adjust the API endpoint if needed
      const response = await fetch(url, {
        headers: {
          Authorization: `Bearer ${TEST_TOKEN}`,
        },
      });

      if (response.ok) {
        const responseData = await response.json();
        // Assuming the backend returns policies with agentId, you'll need to fetch agent details for each policy
        const policiesWithAgentInfo = await Promise.all(
          responseData.data.map(async (policy) => {
            try {
              const agentResponse = await fetch(`/api/v1/agents/${policy.agentId}`, {
                headers: {
                  Authorization: `Bearer ${TEST_TOKEN}`,
                },
              });
              if (agentResponse.ok) {
                const agentData = await agentResponse.json();
                return { ...policy, agent: agentData.data };
              } else {
                console.warn(`Could not fetch agent for policy ID ${policy.policyId}: ${agentResponse.statusText}`);
                return { ...policy, agent: null };
              }
            } catch (agentError) {
              console.error(`Error fetching agent for policy ID ${policy.policyId}:`, agentError);
              return { ...policy, agent: null };
            }
          })
        );
        setAllPolicies(policiesWithAgentInfo || []);
      } else {
        throw new Error(`Error fetching all policies: ${response.statusText}`);
      }
    } catch (error) {
      console.error('Error fetching all policies:', error);
      setError('An error occurred while fetching all policies.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="dashboard-layout"> {/* Consider renaming this class if it's specific to the policy registration page */}
      <div className="background-image"></div> {/* Consider if you need this on a registration page */}
      <header className="transparent-header">
        <CustomerNavbar /> {/* Keep the navbar if users need navigation */}
      </header>
      <div className="dashboard-content" style={{ maxWidth: '1200px', margin: '20px auto', padding: '20px' }}> {/* Consider renaming this class */}
        <h2>Register for Policies</h2> {/* Update the heading */}
        {loading && <p>Loading policies...</p>}
        {error && <p className="error-message">Error: {error}</p>}
        <section className="policies-grid"> {/* Keep this class for styling the grid */}
          {!loading && !error && allPolicies.length > 0 ? (
            allPolicies.map((policy) => (
              <PolicyCard key={policy.policyId} policy={policy} />
            ))
          ) : (
            !loading && !error && <p>No policies found.</p>
          )}
        </section>
      </div>
    </div>
  );
};

export default RegisterPolicy;