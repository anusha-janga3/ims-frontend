// import React from 'react';
// import { Link, useNavigate } from 'react-router-dom';
// import { FaHome, FaSignOutAlt } from 'react-icons/fa'; // Import icons
// import 'bootstrap/dist/css/bootstrap.min.css';

// import './AgentNavBar.css'; // Scoped CSS file for AgentNav

// const AgentNav = () => {

//   const navigate = useNavigate();

//   const handleLogout = () => {
//     // Clear token, userId, and role from localStorage
//     localStorage.removeItem('userToken');
//     localStorage.removeItem('userId');
//     localStorage.removeItem('userRole');
//     console.log('User logged out and local storage cleared.');

//     // Navigate back to the login page
//     navigate('/');
//   };

//   return (
//     <>
//     <header className="transparent-header">
//                     <AgentNav />
//                 </header>
//       <div className="agent-navbar-left">
//         <Link to="/" className="agent-navbar-logo">
//           <img
//             src=""
//             alt="Your Logo"
//             className="img-fluid"
//             style={{ maxHeight: '30px', maxWidth: '80px', height: 'auto' }}
//           />
//         </Link>
//         <span className="agent-app-name">Insurance Management System</span>
//       </div>
//       <div className="agent-navbar-right">
//         <ul className="agent-navbar-menu">
//           <li className="agent-navbar-item">
//             <Link to="/agentdashboard" className="agent-navbar-link">
//               <FaHome className="agent-navbar-icon" /> Home
//             </Link>
//           </li>
//           <li className="agent-navbar-item">
//             <Link to="#" className="agent-navbar-link" onClick={handleLogout}>
//               <FaSignOutAlt className="agent-navbar-icon" /> Logout
//             </Link>
//           </li>
//         </ul>
//       </div>
//     </>
//   );
// };

// export default AgentNav;

import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FaHome, FaSignOutAlt } from 'react-icons/fa'; // Import icons
import 'bootstrap/dist/css/bootstrap.min.css';

import './AgentNavBar.css'; // Scoped CSS file for AgentNav

const AgentNav = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('userToken');
    localStorage.removeItem('userId');
    localStorage.removeItem('userRole');
    sessionStorage.setItem('logoutFlag', 'true');
 
    console.log("Logout initiated. Flag set:", sessionStorage.getItem('logoutFlag'));
 
    window.location.href = '/Login'; // ✅ Redirect to Login
  };
 
  return (
    <nav className="agent-navbar"> {/* Changed <header> to <nav> for semantic correctness of navigation */}
      <div className="agent-navbar-left">
        <Link to="/agentdashboard" className="agent-navbar-logo"> {/* Assuming /agentdashboard is the agent's home */}
          
        </Link>
        <span className="agent-app-name">Insurance Management System</span>
      </div>
      <div className="agent-navbar-right">
        <ul className="agent-navbar-menu">
          <li className="agent-navbar-item">
            <Link to="/agentdashboard" className="agent-navbar-link">
              <FaHome className="agent-navbar-icon" /> Home
            </Link>
          </li>
          <li className="agent-navbar-item">
            <Link to="#" className="agent-navbar-link" onClick={handleLogout}>
              <FaSignOutAlt className="agent-navbar-icon" /> Logout
            </Link>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default AgentNav;
