import React from 'react';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS
import './AgentDashboard.css';
import AgentNav from './AgentNavBar'; // Ensure AgentNav uses updated styling

function AgentDashboard() {
  const agentId = localStorage.getItem('userId'); // Example: Get agent ID from local storage

  return (
    <>
       <header className="transparent-header bg-white">
                <AgentNav />
            </header>
      <div className="agent-dashboard-container mt-5">
        <h1 className="agent-dashboard-heading mb-4">Hi Agent !!</h1>
        <div className="row row-cols-1 row-cols-md-3 g-4">
          <div className="col">
            <div className="agent-dashboard-card h-100">
              <div className="card-body text-center">
                <h5 className="agent-dashboard-card-title">Customers</h5>
                <p className="agent-dashboard-card-text">View your assigned customers</p>
                <Link to={`/agent/customers`} className="agent-dashboard-btn btn btn-primary">
                  View Customers
                </Link>
              </div>
            </div>
          </div>
          <div className="col">
            <div className="agent-dashboard-card h-100">
              <div className="card-body text-center">
                <h5 className="agent-dashboard-card-title">Claims</h5>
                <p className="agent-dashboard-card-text">View and manage your assigned claims</p>
                <Link to={`/agent/claims`} className="agent-dashboard-btn btn btn-info">
                  View Claims
                </Link>
              </div>
            </div>
          </div>
          <div className="col">
            <div className="agent-dashboard-card h-100">
              <div className="card-body text-center">
                <h5 className="agent-dashboard-card-title">Policies</h5>
                <p className="agent-dashboard-card-text">View the policies you are responsible for</p>
                <Link to={`/agent/policies`} className="agent-dashboard-btn btn btn-success">
                  View Policies
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default AgentDashboard;
