import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FaHome, FaSignOutAlt } from 'react-icons/fa';
import 'bootstrap/dist/css/bootstrap.min.css';

import './AdminNavBar.css';

const AdminNavBar = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('userToken');
    localStorage.removeItem('userId');
    localStorage.removeItem('userRole');
 
    sessionStorage.setItem('logoutFlag', 'true'); // ✅ Set logout flag
 
    console.log("Logout initiated. Flag set:", sessionStorage.getItem('logoutFlag'));
 
    window.location.href = '/Login'; // ✅ Redirect to Login
  };
 

  return (
    <nav className="admin-nav">
      <div className="admin-nav-left">
        <Link to="/" className="admin-nav-logo">
         
        </Link>
        <span className="agent-app-name">Insurance Management System</span>
      </div>
      <div className="admin-nav-right">
        <ul className="admin-nav-menu">
          <li className="admin-nav-item">
            <Link to="/admindashboard" className="admin-nav-link">
              <FaHome className="admin-nav-icon" /> Home
            </Link>
          </li>
          <li className="admin-nav-item">
            <Link to="#" className="admin-nav-link" onClick={handleLogout}>
              <FaSignOutAlt className="admin-nav-icon" /> Logout
            </Link>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default AdminNavBar;