

// import React, { useState } from 'react';
// import './PolicyCard.css'; // Importing the dedicated CSS file

// const AUTH_TOKEN = localStorage.getItem('userToken');

// function PolicyCard({ policy }) {
//   const [showPopup, setShowPopup] = useState(false);
//   const [agent, setAgent] = useState(null);
//   const [error, setError] = useState(null);

//   const handleViewDetailsClick = () => {
//     setShowPopup(true);
//     fetchAssignedPolicyDetails();
//   };

//   const handleClosePopup = () => {
//     setShowPopup(false);
//   };

//   const fetchAssignedPolicyDetails = async () => {
//     setError(null);

//     try {
//       const url = '/api/v1/assigned-policy';
//       const response = await fetch(url, {
//         headers: {
//           Authorization: `Bearer ${AUTH_TOKEN}`,
//         },
//       });
//       const data = await response.json();

//       const assignment = data.data.find(
//         (item) => item.policyId === policy.policyId
//       );

//       if (assignment) {
//         const agentResponse = await fetch(`/api/v1/agents/${assignment.agentId}`, {
//           headers: {
//             Authorization: `Bearer ${AUTH_TOKEN}`,
//           },
//         });
//         const agentData = await agentResponse.json();
//         setAgent(agentData.data);
//       } else {
//         setAgent(null);
//       }
//     } catch (err) {
//       console.error('Error fetching assigned policy details:', err);
//       setError('Failed to load agent details. Please try again.');
//     }
//   };

//   const handlePurchasePolicy = async () => {
//     if (!agent) {
//       alert('No agent is assigned to this policy.');
//       return;
//     }

//     try {
//       const userId = localStorage.getItem('userId');
//       const purchaseUrl = 'http://localhost:8082/api/v1/policies/purchase';
//       console.log(JSON.stringify({
//         policyId: policy.policyId,
//         customerId: userId,
//         agentId: agent.agentId,
//       }));
//       const response = await fetch(purchaseUrl, {
//         method: 'POST',
//         headers: {
//           'Content-Type': 'application/json',
//           Authorization: `Bearer ${AUTH_TOKEN}`,
//         },
//         body: JSON.stringify({
//           policyId: policy.policyId,
//           customerId: userId,
//           agentId: agent.agentId,
//         }),
//       });

//       if (response.ok) {
//         alert('Policy purchased successfully!');
//         handleClosePopup();
//       } else {
//         const errorData = await response.json();
//         setError(`Failed to purchase policy: ${errorData.message}`);
//       }
//     } catch (error) {
//       console.error('Error purchasing policy:', error);
//       setError('An unexpected error occurred while purchasing the policy.');
//     }
//   };

//   return (
//     <div className="policy-card-container">
//       <div className="policy-name">
//         {policy.name}
//       </div>
//       <div className="policy-field">
//         <strong>Premium Amount:</strong> {policy.premiumAmount}
//       </div>
//       <div className="policy-field">
//         <strong>Validity Period:</strong> {policy.validityPeriod} Years
//       </div>
//       <div className="policy-field">
//         <strong>Coverage Details:</strong> {policy.coverageDetails}
//       </div>

//       <div className="policy-field">
//         <button className="view-details-button" onClick={handleViewDetailsClick}>
//           View More Details
//         </button>
//       </div>

//       {showPopup && (
//         <div className="policy-popup-overlay">
//           <div className="policy-popup-box">
//             <button className="policy-close-button" onClick={handleClosePopup}>
//               &times;
//             </button>

//             <div className="policy-name"><strong></strong> {policy.name}</div>
//             <div className="policy-field" style={{ marginLeft: '25px' }}><strong>Policy ID:</strong> {policy.policyId}</div>
//             <div className="policy-field" style={{ marginLeft: '25px' }}><strong>Premium Amount:</strong> {policy.premiumAmount}</div>
//             <div className="policy-field" style={{ marginLeft: '25px' }}><strong>Validity Period:</strong> {policy.validityPeriod} Years</div>
//             <div className="policy-field" style={{ marginLeft: '25px' }}><strong>Coverage Details:</strong> {policy.coverageDetails}</div>
//             {error && <div className="error-message">{error}</div>}
//             {agent ? (
//               <>
//                 <div className="policy-field" style={{ marginLeft: '25px' }}><strong>Agent Name:</strong> {agent.name}</div>
//                 <div className="policy-field" style={{ marginLeft: '25px' }}><strong>Agent Phone Number:</strong> {agent.contactInfo}</div>
//               </>
//             ) : (
//               <div className="policy-field">No agent assigned for this policy.</div>
//             )}
//             <button className="policy-purchase-button" onClick={handlePurchasePolicy}>
//               Purchase Policy
//             </button>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// }

// export default PolicyCard;

import React, { useState } from 'react';
import './PolicyCard.css'; // Importing the dedicated CSS file
import axios from 'axios';
 
const AUTH_TOKEN = localStorage.getItem('userToken');

function PolicyCard({ policy }) {
  const [showPopup, setShowPopup] = useState(false);
  const [agent, setAgent] = useState(null);
  const [error, setError] = useState(null);
  const [isAgentAssigned, setIsAgentAssigned] = useState(true); // Assume initially assigned

  const handleViewDetailsClick = () => {
    setShowPopup(true);
    fetchAssignedPolicyDetails();
  };

  const handleClosePopup = () => {
    setShowPopup(false);
  };

  const fetchAssignedPolicyDetails = async () => {
    setError(null);

    try {
      const url = '/api/v1/assigned-policy';
      const response = await axios.get(url, {
        headers: {
          Authorization: `Bearer ${AUTH_TOKEN}`,
        },
      });
      const data = response.data;
 
      const assignment = data.data.find(
        (item) => item.policyId === policy.policyId
      );
 
      if (assignment) {
        const agentResponse = await axios.get(`/api/v1/agents/${assignment.agentId}`, {
          headers: {
            Authorization: `Bearer ${AUTH_TOKEN}`,
          },
        });
        setAgent(agentResponse.data.data);
      } else {
        setAgent(null);
      }
    } catch (err) {
      console.error('Error fetching assigned policy details:', err);
      setError('Failed to load agent details. Please try again.');
    }
  };
 

  const handlePurchasePolicy = async () => {
    if (!agent) {
      alert('No agent is assigned to this policy , Soon we will assign !');
      return;
    }

    try {
      const userId = localStorage.getItem('userId');
      const purchaseUrl = 'http://localhost:8082/api/v1/policies/purchase';
 
      console.log(JSON.stringify({
        policyId: policy.policyId,
        customerId: userId,
        agentId: agent.agentId,
      }));
      console.log(AUTH_TOKEN);
      const response = await axios.post(purchaseUrl, {
        policyId: policy.policyId,
        customerId: userId,
        agentId: agent.agentId,
      }, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${AUTH_TOKEN}`,
        },
      });
     
 
      if (response.status === 201) {
        alert('Policy purchased successfully!');
        handleClosePopup();
      }
     
      if (response.status === 400) {
        alert('Policy already purchased');
        handleClosePopup();
      } else {
        const errorData = response.data;
        setError(`Failed to purchase policy: ${errorData.message || response.statusText}`);
      }
    } catch (error) {
      if (error.status === 400) {
        setError('Policy already purchased');
      }
      else {
      console.error('Error purchasing policy:', error.message.message);
      setError('An unexpected error occurred while purchasing the policy.');
      }
    }
  };
 

  return (
    <div
      className={`policy-card-container ${!isAgentAssigned ? 'no-agent' : ''}`}
    >
      <div className="policy-name">
        {policy.name}
      </div>
      <div className="policy-field">
        <strong>Premium Amount:</strong> {policy.premiumAmount}
      </div>
      <div className="policy-field">
        <strong>Validity Period:</strong> {policy.validityPeriod} Years
      </div>
      <div className="policy-field">
        <strong>Coverage Details:</strong> {policy.coverageDetails}
      </div>

      <div className="policy-field">
        <button className="view-details-button" onClick={handleViewDetailsClick}>
          View More Details
        </button>
      </div>

      {showPopup && (
        <div className="policy-popup-overlay">
          <div className="policy-popup-box">
            <button className="policy-close-button" onClick={handleClosePopup}>
              &times;
            </button>

            <div className="policy-name"><strong></strong> {policy.name}</div>
            <div className="policy-field" style={{ marginLeft: '25px' }}><strong>Premium Amount:</strong> {policy.premiumAmount}</div>
            <div className="policy-field" style={{ marginLeft: '25px' }}><strong>Validity Period:</strong> {policy.validityPeriod} Years</div>
            <div className="policy-field" style={{ marginLeft: '25px' }}><strong>Coverage Details:</strong> {policy.coverageDetails}</div>
            {error && <div className="error-message">{error}</div>}
            {agent ? (
              <>
                <div className="policy-field" style={{ marginLeft: '25px' }}><strong>Agent Name:</strong> {agent.name}</div>
                <div className="policy-field" style={{ marginLeft: '25px' }}><strong>Agent Phone Number:</strong> {agent.contactInfo}</div>
              </>
            ) : (
              <div className="policy-field">No agent assigned for this policy.</div>
            )}
            <button className="policy-purchase-button" onClick={handlePurchasePolicy}>
              Purchase Policy
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default PolicyCard;
 