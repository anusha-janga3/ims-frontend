 
 import { useState, useEffect } from 'react';
 import axios from 'axios';
 import 'bootstrap/dist/css/bootstrap.min.css';
 import { useParams, useNavigate, Link } from 'react-router-dom';
 import AdminNavBar from '../layout/AdminNavBar';
  
 const BASE_AGENT_UPDATE = 'http://localhost:8084/api/v1/agents/update';
 const EditAgent = () => {
   const { agentId } = useParams();
   const navigate = useNavigate();
   const [agent, setAgent] = useState({
     name: '',
     email: '',
     contactInfo: ''
  
   });
   const [error, setError] = useState('');
   const [loading, setLoading] = useState(true);
   const [saving, setSaving] = useState(false);
   const [message, setMessage] = useState('');
   const [contactInfoError, setContactInfoError] = useState('');
   const [nameError, setNameError] = useState('');
  
   useEffect(() => {
     fetchAgentDetailsWithSecurity();
   }, [agentId]);
  
   const fetchAgentDetailsWithSecurity = async () => {
     setLoading(true);
     setError('');
     const token = localStorage.getItem('userToken');
  
  
     try {
       const response = await axios.get(`/api/v1/agents/${agentId}`, {
         headers: {
           'Authorization': `Bearer ${token}`,
           'Content-Type': 'application/json',
         },
       });
       if (response.data && response.data.success && response.data.data) {
         setAgent(response.data.data);
         setError('');
       } else {
         setError(response.data?.message || `Agent with ID ${agentId} not found.`);
       }
     } catch (error) {
       console.error('Error fetching agent details:', error);
       if (error.response && error.response.status === 401) {
         setError('Unauthorized. Please log in again.');
         localStorage.removeItem('userId');
         localStorage.removeItem('userToken');
         navigate('/login');
       } else if (error.response && error.response.status === 403) {
         setError('Forbidden. You do not have permission to view this agent.');
       } else {
         setError('An unexpected error occurred while fetching agent details.');
       }
     } finally {
       setLoading(false);
     }
   };
  
   const handleChange = (e) => {
     const { name, value } = e.target;
     setAgent(prevState => ({
       ...prevState,
       [name]: value,
     }));
  
     // Real-time validation for contactInfo
     if (name === 'contactInfo') {
       if (!/^\d{10}$/.test(value)) {
         setContactInfoError('Contact Info must be 10 digits.');
       } else {
         setContactInfoError('');
       }
     }
  
     // Real-time validation for name
     if (name === 'name') {
       if (!/^[a-zA-Z\s]*$/.test(value)) {
         setNameError('Name must contain only characters and spaces.');
       } else {
         setNameError('');
       }
     }
   };
  
   const handleSubmit = async (e) => {
     e.preventDefault();
     setSaving(true);
     setError('');
     setMessage('');
     setContactInfoError(''); // Reset error on submit
     setNameError(''); // Reset name error on submit
     const token = localStorage.getItem('userToken');
  
     // Final validation before submitting
     if (!/^[a-zA-Z\s]*$/.test(agent.name)) {
       setNameError('Name must contain only characters and spaces.');
       setSaving(false);
       return;
     }
  
     if (!/^\d{10}$/.test(agent.contactInfo)) {
       setContactInfoError('Contact Info must be 10 digits.');
       setSaving(false);
       return;
     }
  
  
     try {
       const response = await axios.put(`${BASE_AGENT_UPDATE}/${agentId}`, agent, {
         headers: {
           'Authorization': `Bearer ${token}`,
           'Content-Type': 'application/json',
         },
       });
       if (response.data && response.data.success) {
         setMessage(`Agent with ID ${agentId} updated successfully!`);
         setTimeout(() => navigate('/agents'), 1500); // Redirect after successful update
       } else {
         setError(response.data?.message || `Failed to update agent with ID ${agentId}.`);
       }
     }  catch (error) {
      console.error('Error updating agent:', error);
      if (error.response && error.response.status === 401) {
          setError('Unauthorized. Please log in again.');
          localStorage.removeItem('userId');
          localStorage.removeItem('userToken');
          navigate('/login');
      } else if (error.response && error.response.status === 403) {
          setError('Forbidden. You do not have permission to update this agent.');
      } else if (error.response && error.response.status === 309) {
          setError(error.response.data.message || 'Duplicate contact information found.');
      } else {
          setError('An unexpected error occurred while updating the agent.');
      }
  } finally {
      setSaving(false);
  }
   };
  
   if (loading) {
     return <div className="container mt-4"><div className="spinner-border text-primary" role="status"><span className="visually-hidden">Loading...</span></div></div>;
   }
  
   if (error) {
     return <div className="container mt-4"><div className="alert alert-danger">{error} <Link to="/agents" className="alert-link">Go back to Agents</Link></div></div>;
   }
  
   return (
     <>
       <header className="transparent-header bg-white">
         <AdminNavBar />
       </header>
       <div className="container mt-4">
         <h2>Edit Agent</h2>
         {message && <div className="alert alert-success">{message}</div>}
         <form onSubmit={handleSubmit}>
           <div className="mb-3">
             <label htmlFor="name" className="form-label">Name</label>
             <input
               type="text"
               className="form-control"
               id="name"
               name="name"
               value={agent.name}
               onChange={handleChange}
               required
             />
             {nameError && <div className="text-danger">{nameError}</div>}
           </div>
           <div className="mb-3">
             <label htmlFor="contactInfo" className="form-label">Contact Info</label>
             <input
               type="text"
               className="form-control"
               id="contactInfo"
               name="contactInfo"
               value={agent.contactInfo}
               onChange={handleChange}
             />
             {contactInfoError && <div className="text-danger">{contactInfoError}</div>}
           </div>
           <button type="submit" className="btn btn-primary" disabled={saving}>
             {saving ? <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> : 'Save Changes'}
           </button>
           <Link to="/agents" className="btn btn-secondary ms-2">Cancel</Link>
         </form>
       </div>
     </>
   );
 };
  
 export default EditAgent;
  
  