const details ={
    admin :'12c99bb1-ebdd-4180-9957-dc5a0497b405' 
};
export default details;