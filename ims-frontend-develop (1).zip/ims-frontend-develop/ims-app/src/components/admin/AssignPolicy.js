 
// import  { useState, useEffect } from 'react';
// import axios from 'axios';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import { Link, useNavigate } from 'react-router-dom';
// import AdminNavBar from '../layout/AdminNavBar';
 
// const API_BASE_URL = '/api/v1/assigned-policy'; // backend API URL
 
// const AssignPolicy = () => {
//   const [assignedPolicies, setAssignedPolicies] = useState([]);
//   const [agents, setAgents] = useState([]);
//   const [policies, setPolicies] = useState([]);
//   const [assignData, setAssignData] = useState({
//     agentId: '',
//     policyId: '',
//     assignedDate: new Date().toISOString(),
//   });
//   const [error, setError] = useState('');
//   const [message, setMessage] = useState('');
//   const [loadingAssigned, setLoadingAssigned] = useState(true);
//   const [loadingAgents, setLoadingAgents] = useState(true);
//   const [loadingPolicies, setLoadingPolicies] = useState(true);
//   const [assigning, setAssigning] = useState(false);
//   const navigate = useNavigate();
 
//   useEffect(() => {
//     // Simulate setting UUID and token in local storage for testing
//     fetchAllAssignedPoliciesWithSecurity();
//     fetchAllAgentsWithSecurity();
//     fetchAllPoliciesWithSecurity();
//   }, []);
 
//   const fetchAllAssignedPoliciesWithSecurity = async () => {
//     setLoadingAssigned(true);
//     setError('');
//     const token = localStorage.getItem('userToken');
//     try {
//       const response = await axios.get(API_BASE_URL, {
//         headers: {
//           'Authorization': `Bearer ${token}`,
//           'Content-Type': 'application/json',
//         },
//       });
//       if (response.data && response.data.success) {
//         setAssignedPolicies(response.data.data);
//         setError('');
//       } else {
//         setError(response.data?.message || 'Failed to fetch assigned policies.');
//       }
//     } catch (error) {
//       console.error('Error fetching assigned policies:', error);
//       handleAuthError(error);
//     } finally {
//       setLoadingAssigned(false);
//     }
//   };
 
//   const fetchAllAgentsWithSecurity = async () => {
//     setLoadingAgents(true);
//     try {
//       const token = localStorage.getItem('userToken');
//       const response = await axios.get('/api/v1/agents', { // Adjust URL if needed
//         headers: {
//           'Authorization': `Bearer ${token}`,
//           'Content-Type': 'application/json',
//         },
//       });
//       if (response.data && response.data.success && Array.isArray(response.data.data)) {
//         setAgents(response.data.data);
//         setError('');
//       } else {
//         setError(response.data?.message || 'Failed to fetch agents for assignment.');
//       }
//     } catch (error) {
//       console.error('Error fetching agents:', error);
//       handleAuthError(error);
//     } finally {
//       setLoadingAgents(false);
//     }
//   };
 
//   const fetchAllPoliciesWithSecurity = async () => {
//     setLoadingPolicies(true);
//     try {
//       const token = localStorage.getItem('userToken');
//       const response = await axios.get('http://localhost:8082/api/v1/policies', {
//         headers: {
//           'Authorization': `Bearer ${token}`,
//           'Content-Type': 'application/json',
//         },
//       });
//       if (response.data && response.data.success && Array.isArray(response.data.data)) {
//         setPolicies(response.data.data);
//         setError('');
//       } else {
//         setError(response.data?.message || 'Failed to fetch available policies.');
//       }
//     } catch (error) {
//       console.error('Error fetching policies:', error);
//       handleAuthError(error);
//     } finally {
//       setLoadingPolicies(false);
//     }
//   };
 
//   const handleAssignChange = (e) => {
//     const { name, value } = e.target;
//     setAssignData(prevState => ({
//       ...prevState,
//       [name]: value,
//     }));
//   };
 
//   const handleAssignPolicyWithSecurity = async () => {
//     setAssigning(true);
//     setError('');
//     setMessage('');
//     const token = localStorage.getItem('userToken');
//     try {
//       const assignDataToSend = {
//         ...assignData,
//         assignedDate: new Date().toISOString(),
//       };
//       console.log(assignDataToSend);
//       const response = await axios.post('http://localhost:8084/api/v1/assigned-policy/addPolicy', assignDataToSend, {
//         headers: {
//           'Authorization': `Bearer ${token}`,
//           'Content-Type': 'application/json',
//         },
//       });
//       if (response.data && response.data.success) {
//         setMessage('Policy assigned successfully!');
//         fetchAllAssignedPoliciesWithSecurity();
//         setAssignData({ agentId: '', policyId: '', assignedDate: new Date().toISOString() });
//       } else {
//         setError(response.data?.message || 'Failed to assign policy.');
//       }
//     }  catch (error) {
//         console.error('Error assigning policy:', error);
//         if (error.response && error.response.status === 409) {
//           setError(error.response.data?.message || 'This policy is already assigned.');
//         } else {
//           handleAuthError(error);
//        }
//       }
//    finally {
//       setAssigning(false);
//     }
//   };
 
//   const handleAuthError = (error) => {
//     if (error.response && error.response.status === 401) {
//       setError('Unauthorized. Please log in again.');
//       localStorage.removeItem('userId');
//       localStorage.removeItem('userToken');
//       navigate('/login');
//     } else if (error.response && error.response.status === 403) {
//       setError('Forbidden. You do not have permission to perform this action.');
//     } else {
//       setError('An unexpected error occurred.');
//     }
//   };
 
//   return (
//     <>
//      <header className="transparent-header bg-white" >
//     <AdminNavBar />
//       </header>
//     <div className="container mt-4">
//       <h2>Assign Policies to Agents</h2>
 
//       {message && <div className="alert alert-success">{message}</div>}
//       {error && <div className="alert alert-danger">{error}</div>}
 
//       <div className="mb-4">
//         <h3>Assign New Policy</h3>
//         <form onSubmit={(e) => { e.preventDefault(); handleAssignPolicyWithSecurity(); }}>
//           <div className="mb-3">
//             <label htmlFor="agentId" className="form-label">Agent</label>
//             {loadingAgents ? (
//               <div className="spinner-border spinner-border-sm text-primary" role="status"><span className="visually-hidden">Loading agents...</span></div>
//             ) : (
//               <select
//                 className="form-select"
//                 id="agentId"
//                 name="agentId"
//                 value={assignData.agentId}
//                 onChange={handleAssignChange}
//                 required
//               >
//                 <option value="">Select Agent</option>
//                 {agents.map(agent => (
//                   <option key={agent.agentId} value={agent.agentId}>{agent.name} ({agent.agentId})</option>
//                 ))}
//               </select>
//             )}
//           </div>
 
//           <div className="mb-3">
//             <label htmlFor="policyId" className="form-label">Policy</label>
//             {loadingPolicies ? (
//               <div className="spinner-border spinner-border-sm text-primary" role="status"><span className="visually-hidden">Loading policies...</span></div>
//             ) : (
//               <select
//                 className="form-select"
//                 id="policyId"
//                 name="policyId"
//                 value={assignData.policyId}
//                 onChange={handleAssignChange}
//                 required
//               >
//                 <option value="">Select Policy</option>
//                 {policies.map(policy => (
//                   <option key={policy.policyId} value={policy.policyId}>
//                     {policy.name} ({policy.policyId})
//                   </option>
//                 ))}
//               </select>
//             )}
//           </div>
 
//           <button type="submit" className="btn btn-primary" disabled={assigning}>
//             {assigning ? <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> : 'Assign Policy'}
//           </button>
//         </form>
//       </div>
 
//       <hr className="my-4" />
 
//       <div>
//         <h3>Currently Assigned Policies</h3>
//         {loadingAssigned ? (
//           <div className="spinner-border text-primary" role="status"><span className="visually-hidden">Loading assigned policies...</span></div>
//         ) : (
//           <div className="table-responsive">
//             {assignedPolicies.length > 0 ? (
//               <table className="table table-striped table-bordered">
//                 <thead>
//                   <tr>
//                     <th>Assign ID</th>
//                     <th>Policy</th> {/* Combined Policy ID and Name */}
//                     <th>Agent</th>  {/* Combined Agent ID and Name */}
//                     <th>Assignment Date</th>
//                     {/* Add other relevant headers */}
//                   </tr>
//                 </thead>
//                 <tbody>
//                   {assignedPolicies.map(assignment => {
//                     // Find the corresponding agent and policy objects
//                     const agent = agents.find(a => a.agentId === assignment.agentId);
//                     const policy = policies.find(p => p.policyId === assignment.policyId);
                   
 
//                     return (
//                       <tr key={assignment.assignId}>
//                         <td style={{ whiteSpace: 'nowrap' }}> <span>{assignment.assignId}</span></td>
//                         <td style={{ whiteSpace: 'nowrap' }}>
//                           <span> {policy?.name || 'N/A'}
//                             <br />
//                             ({assignment.policyId}) </span>
//                         </td>
//                         <td style={{ whiteSpace: 'nowrap' }}>
//                           <span> {agent?.name || 'N/A'}
//                             <br />
//                             ({assignment.agentId}) </span>
//                         </td>
//                         <td>{new Date(assignment.assignedDate).toLocaleDateString()}</td>
//                         {/* Add other relevant data */}
//                       </tr>
//                     );
//                   })}
//                 </tbody>
//               </table>
//             ) : (
//               <div className="alert alert-info">No policies have been assigned yet.</div>
//             )}
//           </div>
//         )}
//       </div>
//       <Link to="/admindashboard" className="btn btn-secondary mt-3">Back to Home</Link>
//     </div>
//     </>
//   );
// };
 
// export default AssignPolicy;
 
 
// import { useState, useEffect } from 'react';
// import axios from 'axios';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import { Link, useNavigate } from 'react-router-dom';
// import AdminNavBar from '../layout/AdminNavBar';
 
// const API_BASE_URL = '/api/v1/assigned-policy'; // backend API URL
 
// const AssignPolicy = () => {
//   const [assignedPolicies, setAssignedPolicies] = useState([]);
//   const [agents, setAgents] = useState([]);
//   const [policies, setPolicies] = useState([]);
//   const [assignData, setAssignData] = useState({
//     agentId: '',
//     policyId: '',
//     assignedDate: new Date().toISOString(),
//   });
//   const [error, setError] = useState('');
//   const [message, setMessage] = useState('');
//   const [loadingAssigned, setLoadingAssigned] = useState(true);
//   const [loadingAgents, setLoadingAgents] = useState(true);
//   const [loadingPolicies, setLoadingPolicies] = useState(true);
//   const [assigning, setAssigning] = useState(false);
//   const navigate = useNavigate();
 
//   useEffect(() => {
//     // Simulate setting UUID and token in local storage for testing
//     fetchAllAssignedPoliciesWithSecurity();
//     fetchAllAgentsWithSecurity();
//     fetchAllPoliciesWithSecurity();
//   }, []);
 
//   const fetchAllAssignedPoliciesWithSecurity = async () => {
//     setLoadingAssigned(true);
//     setError('');
//     const token = localStorage.getItem('userToken');
//     try {
//       const response = await axios.get(API_BASE_URL, {
//         headers: {
//           'Authorization': `Bearer ${token}`,
//           'Content-Type': 'application/json',
//         },
//       });
//       if (response.data && response.data.success) {
//         setAssignedPolicies(response.data.data);
//         setError('');
//       } else {
//         setError(response.data?.message || 'Failed to fetch assigned policies.');
//       }
//     } catch (error) {
//       console.error('Error fetching assigned policies:', error);
//       handleAuthError(error);
//     } finally {
//       setLoadingAssigned(false);
//     }
//   };
 
//   const fetchAllAgentsWithSecurity = async () => {
//     setLoadingAgents(true);
//     try {
//       const token = localStorage.getItem('userToken');
//       const response = await axios.get('/api/v1/agents', { // Adjust URL if needed
//         headers: {
//           'Authorization': `Bearer ${token}`,
//           'Content-Type': 'application/json',
//         },
//       });
//       if (response.data && response.data.success && Array.isArray(response.data.data)) {
//         setAgents(response.data.data);
//         setError('');
//       } else {
//         setError(response.data?.message || 'Failed to fetch agents for assignment.');
//       }
//     } catch (error) {
//       console.error('Error fetching agents:', error);
//       handleAuthError(error);
//     } finally {
//       setLoadingAgents(false);
//     }
//   };
 
//   const fetchAllPoliciesWithSecurity = async () => {
//     setLoadingPolicies(true);
//     try {
//       const token = localStorage.getItem('userToken');
//       const response = await axios.get('http://localhost:8082/api/v1/policies', {
//         headers: {
//           'Authorization': `Bearer ${token}`,
//           'Content-Type': 'application/json',
//         },
//       });
//       if (response.data && response.data.success && Array.isArray(response.data.data)) {
//         setPolicies(response.data.data);
//         setError('');
//       } else {
//         setError(response.data?.message || 'Failed to fetch available policies.');
//       }
//     } catch (error) {
//       console.error('Error fetching policies:', error);
//       handleAuthError(error);
//     } finally {
//       setLoadingPolicies(false);
//     }
//   };
 
//   const handleAssignChange = (e) => {
//     const { name, value } = e.target;
//     setAssignData(prevState => ({
//       ...prevState,
//       [name]: value,
//     }));
//   };
 
//   const handleAssignPolicyWithSecurity = async () => {
//     setAssigning(true);
//     setError('');
//     setMessage('');
//     const token = localStorage.getItem('userToken');
//     try {
//       const assignDataToSend = {
//         ...assignData,
//         assignedDate: new Date().toISOString(),
//       };
//       console.log(assignDataToSend);
//       const response = await axios.post('http://localhost:8084/api/v1/assigned-policy/addPolicy', assignDataToSend, {
//         headers: {
//           'Authorization': `Bearer ${token}`,
//           'Content-Type': 'application/json',
//         },
//       });
//       if (response.data && response.data.success) {
//         setMessage('Policy assigned successfully!');
//         fetchAllAssignedPoliciesWithSecurity();
//         setAssignData({ agentId: '', policyId: '', assignedDate: new Date().toISOString() });
//       } else {
//         setError(response.data?.message || 'Failed to assign policy.');
//       }
//     }   catch (error) {
//         console.error('Error assigning policy:', error);
//         if (error.response && error.response.status === 409) {
//           setError(error.response.data?.message || 'This policy is already assigned.');
//         } else {
//           handleAuthError(error);
//         }
//       }
//     finally {
//       setAssigning(false);
//     }
//   };
 
//   const handleAuthError = (error) => {
//     if (error.response && error.response.status === 401) {
//       setError('Unauthorized. Please log in again.');
//       localStorage.removeItem('userId');
//       localStorage.removeItem('userToken');
//       navigate('/login');
//     } else if (error.response && error.response.status === 403) {
//       setError('Forbidden. You do not have permission to perform this action.');
//     } else {
//       setError('An unexpected error occurred.');
//     }
//   };
 
//   return (
//     <>
//       <header className="transparent-header bg-white" >
//         <AdminNavBar />
//       </header>
//       <div className="container mt-4">
//         <div className="text-center mb-4">
//           <h2 style={{ fontFamily: 'Arial, sans-serif', fontWeight: 'bold', color: '#333' }}>
//             Assigning Policies to Agents
//           </h2>
//         </div>
 
//         {message && <div className="alert alert-success">{message}</div>}
//         {error && <div className="alert alert-danger">{error}</div>}
 
//         <div className="mb-4">
//           <h3 style={{ fontFamily: 'Georgia, serif', color: '#555' }} className="text-center">
//             Assign New Policy
//           </h3>
//           <form onSubmit={(e) => { e.preventDefault(); handleAssignPolicyWithSecurity(); }}>
//             <div className="mb-3">
//               <label htmlFor="agentId" className="form-label">Agent</label>
//               {loadingAgents ? (
//                 <div className="spinner-border spinner-border-sm text-primary" role="status"><span className="visually-hidden">Loading agents...</span></div>
//               ) : (
//                 <select
//                   className="form-select"
//                   id="agentId"
//                   name="agentId"
//                   value={assignData.agentId}
//                   onChange={handleAssignChange}
//                   required
//                   style={{ fontFamily: 'Verdana, sans-serif' }}
//                 >
//                   <option value="">Select Agent</option>
//                   {agents.map(agent => (
//                     <option key={agent.agentId} value={agent.agentId}>
//                       {agent.name} ({agent.agentId})
//                     </option>
//                   ))}
//                 </select>
//               )}
//             </div>
 
//             <div className="mb-3">
//               <label htmlFor="policyId" className="form-label">Policy</label>
//               {loadingPolicies ? (
//                 <div className="spinner-border spinner-border-sm text-primary" role="status"><span className="visually-hidden">Loading policies...</span></div>
//               ) : (
//                 <select
//                   className="form-select"
//                   id="policyId"
//                   name="policyId"
//                   value={assignData.policyId}
//                   onChange={handleAssignChange}
//                   required
//                   style={{ fontFamily: 'Verdana, sans-serif' }}
//                 >
//                   <option value="">Select Policy</option>
//                   {policies.map(policy => (
//                     <option key={policy.policyId} value={policy.policyId}>
//                       {policy.name} ({policy.policyId})
//                     </option>
//                   ))}
//                 </select>
//               )}
//             </div>
 
//             <div className="text-center">
//               <button
//                 type="submit"
//                 className="btn btn-primary"
//                 disabled={assigning}
//                 style={{ fontFamily: 'Segoe UI, Tahoma, Geneva, Verdana, sans-serif', fontWeight: '500' }}
//               >
//                 {assigning ? (
//                   <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
//                 ) : (
//                   'Assign Policy'
//                 )}
//               </button>
//             </div>
//           </form>
//         </div>
 
//         <hr className="my-4" />
 
//         <div>
//           <h3 style={{ fontFamily: 'Georgia, serif', color: '#555' }} className="text-center">
//             Currently Assigned Policies
//           </h3>
//           {loadingAssigned ? (
//             <div className="spinner-border text-primary" role="status"><span className="visually-hidden">Loading assigned policies...</span></div>
//           ) : (
//             <div className="table-responsive">
//               {assignedPolicies.length > 0 ? (
//                 <table className="table table-striped table-bordered" style={{ fontFamily: 'Calibri, sans-serif' }}>
//                   <thead>
//                     <tr>
//                       <th>Assign ID</th>
//                       <th>Policy</th>
//                       <th>Agent</th>
//                       <th>Assignment Date</th>
//                     </tr>
//                   </thead>
//                   <tbody>
//                     {assignedPolicies.map(assignment => {
//                       const agent = agents.find(a => a.agentId === assignment.agentId);
//                       const policy = policies.find(p => p.policyId === assignment.policyId);
 
//                       return (
//                         <tr key={assignment.assignId}>
//                           <td style={{ whiteSpace: 'nowrap' }}> <span>{assignment.assignId}</span></td>
//                           <td style={{ whiteSpace: 'nowrap' }}>
//                             <span> {policy?.name || 'N/A'}
//                               <br />
//                               ({assignment.policyId}) </span>
//                           </td>
//                           <td style={{ whiteSpace: 'nowrap' }}>
//                             <span> {agent?.name || 'N/A'}
//                               <br />
//                               ({assignment.agentId}) </span>
//                           </td>
//                           <td>{new Date(assignment.assignedDate).toLocaleDateString()}</td>
//                         </tr>
//                       );
//                     })}
//                   </tbody>
//                 </table>
//               ) : (
//                 <div className="alert alert-info">No policies have been assigned yet.</div>
//               )}
//             </div>
//           )}
//         </div>
//         <div className="text-center mt-3">
//           <Link
//             to="/admindashboard"
//             className="btn btn-secondary"
//             style={{ fontFamily: 'Segoe UI, Tahoma, Geneva, Verdana, sans-serif', fontWeight: '500' }}
//           >
//             Back to Home
//           </Link>
//         </div>
//       </div>
//     </>
//   );
// };
 
// export default AssignPolicy;
 
import { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link, useNavigate } from 'react-router-dom';
import AdminNavBar from '../layout/AdminNavBar';
import Select from 'react-select';
 
 
const API_BASE_URL = '/api/v1/assigned-policy';
 
const AssignPolicy = () => {
  const [assignedPolicies, setAssignedPolicies] = useState([]);
  const [agents, setAgents] = useState([]);
  const [policies, setPolicies] = useState([]);
  const [assignData, setAssignData] = useState({
    agentId: '',
    policyId: '',
    assignedDate: new Date().toISOString(),
  });
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [loadingAssigned, setLoadingAssigned] = useState(true);
  const [loadingAgents, setLoadingAgents] = useState(true);
  const [loadingPolicies, setLoadingPolicies] = useState(true);
  const [assigning, setAssigning] = useState(false);
  const navigate = useNavigate();
  const agentSelectRef = useRef(null);
  const policySelectRef = useRef(null);
 
  useEffect(() => {
    fetchAllAssignedPoliciesWithSecurity();
    fetchAllAgentsWithSecurity();
    fetchAllPoliciesWithSecurity();
  }, []);
 
  const fetchAllAssignedPoliciesWithSecurity = async () => {
    setLoadingAssigned(true);
    setError('');
    const token = localStorage.getItem('userToken');
    try {
      const response = await axios.get(API_BASE_URL, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
      if (response.data && response.data.success) {
        setAssignedPolicies(response.data.data);
        setError('');
      } else {
        setError(response.data?.message || 'Failed to fetch assigned policies.');
      }
    } catch (error) {
      console.error('Error fetching assigned policies:', error);
      handleAuthError(error);
    } finally {
      setLoadingAssigned(false);
    }
  };
 
  const fetchAllAgentsWithSecurity = async () => {
    setLoadingAgents(true);
    try {
      const token = localStorage.getItem('userToken');
      const response = await axios.get('/api/v1/agents', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
      if (response.data && response.data.success && Array.isArray(response.data.data)) {
        setAgents(response.data.data.map(agent => ({
          value: agent.agentId,
          label: `${agent.name} (${agent.agentId})`,
        })));
        setError('');
      } else {
        setError(response.data?.message || 'Failed to fetch agents for assignment.');
      }
    } catch (error) {
      console.error('Error fetching agents:', error);
      handleAuthError(error);
    } finally {
      setLoadingAgents(false);
    }
  };
 
  const fetchAllPoliciesWithSecurity = async () => {
    setLoadingPolicies(true);
    try {
      const token = localStorage.getItem('userToken');
      const response = await axios.get('http://localhost:8082/api/v1/policies', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
      if (response.data && response.data.success && Array.isArray(response.data.data)) {
        setPolicies(response.data.data.map(policy => ({
          value: policy.policyId,
          label: `${policy.name} (${policy.policyId})`,
        })));
        setError('');
      } else {
        setError(response.data?.message || 'Failed to fetch available policies.');
      }
    } catch (error) {
      console.error('Error fetching policies:', error);
      handleAuthError(error);
    } finally {
      setLoadingPolicies(false);
    }
  };
 
  const handleAgentSelectChange = (selectedOption) => {
    setAssignData(prevState => ({
      ...prevState,
      agentId: selectedOption ? selectedOption.value : '',
    }));
  };
 
  const handlePolicySelectChange = (selectedOption) => {
    setAssignData(prevState => ({
      ...prevState,
      policyId: selectedOption ? selectedOption.value : '',
    }));
  };
 
  const handleAssignPolicyWithSecurity = async () => {
    setAssigning(true);
    setError('');
    setMessage('');
    const token = localStorage.getItem('userToken');
    try {
      const assignDataToSend = {
        ...assignData,
        assignedDate: new Date().toISOString(),
      };
      console.log(assignDataToSend);
      const response = await axios.post('http://localhost:8084/api/v1/assigned-policy/addPolicy', assignDataToSend, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
      if (response.data && response.data.success) {
        setMessage('Policy assigned successfully!');
        fetchAllAssignedPoliciesWithSecurity();
        setAssignData({ agentId: '', policyId: '', assignedDate: new Date().toISOString() });
        if (agentSelectRef.current) agentSelectRef.current.clearValue();
        if (policySelectRef.current) policySelectRef.current.clearValue();
      } else {
        setError(response.data?.message || 'Failed to assign policy.');
      }
    }   catch (error) {
        console.error('Error assigning policy:', error);
        if (error.response && error.response.status === 409) {
          setError(error.response.data?.message || 'This policy is already assigned.');
        } else {
          handleAuthError(error);
        }
      }
    finally {
      setAssigning(false);
    }
  };
 
  const handleAuthError = (error) => {
    if (error.response && error.response.status === 401) {
      setError('Unauthorized. Please log in again.');
      localStorage.removeItem('userId');
      localStorage.removeItem('userToken');
      navigate('/login');
    } else if (error.response && error.response.status === 403) {
      setError('Forbidden. You do not have permission to perform this action.');
    } else {
      setError('An unexpected error occurred.');
    }
  };
 
  return (
    <>
      <header className="transparent-header bg-white" >
        <AdminNavBar />
      </header>
      <div className="container mt-4">
        <div className="text-center mb-4">
          <h2 style={{ fontFamily: 'Arial, sans-serif', fontWeight: 'bold', color: '#333' }}>
            Assigning Policies to Agents
          </h2>
        </div>
 
        {message && <div className="alert alert-success">{message}</div>}
        {error && <div className="alert alert-danger">{error}</div>}
 
        <div className="mb-4">
          <h3 style={{ fontFamily: 'Georgia, serif', color: '#555' }} className="text-center">
            Assign New Policy
          </h3>
          <form onSubmit={(e) => { e.preventDefault(); handleAssignPolicyWithSecurity(); }}>
            <div className="mb-3">
              <label htmlFor="agentId" className="form-label">Agent</label>
              {loadingAgents ? (
                <div className="spinner-border spinner-border-sm text-primary" role="status"><span className="visually-hidden">Loading agents...</span></div>
              ) : (
                <Select
                  ref={agentSelectRef}
                  options={agents}
                  onChange={handleAgentSelectChange}
                  placeholder="Select Agent"
                  isSearchable
                  styles={{
                    control: (provided) => ({
                      ...provided,
                      fontFamily: 'Verdana, sans-serif',
                    }),
                    menu: (provided) => ({
                      ...provided,
                      fontFamily: 'Verdana, sans-serif',
                    }),
                    option: (provided) => ({
                      ...provided,
                      fontFamily: 'Verdana, sans-serif',
                    }),
                  }}
                />
              )}
            </div>
 
            <div className="mb-3">
              <label htmlFor="policyId" className="form-label">Policy</label>
              {loadingPolicies ? (
                <div className="spinner-border spinner-border-sm text-primary" role="status"><span className="visually-hidden">Loading policies...</span></div>
              ) : (
                <Select
                  ref={policySelectRef}
                  options={policies}
                  onChange={handlePolicySelectChange}
                  placeholder="Select Policy"
                  isSearchable
                  styles={{
                    control: (provided) => ({
                      ...provided,
                      fontFamily: 'Verdana, sans-serif',
                    }),
                    menu: (provided) => ({
                      ...provided,
                      fontFamily: 'Verdana, sans-serif',
                    }),
                    option: (provided) => ({
                      ...provided,
                      fontFamily: 'Verdana, sans-serif',
                    }),
                  }}
                />
              )}
            </div>
 
            <div className="text-center">
              <button
                type="submit"
                className="btn btn-primary"
                disabled={assigning || !assignData.agentId || !assignData.policyId}
                style={{ fontFamily: 'Segoe UI, Tahoma, Geneva, Verdana, sans-serif', fontWeight: '500' }}
              >
                {assigning ? (
                  <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                ) : (
                  'Assign Policy'
                )}
              </button>
            </div>
          </form>
        </div>
 
        <hr className="my-4" />
 
        <div>
          <h3 style={{ fontFamily: 'Georgia, serif', color: '#555' }} className="text-center">
            Currently Assigned Policies
          </h3>
          {loadingAssigned ? (
            <div className="spinner-border text-primary" role="status"><span className="visually-hidden">Loading assigned policies...</span></div>
          ) : (
            <div className="table-responsive">
              {assignedPolicies.length > 0 ? (
                <table className="table table-striped table-bordered" style={{ fontFamily: 'Calibri, sans-serif' }}>
                  <thead>
                    <tr>
                      <th>Assign ID</th>
                      <th>Policy</th>
                      <th>Agent</th>
                      <th>Assignment Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {assignedPolicies.map(assignment => {
                      const agent = agents.find(a => a.value === assignment.agentId);
                      const policy = policies.find(p => p.value === assignment.policyId);
 
                      return (
                        <tr key={assignment.assignId}>
                          <td style={{ whiteSpace: 'nowrap' }}>{assignment.assignId}</td>
                          <td>
                            {policy?.label && (
                              <>
                                <div>{policy.label.split(' (')[0]}</div> {/* Policy Name */}
                                <div className="text-muted">({policy.value})</div> {/* Policy ID */}
                              </>
                            )}
                            {!policy?.label && <span>N/A</span>}
                          </td>
                          <td>
                            {agent?.label && (
                              <>
                                <div>{agent.label.split(' (')[0]}</div> {/* Agent Name */}
                                <div className="text-muted">({agent.value})</div> {/* Agent ID */}
                              </>
                            )}
                            {!agent?.label && <span>N/A</span>}
                          </td>
                          <td>{new Date(assignment.assignedDate).toLocaleDateString()}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              ) : (
                <div className="alert alert-info">No policies have been assigned yet.</div>
              )}
            </div>
          )}
        </div>
        <div className="text-center mt-3">
          <Link
            to="/admindashboard"
            className="btn btn-secondary"
            style={{ fontFamily: 'Segoe UI, Tahoma, Geneva, Verdana, sans-serif', fontWeight: '500' }}
          >
            Back to Home
          </Link>
        </div>
      </div>
    </>
  );
};
 
export default AssignPolicy;
 