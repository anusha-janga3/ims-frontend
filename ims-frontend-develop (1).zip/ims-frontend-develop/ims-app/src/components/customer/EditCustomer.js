import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS

const EditCustomer = () => {
  const navigate = useNavigate();
  const [customerData, setCustomerData] = useState({
    address: '',
    name: '',
    email: '',
    phone: '',
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [validationErrors, setValidationErrors] = useState({});

  // Retrieve the token and user ID from local storage
  const token = localStorage.getItem('userToken');
  const loggedInUserId = localStorage.getItem('userId');

  useEffect(() => {
    const fetchCustomerData = async () => {
      setLoading(true);
      setError('');
      try {
        const response = await axios.get(`http://localhost:8088/api/v1/customers/${loggedInUserId}`, {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        setCustomerData({
          address: response.data.data.address,
          name: response.data.data.name,
          email: response.data.data.email,
          phone: response.data.data.phone,
        });
      } catch (err) {
        setError(err.message);
        
        
      } finally {
        setLoading(false);
      }
    };

    if (token && loggedInUserId) {
      fetchCustomerData();
    } else {
      setError('Authentication token or user ID not found. Please log in.');
      setLoading(false);
      navigate('/login'); // Redirect to login if not authenticated
    }
  }, [navigate, token, loggedInUserId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCustomerData({
      ...customerData,
      [name]: value,
    });
    setValidationErrors((prevErrors) => ({
      ...prevErrors,
      [name]: '',
    }));
  };

  const validate = () => {
    const errors = {};
    const nameRegex = /^[a-zA-Z\s]*$/; // Allows only letters and spaces
    const phoneRegex = /^\d{10}$/; // Exactly 10 digits

    if (!customerData.name.trim()) {
      errors.name = 'Name is required.';
    } else if (!nameRegex.test(customerData.name)) {
      errors.name = 'Name should only contain letters and spaces.';
    }

    if (!customerData.phone.trim()) {
      errors.phone = 'Phone number is required.';
    } else if (!phoneRegex.test(customerData.phone)) {
      errors.phone = 'Phone number must be exactly 10 digits.';
    }

    if (!customerData.address.trim()) {
      errors.address = 'Address is required.';
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };


  const handleSubmit = async (e) => {
    e.preventDefault();
    if (validate()) {
      setLoading(true);
      setError('');

      try {
        const response = await axios.put(
          `http://localhost:8088/api/v1/customers/update/${loggedInUserId}`, // Use loggedInUserId for update
          {
            address: customerData.address,
            name: customerData.name,
            email: customerData.email,
            phone: customerData.phone,
          },
          {
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`,
            },
          }
        );
        console.log(response);
        console.log('Customer updated successfully');
        navigate(`/dashboard/profile/${loggedInUserId}`); // Navigate back to the profile page
      } catch (error) {
        console.error('Error updating customer:', error);
        if (error.response) {
          // The request was made and the server responded with a status code
          // that falls out of the range of 2xx
          console.log('Response data:', error.response.data);
          console.log('Response status:', error.response.status);
          console.log('Response headers:', error.response.headers);

          if (error.response.status === 400) {
            setError(error.response.data.message || 'Invalid data provided.');
          } else if (error.response.status === 401) {
            setError('Unauthorized. Please log in again.');
            // Optionally clear tokens and navigate to login
            localStorage.removeItem('userId');
            localStorage.removeItem('userToken');
            navigate('/login');
          } else if (error.response.status === 403) {
            setError('Forbidden. You do not have permission to update this customer.');
          } else if (error.response.status === 404) {
            setError(error.response.data.message || 'Customer not found.');
          } else if (error.response.status === 409) {
            setError(error.response.data.message || 'Duplicate contact information found.');
          } else {
            setError('An unexpected error occurred while updating the customer.');
          }
        } else if (error.request) {
          // The request was made but no response was received
          console.error('No response received:', error.request);
          setError('Network error. Please check your internet connection.');
        } else {
          // Something happened in setting up the request that triggered an Error
          console.error('Error setting up the request:', error.message);
          setError(`An error occurred: ${error.message}`);
        }
      } finally {
        setLoading(false);
      }
    }
  };

  if (loading) {
    return <div>Loading customer information...</div>;
  }

  if (error) {
    return <div className="alert alert-danger mt-4">Error loading customer: {error}</div>;
  }

  return (
    <div className="container mt-4">
      <h2 className="mb-3">Edit Customer</h2>
      <form onSubmit={handleSubmit} noValidate>
        <div className="mb-3">
          <label htmlFor="name" className="form-label">Name:</label>
          <input
            type="text"
            id="name"
            name="name"
            value={customerData.name}
            onChange={handleChange}
            className={`form-control ${validationErrors.name ? 'is-invalid' : ''}`}
            aria-describedby="nameError"
          />
          {validationErrors.name && <div id="nameError" className="invalid-feedback">{validationErrors.name}</div>}
        </div>
        <div className="mb-3">
          <label htmlFor="email" className="form-label">Email:</label>
          <input
            type="email"
            id="email"
            name="email"
            value={customerData.email}
            onChange={handleChange}
            className="form-control"
            readOnly
            aria-describedby="emailError"
          />
          <div id="emailError" className="form-text text-muted">Email cannot be updated.</div>
        </div>
        <div className="mb-3">
          <label htmlFor="phone" className="form-label">Phone:</label>
          <input
            type="text"
            id="phone"
            name="phone"
            value={customerData.phone}
            onChange={handleChange}
            className={`form-control ${validationErrors.phone ? 'is-invalid' : ''}`}
            aria-describedby="phoneError"
          />
          {validationErrors.phone && <div id="phoneError" className="invalid-feedback">{validationErrors.phone}</div>}
        </div>
        <div className="mb-3">
          <label htmlFor="address" className="form-label">Address:</label>
          <textarea
            id="address"
            name="address"
            value={customerData.address}
            onChange={handleChange}
            className={`form-control ${validationErrors.address ? 'is-invalid' : ''}`}
            aria-describedby="addressError"
          />
          {validationErrors.address && <div id="addressError" className="invalid-feedback">{validationErrors.address}</div>}
        </div>
        <button type="submit" className="btn btn-primary" disabled={loading}>
          {loading ? 'Updating...' : 'Update'}
        </button>
        {error && <p className="text-danger mt-2">{error}</p>}
      </form>
    </div>
  );
};

export default EditCustomer;