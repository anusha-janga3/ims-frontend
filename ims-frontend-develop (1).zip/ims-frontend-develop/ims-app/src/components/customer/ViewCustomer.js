
import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';

const ViewCustomer = () => {
  const navigate = useNavigate();
  const [customer, setCustomer] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const token = localStorage.getItem('userToken');
  const loggedInUserId = localStorage.getItem('userId');

  useEffect(() => {
    const fetchCustomer = async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await axios.get(`http://localhost:8088/api/v1/customers/${loggedInUserId}`, {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        setCustomer(response.data.data);
        setLoading(false);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };

    if (token && loggedInUserId) {
      fetchCustomer();
    } else {
      setError('Authentication token or user ID not found. Please log in.');
      setLoading(false);
      navigate('/login');
    }
  }, [navigate, token, loggedInUserId]);

 

 

  if (loading) {
    return <div className="container mt-5">
      <div className="spinner-border text-primary" role="status">
        <span className="visually-hidden">Loading customer details...</span>
      </div>
    </div>;
  }

  if (error) {
    return <div className="container mt-5">
      <div className="alert alert-danger" role="alert">
        Error: {error}
      </div>
    </div>;
  }

  if (!customer) {
    return <div className="container mt-5">
      <div className="alert alert-warning" role="alert">
        Customer not found.
      </div>
    </div>;
  }


  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-8">
          <div className="card shadow-lg border-0 rounded-lg mt-5">
            <div className="card-header bg-primary text-white rounded-top">
              <h3 className="card-title text-center">My Profile</h3>
            </div>
            <div className="card-body p-4">
              <div className="mb-3">
                <h5 className="card-subtitle mb-2 text-muted">Personal Details</h5>
                <p className="card-text">
                  <strong>Customer ID:</strong> <span className="fw-bold">{customer.customerId}</span>
                </p>
                <p className="card-text">
                  <strong>Name:</strong> <span className="fw-bold">{customer.name}</span>
                </p>
                <p className="card-text">
                  <strong>Email:</strong> <span className="fw-bold">{customer.email}</span>
                </p>
                {customer.phone && (
                  <p className="card-text">
                    <strong>Phone:</strong> <span className="fw-bold">{customer.phone}</span>
                  </p>
                )}
                {customer.address && (
                  <p className="card-text">
                    <strong>Address:</strong> <span className="fw-bold">{customer.address}</span>
                  </p>
                )}
              </div>

              {Object.keys(customer)
                .filter(
                  (key) =>
                    key !== 'customerId' &&
                    key !== 'name' &&
                    key !== 'email' &&
                    key !== 'phone' &&
                    key !== 'address'
                )
                .map((key) => (
                  <p className="card-text mb-2" key={key}>
                    <strong>{key.charAt(0).toUpperCase() + key.slice(1)}:</strong>{' '}
                    <span className="fw-bold">{customer[key]}</span>
                  </p>
                ))}

              <div className="d-grid gap-2 mt-4">
                <Link
                  to={`/customers/edit/${loggedInUserId}`}
                  className="btn btn-outline-primary btn-lg"
                >
                  <i className="bi bi-pencil-square me-2"></i>Update Profile
                </Link>
                
                <button
                  onClick={() => navigate('/dashboard')}
                  className="btn btn-secondary btn-sm mt-3"
                >
                  <i className="bi bi-arrow-left me-2"></i>Back to Dashboard
                </button>
              </div>

              {error && <p className="mt-3 text-danger"><i className="bi bi-exclamation-triangle-fill me-2"></i>{error}</p>}
            </div>
          </div>
        </div>
      </div>

     
    </div>
  );
};

export default ViewCustomer;
 