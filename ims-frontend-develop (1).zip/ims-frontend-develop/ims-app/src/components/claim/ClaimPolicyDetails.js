import React from "react";
import "./ClaimpolicyDetails.css"; 

const ClaimPolicyDetails = ({ policy, handleFileClaimClick }) => {
  if (!policy) {
    return <p>No policy details available.</p>;
  }

  return (
    <div className="claim-policy-card">
      <h3>Policy Information</h3>
      {policy.name && <p><strong>Policy Name:</strong> {policy.name}</p>}
      {policy.coverageDetails && <p><strong>Coverage Details:</strong> {policy.coverageDetails}</p>}
      {policy.premiumAmount && <p><strong>Premium:</strong> ₹{policy.premiumAmount}</p>}
      {policy.validityPeriod && <p><strong>Validity Period:</strong> {policy.validityPeriod} years</p>}
      {policy.purchaseDate && (
        <p><strong>Purchase Date:</strong> {new Date(policy.purchaseDate).toLocaleString()}</p>
      )}
      <button
        className="file-claim-btn"
        onClick={() => handleFileClaimClick(policy)}
      >
        File Claim
      </button>
    </div>
  );
};

export default ClaimPolicyDetails;
