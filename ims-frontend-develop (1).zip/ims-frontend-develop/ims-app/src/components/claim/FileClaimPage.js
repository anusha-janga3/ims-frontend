import React, { useState, useEffect } from "react";
import axios from "axios";
import ClaimPolicyDetails from "./ClaimPolicyDetails"; 
import "../policy/CustomerPolicies.css"; 
import CustomerNavbar from "../layout/CustomerNavbar";
import details from '../admin/Properties';

import "./FileClaimPage.css"; 

const FileClaimPage = () => {
  const [policies, setPolicies] = useState([]); 
  const [error, setError] = useState(""); 
  const [popupError, setPopupError] = useState(""); 
  const [showPopup, setShowPopup] = useState(false); 
  const [selectedPolicy, setSelectedPolicy] = useState(null); 
  const [claimAmount, setClaimAmount] = useState(""); 
  const [successMessage, setSuccessMessage] = useState("");

  const token = localStorage.getItem("userToken"); 
  const customerId = localStorage.getItem("userId"); 
  const adminId = details.admin;

  const fetchCustomerPolicyDetails = async () => {
    try {
      const customerResponse = await axios.get(
        `/api/v1/policies/customer/${customerId}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      const customerPolicies = customerResponse.data.data;
      const policyDetailsArray = await Promise.all(
        customerPolicies.map(async (customerPolicy) => {
          const { policyId, purchaseDate, agentId } = customerPolicy;

          if (!policyId) {
            console.error("Policy ID is missing.");
            return null;
          }

          const policyResponse = await axios.get(`/api/v1/policies/${policyId}`, {
            headers: { Authorization: `Bearer ${token}` },
          });

          return {
            ...policyResponse.data.data,
            purchaseDate, 
            agentId, 
          };
        })
      );

      setPolicies(policyDetailsArray.filter((policy) => policy));
    } catch (err) {
      console.error("Failed to fetch policies:", err);
      setError("Failed to fetch policies.");
    }
  };

  const handleFileClaimClick = (policy) => {
    setSelectedPolicy(policy); 
    setShowPopup(true); 
    setClaimAmount(""); 
    setPopupError(""); 
  };

  const handleClaimSubmit = async () => {
    if (!claimAmount) {
      setPopupError("Claim amount cannot be empty.");
      return;
    }

    if (parseFloat(claimAmount) <= 10000) {
      setPopupError("Claim amount must be greater than 10000.");
      return;
    }

    if (parseFloat(claimAmount) >= 10000000) {
      setPopupError("Claim amount is Invalid");
      return;
    }

    try {
      const claimData = {
        claimAmount: parseFloat(claimAmount), 
        customerId,
        adminId,
        policyId: selectedPolicy.policyId,
        agentId: selectedPolicy.agentId,
      };

      const response = await axios.post(
        "http://localhost:8083/api/v1/claim/claim",
        claimData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          withCredentials: true,
        }
      );
      console.log(response);
      setSuccessMessage("Claim filed successfully!");
      setShowPopup(false); 
      setClaimAmount(""); 
      setPopupError(""); 
    } catch (err) {
      console.error("Error filing claim:", err);
      if (err.response && err.response.data && err.response.data.message) {
        setPopupError(err.response.data.message); 
      } else if (err.message) {
        setPopupError(`Failed to file the claim: ${err.message}`); 
      } else {
        setPopupError("Failed to file the claim. Please try again."); 
      }
    }
  };

  useEffect(() => {
    fetchCustomerPolicyDetails();
  }, []);

  return (
    <>
      <header className="transparent-header">
        <CustomerNavbar />
      </header>
      <div className="container">
        <h1 className="title">File a Claim for Your Policies</h1>
        {error && <p className="error">{error}</p>} 
        {successMessage && <p className="success">{successMessage}</p>}
        {policies.length > 0 ? (
          <div className="policies-grid">
            {policies.map((policy, index) => (
              <ClaimPolicyDetails
                key={index}
                policy={policy}
                handleFileClaimClick={handleFileClaimClick}
              />
            ))}
          </div>
        ) : (
          <p>Loading policy details...</p>
        )}

        {/* Popup for filing a claim */}
        {showPopup && (
          <div className="popup-overlay" onClick={() => setShowPopup(false)}>
            <div
              className="popup-box"
              onClick={(e) => e.stopPropagation()} 
            >
              <h3 className="popup-title">File Claim</h3>
              <p className="popup-policy-info">
                Filing a claim for Policy : {selectedPolicy.policyName}
                <strong className="highlighted-policy-name">
                  {selectedPolicy.policyName}
                </strong>
              </p>
              <input
                type="number"
                placeholder="Enter Claim Amount "
                value={claimAmount}
                onChange={(e) => setClaimAmount(e.target.value)}
                className={`claim-input ${popupError ? 'error-input' : ''}`}
              />
              {popupError && <p className="validation-error">{popupError}</p>}
              <div className="popup-buttons">
                <button className="submit-claim-button" onClick={handleClaimSubmit}>
                  Submit
                </button>
                <button className="close-popup-button" onClick={() => setShowPopup(false)}>
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default FileClaimPage;