import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import Login from './components/authentication/Login';
import Signup from './components/authentication/Signup';
import PrivateRoute from './components/authentication/PrivateRoute';
import DashboardLayout from './components/layout/CustomerDashboard';
import NotificationPage from './components/notificaton/Notification';
import CustomerClaimListPage from './components/claim/CustomerClaimList';
import Landing from './components/authentication/Landing';
import CustomerPolicies from './components/policy/CustomerPolicies';
import FileClaimPage from './components/claim/FileClaimPage';
import AdminDashBoard from './components/layout/AdminDashboard';
import AgentManager from './components/admin/AgentManager';
import EditAgent from './components/admin/EditAgent';
import ViewAgent from './components/admin/ViewAgent';
import AssignPolicy from './components/admin/AssignPolicy';
import PolicyManager from './components/admin/PolicyManager';
import EditPolicy from './components/admin/UpdatePolicy';
import ViewPolicy from './components/admin/ViewPolicy';
import AddPolicy from './components/admin/AddPolicy';
import AgentDashboard from './components/layout/AgentDashboard';
import AgentClaimListPage from './components/claim/AgentClaimList';
import AgentPolicies from './components/policy/AgentPolicies';
import AgentCustomers from './components/policy/AgentCustomers';
import RegisterPolicy from './components/policy/PolicyRegister';
import SupportPage from './components/pages/SupportPage';
import ViewCustomer from './components/customer/ViewCustomer';
import EditCustomer from './components/customer/EditCustomer';
import CustomerFooter from './components/pages/FooterPage';

function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}

function AppContent() {
  const location = useLocation();

  const hideFooterRoutes = ['/', '/Login', '/SignUp'];
  const showFooter = !hideFooterRoutes.includes(location.pathname);
   const loggedInUserId = localStorage.getItem('userId');

  return (
    <>
      {/* Conditionally render the AppNavbar only when showNavbar is true */}
      <div className="container mt-3">
        <Routes>
          {/* Public routes */}
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signUp" element={<Signup />} />

          {/* Protected routes */}
          <Route
            path="/dashboard"
            element={<PrivateRoute allowedRole="CUSTOMER"><DashboardLayout /></PrivateRoute>}
          />
          <Route
            path="/admindashboard"
            element={<PrivateRoute allowedRole="ADMIN"><AdminDashBoard /></PrivateRoute>}
          />
          <Route
            path="/agents"
            element={<PrivateRoute allowedRole="ADMIN"><AgentManager /></PrivateRoute>}
          />
          <Route
            path="/agents/edit/:agentId"
            element={<PrivateRoute allowedRole="ADMIN"><EditAgent /></PrivateRoute>}
          />
           <Route
            path="/agents/view/:agentId"
            element={<PrivateRoute allowedRole="ADMIN"><ViewAgent /></PrivateRoute>}
          />
           <Route
            path="/assign-policy"
            element={<PrivateRoute allowedRole="ADMIN"><AssignPolicy /></PrivateRoute>}
          />
          <Route
            path="/assign-policy/:agentId"
            element={<PrivateRoute allowedRole="ADMIN"><AssignPolicy /></PrivateRoute>}
          />
          <Route 
          path="/policies" 
          element={<PrivateRoute allowedRole="ADMIN"><PolicyManager /></PrivateRoute>} 
          />
          
        <Route
         path="/policies/edit/:policyId"
         element={<PrivateRoute allowedRole="ADMIN"><EditPolicy /></PrivateRoute>} 
          />

        <Route
         path="/policies/view/:policyId" 
         element={<PrivateRoute allowedRole="ADMIN"><ViewPolicy /></PrivateRoute>} 
        />

        <Route
         path="/policies/create" 
         element={<PrivateRoute allowedRole="ADMIN"><AddPolicy /></PrivateRoute>} 
         />
 
          <Route
            path={`/dashboard/profile/${loggedInUserId}`}
            element={<PrivateRoute allowedRole="CUSTOMER"><ViewCustomer /></PrivateRoute>}
          />
          <Route
            path={`/customers/edit/${loggedInUserId}`}
            element={<PrivateRoute allowedRole="CUSTOMER"><EditCustomer /></PrivateRoute>}
          />
           <Route
            path="/dashboard/policies/view"
            element={<PrivateRoute allowedRole="CUSTOMER"><CustomerPolicies /></PrivateRoute>}
          />
          <Route
            path="/dashboard/policies/add"
            element={<PrivateRoute allowedRole="CUSTOMER"><RegisterPolicy /></PrivateRoute>}
          />
          <Route
            path="/dashboard/claims/submit"
            element={<PrivateRoute allowedRole="CUSTOMER"><FileClaimPage /></PrivateRoute>}
          />
          <Route
            path="/dashboard/claims/status"
            element={<PrivateRoute allowedRole="CUSTOMER"><CustomerClaimListPage /></PrivateRoute>}
          />
          <Route
            path="/dashboard/support"
            element={<PrivateRoute allowedRole="CUSTOMER"><SupportPage /></PrivateRoute>}
          />
          <Route
            path="/dashboard/notifications"
            element={<PrivateRoute allowedRole="CUSTOMER"><NotificationPage /></PrivateRoute>}
          />

         <Route
          path="/agentdashboard" 
          element={<PrivateRoute allowedRole="AGENT"><AgentDashboard /></PrivateRoute>}
           />

          <Route
           path="/agent/claims"
           element={<PrivateRoute allowedRole="AGENT"><AgentClaimListPage /></PrivateRoute>}
             />
      <Route 
      path="/agent/customers" 
      element={<PrivateRoute allowedRole="AGENT"><AgentCustomers /></PrivateRoute>}
      /> 
          
          <Route
           path="/agent/policies"
           element={<PrivateRoute allowedRole="AGENT"><AgentPolicies /></PrivateRoute>}
            />

          {/* Default route */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
      {showFooter && <CustomerFooter />}
    </>
  );
}



export default App;
